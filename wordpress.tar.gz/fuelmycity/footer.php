</main>
<?php
$page = fmc_get_current_page();
if ($page !== PRIZES && $page !== ABOUT && $page !== JOURNEY && $page !== TERMS) {
    include_once get_template_directory() . '/inc/loading.php';
}
include_once get_template_directory() . '/inc/footer.php';
?>
</div>
<div id="overlay"></div>
<script>
<?php
$filter_posts_byKol = '';
if (isset($_GET['kol-user'])) {
    $filter_posts_byKol = '&kol-user=' . (int) $_GET['kol-user'];
}

$country = '&' . COUNTRY . '=' . fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());
?>
    var settings = {
        language: '<?php echo ICL_LANGUAGE_CODE; ?>',
        country: '<?php echo fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs()); ?>',
        rating: {
            url: '<?php echo admin_url('admin-ajax.php?action=save_rating'); ?>',
            type: 'post'
        },
        journeys: {
            url: '<?php echo admin_url('admin-ajax.php?action=get_list_posts&page=1' . $filter_posts_byKol . $country); ?>',
            type: 'get',
            dataType: 'json'
        },
        socialFeed: {
            urlHome: '<?php echo admin_url('admin-ajax.php?action=get_feeds&limit=' . HOME_NUM_FEEDS . '&kol_user=true' . $country); ?>',
            gridUrl: {
                urlKOL: '<?php echo admin_url('admin-ajax.php?action=get_feeds&limit=' . FEED_LIMIT . '&kol_user=true&page=0' . $country); ?>',
                urlPubs: '<?php echo admin_url('admin-ajax.php?action=get_feeds&limit=' . FEED_LIMIT . '&publish=true&page=0'); ?>'
            },
            mapUrl: {
                urlKOL: '<?php echo admin_url('admin-ajax.php?action=get_feeds&limit=' . FEED_LIMIT . '&location=true&kol_user=true&page=0' . $country); ?>',
                urlPubs: '<?php echo admin_url('admin-ajax.php?action=get_feeds&limit=' . FEED_LIMIT . '&location=true&publish=true&page=0'); ?>',
                urlOneFeed: '<?php echo admin_url('admin-ajax.php?action=get_feeds&id='); ?>'
            }
        },
        iconMarker: {
            pub: '<?php echo get_template_directory_uri(); ?>/images/icon-marker-blue-medium.png',
            amb: '<?php echo get_template_directory_uri(); ?>/images/icon-marker-blue-medium.png',
            black: '<?php echo get_template_directory_uri(); ?>/images/icon-marker-black-medium.png'
        }
    };
</script>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/l10n.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/libs.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/script.js"></script>
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-64597553-1', 'auto');
  ga('send', 'pageview');

</script>
<noscript><?php _e('JavaScript is off. Please enable to view full site.', FMC); ?></noscript>
<?php wp_footer(); ?>
</body>
</html>
