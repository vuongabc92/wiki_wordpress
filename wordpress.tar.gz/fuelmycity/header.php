<!DOCTYPE html>
<html lang="en" class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1"><![endif]-->
        <title><?php wp_title('-', true, 'right'); ?><?php bloginfo('name'); ?></title>
        <?php $country = fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());?>
        <meta content="<?php echo home_url(); ?>" property="og:url">
        <meta content="<?php _e('Fuel My City', FMC); ?>" property="og:title">
        <meta content="<?php echo fmc_get_social_share($country, 'gp'); ?>" property="og:description">
        <meta content="<?php echo get_template_directory_uri() ?>/images/logo-slider.png" property="og:image">
        <meta content="article" property="og:type">

        <meta name="description" content="<?php bloginfo('description'); ?>">
        <meta name="keywords" content="">
        <meta name="robots" content="index, follow">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimal-ui">
        <link rel="shortcut icon" href="<?php echo get_template_directory_uri() ?>/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/style.css">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/print.css" media="print">
        <?php
            if ($country === LANG_TH) :
        ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/lang-th.css">
        <?php
            endif;
            if ($country === LANG_CH) :
        ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/lang-cn.css">
        <?php
            endif;
        ?>
        <script src="<?php echo get_template_directory_uri() ?>/js/modernizr.js"></script>
        <script src="https://apis.google.com/js/platform.js"></script>
        <script type="text/javascript">
            // First, load the widgets.js file asynchronously
            window.twttr = (function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0],
                t = window.twttr || {};
              if (d.getElementById(id)) return;
              js = d.createElement(s);
              js.id = id;
              js.src = '//platform.twitter.com/widgets.js';
              fjs.parentNode.insertBefore(js, fjs);
              t._e = [];
              t.ready = function(F) {
                t._e.push(F);
              };
              return t;
            }(document, 'script', 'twitter-wjs'));
            (function(d, s, id){
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) {return;}
              js = d.createElement(s); js.id = id;
              js.src = '//connect.facebook.net/en_US/sdk.js';
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
            window.fbAsyncInit = function() {
                   // init the FB JS SDK
                      FB.init({
                          <?php
                            $sp_user_id      = FMC_Country::SUPPER_ADMIN;
                            $facebook_app_id = get_user_meta($sp_user_id, 'facebook_app_id', true);
                          ?>
                          appId: '<?php echo $facebook_app_id; ?>', // App ID from the app dashboard
                          version: 'v2.4',
                          xfbml: true  // Look for social plugins on the page
                      });
                  }
        </script>
        <?php wp_head(); ?>
    </head>
    <?php

        $page = fmc_get_current_page();
        $body_class = '';
        switch ($page) {
            case ABOUT:
                $body_class = 'about';

                break;
            case PRIZES:
                $body_class = 'prizes';

                break;
            case JOURNEYS:
                $body_class = 'post';

                break;
            case JOURNEY:
                $body_class = 'post-details';

                break;
            case SOCIALFEEDS:
                $body_class = 'social-feed';

                break;
            case TERMS:
                $body_class = 'terms-conditions';

                break;

            default:
                break;
        }
        if ($body_class === '') {
            $cur_post_for_slug = get_post(get_the_ID());
            if (is_front_page() || $cur_post_for_slug->post_name === HOME) {
                $body_class = HOME;
            } else {
                $body_class = 'post-details';
            }
        }
    ?>
    <body class="<?php echo $body_class; ?>">
        <?php include_once get_template_directory() . '/inc/conversion-tags.php'; ?>
        <div id="container">
            <?php include_once get_template_directory() . '/inc/header.php'; ?>
            <main id="main">