<?php

/*
  Template Name: Home page
 */

get_header();

include_once $template_path . '/inc/home/home-carousel.php';
include_once $template_path . '/inc/home/home-featured-posts.php';
include_once $template_path . '/inc/home/home-social-feeds.php';
get_footer();

