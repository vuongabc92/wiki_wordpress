<?php


get_header();
$image_bottom = CFS()->get("prize_image_bottom");
$img = (!is_null($image_bottom)) ? wp_get_attachment_image($image_bottom, 'full') : '';

?>
<div class="prize-block bgd-dark">
    <div class="grid-fluid">
        <div class="row heading">
            <div class="col-md-4">
                <h2 class="title"><?php echo CFS()->get("prize_title") ?></h2>
                <div class="tags"><span>#<?php echo CFS()->get("prize_tag1") ?></span><span>#<?php echo CFS()->get("prize_tag2") ?></span></div>
            </div>
            <div class="col-md-4 col-sm-6 editer-1">
                <p class="desc">
                    <?php echo apply_filters('content', CFS()->get("cfs_prize_left_column")); ?>
                </p>
            </div>
            <div class="col-md-4 col-sm-6 editer-1">
                <p class="desc">
                    <?php echo apply_filters('content', CFS()->get("cfs_prize_right_column")); ?>
                </p>
            </div>
        </div>
        <div class="row infographic">
            <div class="col-md-11 col-md-offset-1">
            <?php
               $img = preg_replace( '/(width|height)="\d*?"\s/', "", $img );
                echo $img;
            ?>
            </div>
        </div>
        </div>
</div>
<?php
get_footer();
