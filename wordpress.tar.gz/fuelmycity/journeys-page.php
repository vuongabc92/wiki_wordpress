<?php
/*
  Template Name: Journeys page
 */
get_header();
?>
<div class="posts-block bgd-dark">
    <div class="grid-fluid">
        <div class="row heading">
            <div class="col-md-4">
                <h2 class="title"><?php _e('Journeys', FMC); ?></h2>
                <div class="tags">
                    <span><?php _e('#Caltex', FMC); ?></span>
                    <span><?php _e('#Fuelmycity', FMC); ?></span>
                </div>
            </div>
            <div class="col-md-5 col-sm-8">
                <p class="desc blue-text">
                    <?php _e("We've searched high and low to find the best secret hang outs in and around Singapore City", FMC); ?>
                </p>
            </div>
        </div>
        <div class="post-list">
            <?php
            $posts = fmc_get_posts_by_user_registed_date(POST_LIMIT);
            $load_more = fmc_get_posts_by_user_registed_date(POST_LIMIT + 1);
            if (isset($_GET['kol-user']) && (int) $_GET['kol-user'] > 0) {
                $kol_id = (int) $_GET['kol-user'];
                $posts = fmc_get_posts(false, POST_LIMIT, 0, $kol_id, 0, '', true);
                if (count($posts) === 1) {
                    $post_detail = $posts[0];
                    $url = get_permalink($post_detail->ID);
                    wp_redirect($url);
                }
                $load_more = fmc_get_posts(false, POST_LIMIT + 1, 0, $kol_id, 0, '', true);
            }
            $count_posts = count($posts);
            global $post;
            if ($count_posts) :
                $cols = 2;
                $pre_row_num = (int) ($count_posts / $cols);
                $row_num = ($count_posts % $cols === 0) ? $pre_row_num : $pre_row_num + 1;
                $i = 1;
                for ($j = 1; $j <= $row_num; $j++) :
                    ?>
                    <div class="row">
                        <?php
                        for ($z = 1; $z <= $cols; $z++) :

                            if (isset($posts[$i - 1])) :
                                $post = $posts[$i - 1];
                                setup_postdata($post);
                                $kol_id = get_post_meta(get_the_ID(), CFS_KOL_USER, true);
                                if ('' === $kol_id) {
                                    $kol_id = get_the_author_meta('ID');
                                }
                                $img_id = get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true);
                                $cover_img = wp_get_attachment_image_src($img_id, FEATURED_POST_THUMBNAIL);
                                $alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                                $author_post = get_user_by('id', $kol_id);
                                $display_name = $author_post->display_name;
                                $higher = '';
                                if ($i % 2 === 0) {
                                    $higher = ' data-animate-scroll="data-animate-scroll"';
                                }
                                include 'inc/journey.php';
                            endif;
                            $i++;
                        endfor;
                        ?>
                    </div>
                    <?php
                endfor;
            endif;
            ?>
        </div>
        <?php
        if (count($load_more) > POST_LIMIT) :
            ?>
            <div class="button-wrap-1">
                <a href="javascrtip:;" title="<?php _e('Load more', FMC); ?>" class="button-style" data-load-more="">
                    <span class="text"><?php _e('Load more', FMC); ?></span>
                    <span class="arrow-down"></span>
                </a>
            </div>
            <?php
        endif;
        ?>
    </div>
</div>
<?php
get_footer();
