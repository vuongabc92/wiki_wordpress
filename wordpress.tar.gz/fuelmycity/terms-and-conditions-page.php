<?php
/*
  Template Name: Terms and conditions page
 */

get_header();
if (have_posts()) :
    while (have_posts()) : the_post();
        ?>
        <div class="terms-block bgd-dark">
            <div class="grid-fluid">
                <div class="row heading">
                    <div class="col-md-4">
                        <h2 class="title"><?php the_title(); ?></h2>
                    </div>
                    <div class="col-md-8">
                        <div class="editer-1">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    endwhile;
endif;
get_footer();
