<?php
get_header();
$article_id = get_the_ID();
$article = get_post($article_id);
$template_path = get_template_directory();
$cover_img_id = get_post_meta($article->ID, CFS_COVER_IMG, TRUE);
$rating_json = get_post_meta($article->ID, FMC_JOURNEY_RATING, TRUE);
$kol_id = get_post_meta($article->ID, CFS_KOL_USER, TRUE);
if (false === $kol_id || '' === $kol_id) {
    $kol_id = $article->post_author;
}
$cover_img = wp_get_attachment_image_src($cover_img_id, POST_COVER_IMG_SIZE);
$alt = get_post_meta($cover_img_id, '_wp_attachment_image_alt', true);
$youtube = get_post_meta($article->ID, FMC_YOUTUBE_URL, TRUE);
$article_title = $article->post_title;
$author_post  = get_user_by('id', $kol_id);
$display_name = $author_post->display_name;
$avatar_url = get_kol_avatar($kol_id, 481);
$kol_desc = get_user_meta($kol_id, 'description', true);
$kol_city = get_user_meta($kol_id, 'kol_city', true);
$facebook_name = get_user_meta($kol_id, 'facebook_name', true);
$facebook = get_user_meta($kol_id, 'facebook_link', true);
$twiter_name = get_user_meta($kol_id, 'twitter_name', true);
$twiter = get_user_meta($kol_id, 'twitter_link', true);
$instagram_name = get_user_meta($kol_id, 'instagram_name', true);
$instagram = get_user_meta($kol_id, 'instagram_link', true);
$desc_trans = apply_filters('content', $kol_desc);
$facebook_share = get_user_meta($kol_id, 'kol_facebook_share', true);
$titter_share = urlencode(get_user_meta($kol_id, 'kol_twitter_share', true));
$facebooks = preg_split('/[;,]/', $facebook);
$facebook_names = preg_split('/[;,]/', $facebook_name);
$facebook_min = count($facebooks) < count($facebook_names) ? count($facebooks) : count($facebook_names);
$twiters = preg_split('/[;,]/', $twiter);
$twiter_names = preg_split('/[;,]/', $twiter_name);
$twiter_min = count($twiters) < count($twiter_names) ? count($twiters) : count($twiter_names);
$instagrams = preg_split('/[;,]/', $instagram);
$instagram_names = preg_split('/[;,]/', $instagram_name);
$instagram_min = count($instagrams) < count($instagram_names) ? count($instagrams) : count($instagram_names);
?>

<figure class="cover-block">
    <div class="thumb">
        <?php if (fmc_check_detail_image($cover_img)) : ?>
            <img src="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_DETAILS_COVER); ?>" alt="<?php echo $alt; ?>"/>
        <?php endif; ?>
    </div>
    <div class="box-banner box-banner-blog">
        <div class="wrap">
            <div style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/bg_shape/bgd-blogpost.png)" class="inner bgd-blogpost">
                <h2><?php echo $display_name; ?> </h2>
                <ul class="social-group">
                    <li><span class="icon ic-facebook"></span>
                        <ul class="content-social">
                            <?php
                            if ($facebook_min > 0) {
                                for ($i = 0; $i < $facebook_min; $i++) {
                                    $tmp_facebook = trim($facebooks[$i]);
                                    $tmp_facebook_name = trim($facebook_names[$i]);
                                    if ($tmp_facebook != '' && $tmp_facebook_name != '') {
                                        echo '<li><a href="' . $tmp_facebook .'" target="_blank">' . $tmp_facebook_name . '</a></li>';
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </li>
                    <li><span class="icon ic-twitter"></span>
                        <ul class="content-social">
                            <?php
                            if ($twiter_min > 0) {
                                for ($i = 0; $i < $twiter_min; $i++) {
                                    $tmp_twiter = trim($twiters[$i]);
                                    $tmp_twiter_name = trim($twiter_names[$i]);
                                    if ($tmp_twiter != '' && $tmp_twiter_name != '') {
                                        echo '<li><a href="' . $tmp_twiter .'" target="_blank">' . $tmp_twiter_name . '</a></li>';
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </li>
                    <li><span class="icon ic-instagram"></span>
                        <ul class="content-social">
                            <?php
                            if ($instagram_min > 0) {
                                for ($i = 0; $i < $instagram_min; $i++) {
                                    $tmp_instagram = trim($instagrams[$i]);
                                    $tmp_instagram_name = trim($instagram_names[$i]);
                                    if ($tmp_instagram != '' && $tmp_instagram_name != '') {
                                        echo '<li><a href="' . $tmp_instagram .'" target="_blank">' . $tmp_instagram_name . '</a></li>';
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</figure>
<div class="grid-fluid">
    <div class="row">
        <div class="col-md-offset-2 col-md-8 col-sm-11 kol-profile">
            <h2><?php echo $article->post_title; ?></h2>
            <p><?php echo $desc_trans; ?></p>
        </div>
        <div class="col-sm-1 text-right wrap-btn-down hidden-xs">
            <a href="javascript:;" title="<?php _e('Down', FMC); ?>" class="icon-down circle-icon small-icon" data-scroll-to="#post-details-1"><?php _e('Down', FMC); ?></a>
        </div>
    </div>
</div>
<div class="share-block">
    <div class="grid-fluid">
        <div class="row">
            <div class="col-sm-9 col-sm-offset-2 col-xs-offset-1">
                <div class="share-group">
                    <span class="share">
                        <?php _e('Share', FMC); ?>
                    </span>
                    <a href="#" data-share="facebook" title="<?php _e('Facebook', FMC); ?>" class="icon-fb"
                       data-bitly-link="<?php echo home_url(); ?>"
                       data-text="<?php echo $facebook_share; ?>"
                       data-img="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_DETAILS_COVER); ?>"
                       data-caption=""><?php _e('Facebook', FMC); ?></a><a href="#" data-share="twitter" title="<?php _e('Twitter', FMC); ?>" class="icon-twitter"
                       data-text="<?php echo $titter_share; ?>"
                       data-on-footer=""><?php _e('Twitter', FMC); ?></a>
                </div>
                <span data-rating="span" data-id="<?php echo $article_id; ?>" class="star">
                    <?php
                    $num_star = 5;
                    $rating = 0;
                    if (false !== $rating_json && '' != $rating_json) {
                        $rating_arr = json_decode($rating_json);
                        $rating = round(array_sum($rating_arr) / count($rating_arr));
                    }
                    echo str_repeat('<span class="active"></span>', $rating);
                    echo str_repeat('<span></span>', $num_star - $rating);
                    ?>
                    <div class="statistic"><?php echo '<strong class="numb-rate">' . count($rating_arr) . '</strong> ' . __('user rated', FMC) ?> </div>
                </span>
            </div>
        </div>
    </div>
</div>
<?php
if ($youtube !== false && $youtube !== '') :
    ?>
    <div class="video-block">
        <div class="grid-fluid">
            <div class="row">
                <div class="col-md-8 col-md-offset-3 col-sm-12">
                    <div class="embed-responsive">
                        <iframe src="<?php echo YOUTUBE_EMBED_URL . $youtube; ?>" frameborder="0" allowfullscreen class="embed-responsive-item"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
endif;

/** Loop to genarate fice sections of post */
$j = 0;
for ($i = 1; $i <= NUM_SECTIONS; $i++) {
    $section_cover_img = wp_get_attachment_image_src(get_post_meta(get_the_ID(), constant("CFS_S{$i}_COVER_BG"), true));
    $section_cover_color = get_post_meta(get_the_ID(), constant("CFS_S{$i}_COVER_COLOR"), true);
    //$section_title       = mb_substr(get_post_meta(get_the_ID(), constant("CFS_S{$i}_TITLE"), true), 0, CFS_SECTION_TITLE_MAX, 'utf-8');
    $section_title = get_post_meta(get_the_ID(), constant("CFS_S{$i}_TITLE"), true);
    $section_map = get_post_meta(get_the_ID(), constant("CFS_S{$i}_MAP_LINK"), true);
    $location_address = get_post_meta(get_the_ID(), constant("CFS_S{$i}_LOCATION_ADDRESS"), true);
    $section_text1 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_TEXT_1"), true);
    $section_text2 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_TEXT_2"), true);
    $section_text3 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_TEXT_3"), true);

    $attachment_id_1 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_IMG_1"), true);
    $attachment_id_2 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_IMG_2"), true);
    $attachment_id_3 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_IMG_3"), true);
    $attachment_id_4 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_IMG_4"), true);
    $attachment_id_5 = get_post_meta(get_the_ID(), constant("CFS_S{$i}_IMG_5"), true);

    $section_img1 = wp_get_attachment_image_src($attachment_id_1);
    $section_img2 = wp_get_attachment_image_src($attachment_id_2);
    $section_img3 = wp_get_attachment_image_src($attachment_id_3);
    $section_img4 = wp_get_attachment_image_src($attachment_id_4);
    $section_img5 = wp_get_attachment_image_src($attachment_id_5);
    $post_images = fmc_get_num_post_img(get_the_ID(), $i);
    $num_img = count($post_images);

    $attachment_metadata1 = wp_get_attachment_metadata($attachment_id_1);
    $thumb_img = get_post( $attachment_id_1 ); // Get the image post
    $attachment_metadata1["image_meta"]["caption"] = $thumb_img->post_excerpt;

    $attachment_metadata2 = wp_get_attachment_metadata($attachment_id_2);
    $thumb_img = get_post( $attachment_id_2 ); // Get the image post
    $attachment_metadata2["image_meta"]["caption"] = $thumb_img->post_excerpt;

    $attachment_metadata3 = wp_get_attachment_metadata($attachment_id_3);
    $thumb_img = get_post( $attachment_id_3 ); // Get the image post
    $attachment_metadata3["image_meta"]["caption"] = $thumb_img->post_excerpt;

    $attachment_metadata4 = wp_get_attachment_metadata($attachment_id_4);
    $thumb_img = get_post( $attachment_id_4 ); // Get the image post
    $attachment_metadata4["image_meta"]["caption"] = $thumb_img->post_excerpt;

    $attachment_metadata5 = wp_get_attachment_metadata($attachment_id_5);
    $thumb_img = get_post( $attachment_id_5 ); // Get the image post
    $attachment_metadata5["image_meta"]["caption"] = $thumb_img->post_excerpt;

    /**
     * This code will extract all index name in array
     * to variable. dump the array to know the name.
     */
    extract($post_images);

    $backroud_style = '';
    $white_state = '';
    if ($section_cover_img !== false && $section_cover_img !== '') {
        $backroud_style = "style='background-image: url(\"{$section_cover_img[0]}\")'";
    }
    elseif ($section_cover_color !== false && $section_cover_color !== '') {
        $fixed_bg_color = array(CFS_SECTION_BG_RED, CFS_SECTION_BG_WHITE);
        if (in_array($section_cover_color, $fixed_bg_color)) {
            $backroud_style = "style='background-color: {$section_cover_color}'";
        }

        if ($section_cover_color === CFS_SECTION_BG_RED) {
            $white_state = 'white-state';
        }
    }

    /** Get location for view on map link on each section */
    $map_link = false;
    $post_social_id = 0;
    if (false !== $section_map && '' !== $section_map) {
        //Get post id by feed id
        $post_meta = $wpdb->get_results("SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_key='sf_feed_id' AND meta_value = '{$section_map}' ORDER BY post_id DESC", OBJECT);

        if (count($post_meta)) {
            $post_social_id = $post_meta[0]->post_id;
        }

        if ($post_social_id !== 0) {
            //Get map location
            $map_location = get_post_meta($post_social_id, SF_LOCATION, true);
            if (false !== $map_location && '' !== $map_location) {
                $map_link = json_decode($map_location);
            }
        }
    }

    //Link view on map for each section
    if (false !== $map_link) {
        $country = fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());
        $map_link = fmc_get_page_url(SOCIALFEEDS) . '?latitude='
                . $map_link->latitude
                . '&amp;longitude='
                . $map_link->longitude
                . '&amp;id=' . $post_social_id
                . '&amp;' . COUNTRY . '=' . $country
                . '&amp;location=' . $section_title;
        ;
    }

    //Grow number of block
    if ($num_img) {
        $j++;
    }
    /**
     * Base on number of images in a section to get the correct section layout
     * There are 5 layout sections for 1, 2, 3, 4, 5 images for each case
     */
    switch ($num_img) {
        case 1:
            include $template_path . '/inc/post-details/block-1-image.php';
            break;
        case 2:
            include $template_path . '/inc/post-details/block-2-image.php';
            break;
        case 3:
            include $template_path . '/inc/post-details/block-3-image.php';
            break;
        case 4:
            include $template_path . '/inc/post-details/block-4-image.php';
            break;
        case 5:
            include $template_path . '/inc/post-details/block-5-image.php';
            break;
        default:
            break;
    }
}

/** Other posts */
$wp_count_post = wp_count_posts();
if ($wp_count_post->publish > 1) {
    include $template_path . '/inc/post-details/other-posts.php';
}
?>
<style type="text/css">
    #loading{ display:none; }
</style>
<?php
get_footer();
