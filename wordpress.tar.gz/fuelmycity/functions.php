<?php
$template_path = get_template_directory();
include_once $template_path . '/inc/constants.php';
include_once $template_path . '/inc/debug/debug.php';
include_once $template_path . '/inc/custom-field-suite/add-custom-fields.php';
include_once $template_path . '/inc/ajax-functions.php';
include_once $template_path . '/inc/functions.php';
include_once $template_path . '/inc/class-carousel-post-type.php';
include_once $template_path . '/inc/class-social-share-post-type.php';
include_once $template_path . '/inc/class-config-post-type.php';
include_once $template_path . '/inc/class-custom-page.php';
include_once $template_path . '/inc/custom-user-profiles.php';

