<?php



get_header(); ?>
<div class="prize-block bgd-dark">
    <div style="max-width:970px;margin:0 auto 20px auto;">
        <h1><?php _e('404_key1', FMC); ?></h1>
        <p><h3><?php _e("404_key2", FMC); ?></h3></p>
    </div>
</div>
<?php
get_footer();