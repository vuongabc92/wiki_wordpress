<?php
    $country = get_country_current_site();

?>
<header id="header" data-scrolling="" data-dropdown=".navbar-toggle" data-target=".navbar-collapse">
    <div class="navbar-header">
        <a href="<?php echo fmc_get_page_url() ; ?>" title="<?php _e('Caltex FuelMyCity', FMC); ?>" class="logo">
            <img src="<?php echo get_template_directory_uri(); ?>/images/logo-caltex-small.png" alt="<?php _e('Caltex', FMC); ?>"/>
        </a>
        <button type="button" class="navbar-toggle"><span class="icon-bar"></span></button>
    </div>
    <nav class="navbar-collapse">
        <ul class="main-nav">
            <li <?php fmc_print_active_class(JOURNEYS, JOURNEY); ?>>
                <a href="<?php echo fmc_get_page_url(JOURNEYS) ; ?>" title="<?php _e('Journeys', FMC); ?>">
                    <span class="text"><?php _e('Journeys', FMC); ?></span>
                </a>
                <ul class="sub-nav visible-xs">
                    <?php
                    $kol_users = get_user_nav(LIMIT_KOL_SUBMENU);
                    if (count($kol_users)) {
                        foreach ($kol_users as $kol) :
                            $filter_post_url = fmc_get_page_url(JOURNEYS) . '?kol-user=' . $kol->ID ;
                            ?>
                            <li>
                                <a href="<?php echo $filter_post_url; ?>" title="<?php echo $kol->display_name; ?>">
                                    <span class="text"><?php echo $kol->display_name; ?></span>
                                </a>
                            </li>
                            <?php
                        endforeach;
                    }
                    ?>
                </ul>
                <a href="<?php echo fmc_get_page_url(JOURNEYS) ; ?>" title="<?php _e('Other roadtrippers', FMC); ?>" class="hidden-sm visible-xs order-link">
                    <span class="text"><?php _e('Other roadtrippers', FMC); ?></span>
                </a>
            </li>
            <li <?php fmc_print_active_class(SOCIALFEEDS); ?>>
                <a href="<?php echo fmc_get_page_url(SOCIALFEEDS) ; ?>" title="<?php _e('#fuelmycity', FMC); ?>">
                    <span class="text"><?php _e('#fuelmycity', FMC); ?></span>
                </a>
            </li>
            <li <?php fmc_print_active_class(PRIZES); ?>>
                <a href="<?php echo fmc_get_page_url(PRIZES) ; ?>" title="<?php _e('Contest', FMC); ?>">
                    <span class="text"><?php _e('Contest', FMC); ?></span>
                </a>
            </li>
            <li data-dropdown=".lang-selected" data-target=".dropdown-menu" class="langs">
                <?php include get_template_directory() . '/inc/language-dropdown.php'; ?>
            </li>
        </ul>
    </nav>
</header>