<?php
if ( ! function_exists('fmc_get_feeds')) {
    /**
     * AJAX!
     *
     * Get feeds with a limit number and page (option)
     *
     * @return json
     */
    function fmc_get_feeds() {
        $limit           = isset($_GET['limit'])  ? (int) $_GET['limit'] : 0;
        $page            = isset($_GET['page'])   ? (int) $_GET['page']  : 0;
        $feed_id         = isset($_GET['id'])     ? (int) $_GET['id']    : 0;
        $filter_kol      = (isset($_GET['kol_user']) && $_GET['kol_user'] == 'true') ? true : false;
        $filter_admin    = (isset($_GET['admin_user']) && $_GET['admin_user'] == 'true') ? true : false;
        $filter_publish  = (isset($_GET['publish'])  && $_GET['publish']   == 'true') ? true : false;
        $filter_location = (isset($_GET['location']) && $_GET['location'] == 'true') ? true : false;
        $next_page       = $page + 1;
        $offset          = $limit * $page;
        $filter_query    = false;
        $paging_url      = '';

        if ($filter_publish && $filter_location) {
            $filter_query = array(
                array(
                    'key'     => SF_IS_KOL,
                    'value'   => FMC_Social_Feed_Constant::NOT_KOL_USER,
                    'compare' => '=',
                ),
                array(
                    'key'     => SF_LOCATION,
                    'value'   => '',
                    'compare' => '!=',
                )
            );
            $paging_url = '&publish=true&location=true';
        } elseif ($filter_kol && $filter_location) {
            $filter_query = array(
                array(
                    'key'     => SF_IS_KOL,
                    'value'   => FMC_Social_Feed_Constant::KOL_USER,
                    'compare' => '=',
                ),
                array(
                    'key'     => SF_LOCATION,
                    'value'   => '',
                    'compare' => '!=',
                ),
            );
            $paging_url = '&kol_user=true&location=true';
        } elseif($filter_admin && $filter_location){
            $filter_query = array(
                array(
                    'key'     => SF_IS_ADMIN,
                    'value'   => FMC_Social_Feed_Constant::ADMIN_USER,
                    'compare' => '=',
                ),
                array(
                    'key'     => SF_LOCATION,
                    'value'   => '',
                    'compare' => '!=',
                )
            );
            $paging_url = '&admin_user=true&location=true';
        }elseif($filter_admin){
            $filter_query = array(
                array(
                    'key'     => SF_IS_ADMIN,
                    'value'   => FMC_Social_Feed_Constant::ADMIN_USER,
                    'compare' => '=',
                )
            );
            $paging_url = '&admin_user=true&location=true';
        } elseif ($filter_publish) {
            $filter_query = array(
                array(
                    'key'     => SF_IS_KOL,
                    'value'   => FMC_Social_Feed_Constant::NOT_KOL_USER,
                    'compare' => '=',
                )
            );
            $paging_url = '&publish=true';
        } elseif ($filter_kol) {
            $filter_query = array(
                array(
                    'key'     => SF_IS_KOL,
                    'value'   => FMC_Social_Feed_Constant::KOL_USER,
                    'compare' => '=',
                ),
            );
            $paging_url = '&kol_user=true';
        }
        /* 360 > 720 > ...
        if (is_array($filter_query)) {
            $limit *= $page;
            $offset = 0;
        }*/

        //Get lastest feeds
        $args = array(
            'post_type'         => FMC_Social_Feed_Constant::POST_TYPE,
            'posts_per_page'    => $limit,
            'offset'            => $offset,
            'post_status'       => array('publish'),
            'orderby'           => 'meta_value_num',
            'meta_key'          => SF_CREATED_TIMESTAMP,
            'order'             => 'DESC'
        );

        if (is_array($filter_query)) {
            $args['meta_query'] = $filter_query;
        }

        /** Set args to get specify feed */
        if ($feed_id) {
            $args = array(
                'p'                 => $feed_id,
                'post_type'         => FMC_Social_Feed_Constant::POST_TYPE,
                'posts_per_page'    => 1,
                'post_status'       => array('publish'),
            );
        }


        $query          = new WP_Query($args);
        $args['offset'] = $limit * $next_page;
        $next_query     = new WP_Query($args);
        $feeds_paging   = admin_url("admin-ajax.php?action=get_feeds&limit=" . FEED_LIMIT
                                                                             . "&publish=true&page={$next_page}{$paging_url}");
        $response       = array(
            'status' => AJAX_OK,
            'data'   => array(),
            'paging' => ($next_query->post_count) ? $feeds_paging : '',
        );

        if ($feed_id) {
            unset($response['paging']);
        }

        if ($query->have_posts()) {
            while($query->have_posts()) { $query->the_post();
                $sf_id              = get_post_meta(get_the_ID(), SF_ID, true);
                $feed_img           = get_post_meta(get_the_ID(), SF_PICTURE, true);
                $feed_video         = get_post_meta(get_the_ID(), SF_VIDEO, true);
                $feed_type          = get_post_meta(get_the_ID(), SF_TYPE, true);
                $from_avatar_url    = get_post_meta(get_the_ID(), SF_FROM_AVATAR, true);
                $from_name          = get_post_meta(get_the_ID(), SF_FROM_NAME, true);
                $social_type        = get_post_meta(get_the_ID(), SF_SOCIAL_TYPE, true);
                $location           = get_post_meta(get_the_ID(), SF_LOCATION, true);
                $location_name      = get_post_meta(get_the_ID(), SF_LOCATION_NAME, true);
                $created_at         = new \DateTime(get_post_meta(get_the_ID(), SF_CREATED_AT, true));
                $feed_text_limit    = ('' !== $feed_img && false !== $feed_img) ? FEED_GIRD_LIMIT_NUM : FEED_POPUP_LIMIT_NUM;
                $short_desc         = mb_substr(get_the_content(), 0, $feed_text_limit, 'utf-8');
                $full_desc          = get_the_content();

                $feed = array(
                    'id'                => get_the_ID(),
                    'post-image'        => $feed_img,
                    'post-video'        => "",
                    'short-description' => (strlen($full_desc) > FEED_GIRD_LIMIT_NUM) ? $short_desc . '...' : $short_desc,
                    'full-description'  => $full_desc,
                    //'user-image'        => $from_avatar_url,
                    'user-name'         => $from_name,
                    'feed-time'         => $created_at->format('Y/m/d h:i:s'),
                    'social-name'       => $social_type,
                    'location'          => (false !== $location && '' !== $location ) ? json_decode($location) : '',
                    'type'              => "",
                    'establish-name'    => "",
                    'establish-address' => "",
                    'establish-phone'   => "",
                    'establish-time'    => "",
                );

                if ($feed_type === 'image') {
                    $feed['type'] = 'image';
                }

                if ($feed_type === 'video') {
                    $feed['type'] = 'video';
                    if ($social_type === FMC_Social_Feed_Constant::SF_TWITTER) {
                        $feed['post-video'] = $sf_id;
                    } else {
                        $feed['post-video'] = $feed_video;
                    }

                }

                if (false !== $location_name && '' !== $location_name) {
                    $feed['location-name'] = $location_name;
                }

                if ($filter_location) {
                    $feed = array(
                        'id'        => get_the_ID(),
                        'location'  => (false !== $location && '' !== $location ) ? json_decode($location) : '',
                    );
                }

                $response['data'][] = $feed;
            }
        }
        wp_reset_query();

        echo json_encode($response);
        wp_die();
    }

    add_action("wp_ajax_nopriv_get_feeds", "fmc_get_feeds");
    add_action("wp_ajax_get_feeds", "fmc_get_feeds");
}

if ( !function_exists('fmc_get_list_posts')) {
    /**
     * AJAX!
     * Get list posts when load more
     *
     * @global type $post
     *
     * @return json
     */
    function fmc_get_list_posts() {

        global $post;

        $page          = (isset($_GET['page'])) ? (int) $_GET['page'] : 0;
        $offset        = $page * POST_LIMIT;
        $next_page     = $page + 1;

        $posts         = fmc_get_posts_by_user_registed_date(POST_LIMIT, $offset);
        $posts_next    = fmc_get_posts_by_user_registed_date(POST_LIMIT, $next_page * POST_LIMIT);
        $filter_by_kol = '';
        if (isset($_GET['kol-user'])) {
            $kol_id        = (int) $_GET['kol-user'];
            $filter_by_kol = '&kol-user=' . $kol_id;
            $posts         = fmc_get_posts(FALSE, POST_LIMIT, $offset, $kol_id);
            $posts_next    = fmc_get_posts(FALSE, POST_LIMIT, $next_page * POST_LIMIT, $kol_id);
        }
        $response    = array(
            'status' => AJAX_OK,
            'data'   => '',
            'url'    => (count($posts_next)) ? admin_url("admin-ajax.php?action=get_list_posts&page={$next_page}{$filter_by_kol}") : '',
        );
        if (count($posts)) :
            foreach ($posts as $post) :
                setup_postdata($post);
                $kol_id = get_post_meta(get_the_ID(), CFS_KOL_USER, true);
                if ($kol_id === '') {
                    $kol_id = get_the_author_meta('ID');
                }
                $cover_img    = wp_get_attachment_image_src(get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true), FEATURED_POST_THUMBNAIL);
                $author_post  = get_user_by('id', $kol_id);
                $display_name = $author_post->display_name;

                $response['data'][] = array(
                    'post-url'   => get_permalink(get_the_ID()),
                    'alt-image'  => get_the_title(),
                    'post-image' => (isset($cover_img[0])) ? $cover_img[0] : '',
                    'title'      => get_the_title(),
                    'user-name'  => $display_name
                );
            endforeach;
        endif;

        echo json_encode($response);
        wp_die();
    }

    add_action("wp_ajax_nopriv_get_list_posts", "fmc_get_list_posts");
    add_action("wp_ajax_get_list_posts"       , "fmc_get_list_posts");
}

if ( ! function_exists('fmc_save_rating')) {
    /**
     * AJAX!
     * Save rating
     *
     * @global type $post
     *
     * @return json
     */
    function fmc_save_rating() {

        if (!session_id()) {
            session_start();
        }
        if (isset($_POST['rating']) && isset($_POST['id'])) {

            $rate         = (int) $_POST['rating'];
            $id           = (int) $_POST['id'];
            $session_name = FMC_JOURNEY_RATING . $id;
            $journey      = get_post($id);

            if (NULL === $journey || (isset($_SESSION[$session_name])
                                     && $_SESSION[$session_name] === $id)) {
                echo json_encode(array(
                    'status' => AJAX_ERROR,
                    'data'   => __('Opp! Something went wrong.')
                ));
                wp_die();
            }

            $_SESSION[$session_name] = $id;

            $rating = get_post_meta($id, FMC_JOURNEY_RATING, true);
            $num_rated = 1;
            if (false !== $rating&& '' !== $rating) {
                $rating_decode   = json_decode($rating);
                $rating_decode[] = $rate;
                $num_rated = count($rating_decode);
                update_post_meta($id, FMC_JOURNEY_RATING, json_encode($rating_decode));
                $rate = round(array_sum($rating_decode)/count($rating_decode));
            } else {
                add_post_meta($id, FMC_JOURNEY_RATING, json_encode(array($rate)));
            }
            echo json_encode(array(
                'status' => AJAX_OK,
                'data' => $rate,
                'num_rated' => $num_rated
            ));
            wp_die();
        }
        wp_die();
    }

    add_action("wp_ajax_nopriv_save_rating", "fmc_save_rating");
    add_action("wp_ajax_save_rating"       , "fmc_save_rating");
}