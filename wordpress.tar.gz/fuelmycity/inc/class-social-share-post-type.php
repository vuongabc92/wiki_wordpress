<?php

/**
 * Register carousel post type
 */
class FMC_Social_Share_Post_Type {

    /**
     * @constructor
     */
    public function __construct() {
        add_action('init', array($this, 'fmc_register_social_share_post_type'));
    }

    /**
     * Register new post type
     */
    public function fmc_register_social_share_post_type() {

        $labels = array(
            'name' => __('Social Share'),
            'singular_name' => __('Social Share'),
            'menu_name' => __('Social Share'),
            'name_admin_bar' => __('Social Share'),
            'add_new' => __('Add New'),
            'add_new_item' => __('Add New Social Share'),
            'new_item' => __('New Social Share'),
            'edit_item' => __('Edit Social Share'),
            'view_item' => __('View Social Share'),
            'all_items' => __('All Social Share'),
            'search_items' => __('Search Social Share'),
            'parent_item_colon' => __('Parent Social Share:'),
            'not_found' => __('No Social share found.'),
            'not_found_in_trash' => __('No Social share found in Trash.')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => FMC_Social_Share::SOCIAL_SHARE_POST_TYPE),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'map_meta_cap' => true,
            //Only admin can control this post type
            'capabilities' => array(
                'edit_post'          => 'update_core',
                'read_post'          => 'update_core',
                'delete_post'        => 'update_core',
                'edit_posts'         => 'update_core',
                'edit_others_posts'  => 'update_core',
                'publish_posts'      => 'update_core',
                'read_private_posts' => 'update_core'
            ),
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt')
        );

        register_post_type( FMC_Social_Share::SOCIAL_SHARE_POST_TYPE, $args );
    }

}
$social_share = new FMC_Social_Share_Post_Type();