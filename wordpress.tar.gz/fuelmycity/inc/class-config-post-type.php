<?php

/**
 * Register config post type
 */
class FMC_Config_Post_Type {

    /**
     * @constructor
     */
    public function __construct() {
        add_action('init', array($this, 'fmc_register_config_post_type'));
        add_action('init', array($this, 'fmc_remove_unsupport_from_post_type'));
        add_filter( 'post_row_actions', array($this, 'fmc_remove_trash_link'), 10, 1 );
        add_action('admin_head', array($this, 'fmc_hide_move_to_trash'));
        add_action('admin_head', array($this, 'fmc_disable_config_new_posts'));
    }

    /**
     * Register new post type
     */
    public function fmc_register_config_post_type() {

        $labels = array(
            'name' => __('FMC Config'),
            'singular_name' => __('fmc-config'),
            'menu_name' => __('FMC Config'),
            'name_admin_bar' => __('FMC Config'),
            'add_new' => __('Add New'),
            'add_new_item' => __('Add New Config'),
            'new_item' => __('New FMC Config'),
            'edit_item' => __('Edit FMC Config'),
            'view_item' => __('View FMC Config'),
            'all_items' => __('All FMC Config'),
            'search_items' => __('Search FMC Config'),
            'parent_item_colon' => __('Parent FMC Config:'),
            'not_found' => __('No FMC Config found.'),
            'not_found_in_trash' => __('No FMC Config found in Trash.')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => FMC_CONFIG_POST_TYPE),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'map_meta_cap' => true,
            //Only admin can control this post type
            'capabilities' => array(
                'edit_post'          => 'update_core',
                'read_post'          => 'update_core',
                'delete_post'        => 'update_core',
                'edit_posts'         => 'update_core',
                'edit_others_posts'  => 'update_core',
                'publish_posts'      => 'update_core',
                'read_private_posts' => 'update_core'
            ),
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt')
        );

        register_post_type( FMC_CONFIG_POST_TYPE, $args );
    }

    /**
     * Remove unneccessary support
     */
    public function fmc_remove_unsupport_from_post_type() {
        //remove_post_type_support( CAROUSEL_POST_TYPE, 'title' );
        remove_post_type_support( FMC_CONFIG_POST_TYPE, 'editor' );
        remove_post_type_support( FMC_CONFIG_POST_TYPE, 'excerpt' );
        remove_post_type_support( FMC_CONFIG_POST_TYPE, 'author' );
        //For posts (articles)
        remove_post_type_support( 'post', 'editor' );
    }

    /**
     * Remove unneccessary action in list post type
     *
     * @param array $actions
     *
     * @return array
     */
    public function fmc_remove_trash_link( $actions ) {
        if( get_post_type() === FMC_CONFIG_POST_TYPE ) {
            unset( $actions['trash'] );
            unset( $actions['view'] );
            unset($actions['inline hide-if-no-js']);
        }

        return $actions;
    }

    /**
     * Hide move to trash link when edit carousel
     *
     * @global type $post
     */
    public function fmc_hide_move_to_trash() {
        $post_type = FMC_CONFIG_POST_TYPE;
        if (get_post_type() == $post_type) {
            echo '
                <style type="text/css">
                    #delete-action, .tablenav{
                        display:none;
                    }
                </style>
            ';
        }
    }

    /**
     * Hide add new
     *
     * @global type $submenu
     */
    public function fmc_disable_config_new_posts() {
        global $submenu;

        if ((isset($_GET['post_type']) && $_GET['post_type'] == FMC_CONFIG_POST_TYPE)
                                       || get_post_type()    == FMC_CONFIG_POST_TYPE) {
            //unset($submenu["edit.php"][10]);
            /*echo '<style type="text/css">
                    #favorite-actions, .add-new-h2, .tablenav { display:none; }

                  </style>';*/
        }
    }

    /**
     * Get list carousel src
     *
     * @return type
     */
    public function fmc_get_carousel111() {
        //Get carousel post
        $agrs = array(
            'post_type'     => 'carousel',
            'post_per_page' => -1,
        );
        $carousel_query  = new WP_Query($agrs);
        $carousel        = $carousel_query->posts;
        $carousel_slides = array();
        if ($carousel_query->post_count) {
            for($i = 1; $i <= CAROUSEL_NUM; $i++) {
                $attachment_id = get_post_meta($carousel[0]->ID, constant('CFS_CAROUSEL_SLIDE_' . $i), true);
                $author        = get_post_meta($carousel[0]->ID, constant('CFS_SLIDE_' . $i . '_AUTHOR'), true);
                $title         = get_post_meta($carousel[0]->ID, constant('CFS_SLIDE_' . $i . '_TITLE'), true);
                $link          = get_post_meta($carousel[0]->ID, constant('CFS_SLIDE_' . $i . '_LINK'), true);
                $alt           = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                if ('' !== $attachment_id && false !== $attachment_id &&
                    '' !== $author && false !== $author &&
                    '' !== $title && false !== $title) {
                    $slide        = wp_get_attachment_image_src($attachment_id, CAROUSEL_POST_TYPE);
                    $one_carousel = array();
                    if (is_array($slide) && isset($slide[0])) {
                        $one_carousel = array(
                            'img'    => $slide[0],
                            'author' => $author,
                            'title'  => $title,
                            'link'   => ('' !== $link && false !== $link) ? $link : '',
                            'alt'    => ('' !== $alt && false !== $alt) ? $alt : ''
                        );
                    }

                    $carousel_slides[] = $one_carousel;
                }

            }
        }

        return $carousel_slides;
    }

    /**
     * get fmc config post type
     *
     * @return type
     */
    public function get_fmc_config() {

        $fmc_config = get_posts(array(
            'post_type' => FMC_CONFIG_POST_TYPE,
            'limit'     => 1,
            'type'      => array('publish'),
            'orderby'   => 'date',
            'order'     => 'DESC'
        ));

        return $fmc_config;
    }
}
$fmc_config_post_type = new FMC_Config_Post_Type();