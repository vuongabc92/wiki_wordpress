<?php

if ( !function_exists('sm_dump')) {

    /**
     * Dump a var and die
     *
     * @param type $data
     */
    function dd($data) {
        var_dump('<pre>', $data);
        die;
    }
}