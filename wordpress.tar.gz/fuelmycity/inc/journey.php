
<div class="col-sm-6">

    <a href="<?php echo get_permalink($post->ID) ?>"
       title="<?php the_title(); ?>" class="post-preview" <?php echo $higher; ?>>
        <?php
        if (fmc_check_detail_image($cover_img)) :
            ?>
            <div class="thumb">
                <img src="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_SMALL_JOURNEY); ?>" alt="<?php echo $alt; ?>"/>
            </div>
            <?php
        endif;
        ?>

        <div class="content">
            <h3 class="title"><?php the_title(); ?></h3>
            <div class="desc">
                <span class="name"><?php echo $display_name; ?></span>
<!--                <span class="year"><?php echo get_the_date('Y'); ?></span>-->
            </div>
        </div>
    </a>
</div>