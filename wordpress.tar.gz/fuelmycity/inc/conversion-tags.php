<?php

global $post;
$current_blog_id = get_current_blog_id();
$site_blog       = array_flip(FMC_Country::get_site_blog());
$file_name       = strtolower($site_blog[$current_blog_id] . '.html');

if ($post->post_name === PRIZES) {
    $file_name = strtolower($site_blog[$current_blog_id] . '-contest.html');
    include_once get_template_directory() . '/inc/conversion-tags/' . $file_name;
}

if (is_front_page()) {
    $file_name = strtolower($site_blog[$current_blog_id] . '.html');
    include_once get_template_directory() . '/inc/conversion-tags/' . $file_name;
}

