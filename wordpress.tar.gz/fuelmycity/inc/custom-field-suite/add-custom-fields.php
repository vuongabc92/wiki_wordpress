<?php
/**
 * Register a new custom field
 * KOL select box include list kol user
 *
 * @param array $field_types
 * @return string
 */
function kol_select($field_types)
{
    $field_types['kol_select'] = get_template_directory() . '/inc/custom-field-suite/class-kol-select.php';

    return $field_types;
}
add_filter('cfs_field_types', 'kol_select');