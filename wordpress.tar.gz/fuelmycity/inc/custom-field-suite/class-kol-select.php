<?php
/**
 * Register a new custom field kol select that list
 * all kol user
 */
class cfs_kol_select extends cfs_field
{
    /**
     * @constructor
     */
    function __construct()
    {
        $this->name = 'kol_select';
        $this->label = __('KOL select', 'cfs');
    }

    /**
     * Build element html
     *
     * @param type $field
     */
    function html($field)
    {
        $multiple = '';
        // Multi-select
        if (isset($field->options['multiple']) && '1' == $field->options['multiple'])
        {
            $multiple = ' multiple';

            if (empty($field->input_class))
            {
                $field->input_class = 'multiple';
            }
            else
            {
                $field->input_class .= ' multiple';
            }
        }
        // Single-select
        elseif (!isset($field->input_class))
        {
            $field->input_class = '';
        }

        // Select boxes should return arrays (unless "force_single" is true)
        if ('[]' != substr($field->input_name, -2) && empty($field->options['force_single']))
        {
            $field->input_name .= '[]';
        }
        //$current_user = get_current_user_id();
        //$meta_country = get_user_meta($current_user, FMC_Country::USER_META_KEY, true);
        $user_args = array(
            'role' => 'kol'
        );
        /*if (null !== $meta_country && '' !== $meta_country) {
            $user_args['meta_key']   = FMC_Country::USER_META_KEY;
            $user_args['meta_value'] = $meta_country;
        }*/
        $users = get_users($user_args);


        $current_post   = new \stdClass();
        $current_post->post_author = 0;
        $disable        = '';
        $list_kol       = fmc_get_list_koluserid();
        if (isset($_GET['post'])) {
            $current_post = get_post($_GET['post']);
            if (in_array($current_post->post_author, $list_kol)) {
                $disable = 'disabled';
            }
        }
    ?>
        <select <?php echo $disable; ?> name="<?php echo $field->input_name; ?>" class="<?php echo $field->input_class; ?>"<?php echo $multiple; ?>>
            <option value="NONE"><?php _e('Select a KOL user to create post on behalf'); ?></option>
            <?php
                if(count($users)) {
                    foreach ($users as $user) {
                        $selected = '';
                        if ((int)$field->value === (int) $user->ID || (int) $current_post->post_author === (int) $user->ID) {
                            $selected = ' selected';
                        }
            ?>
            <option value="<?php echo esc_attr($user->ID); ?>" <?php echo $selected; ?>><?php echo esc_attr($user->user_login); ?></option>
            <?php
                    }
                }
            ?>
        </select>

        <!-- JS to add or remove html attribute for JS validation -->
        <script>
            (function($) {
                var selected = $('.<?php echo $field->input_class; ?>').find(":selected");
                if (selected.val() !== 'NONE') {
                    $('.field-<?php echo CFS_KOL_USER; ?>').attr('data-validator', '');
                }
                $('.<?php echo $field->input_class; ?>').on('click', function(){
                    var val = $(this).val();
                    if (val === 'NONE') {
                        $('.field-<?php echo CFS_KOL_USER; ?>').attr('data-validator', 'required');
                    } else {
                        $('.field-<?php echo CFS_KOL_USER; ?>').attr('data-validator', '');
                    }
                });
            })(jQuery);
        </script>
    <?php
    }

}
