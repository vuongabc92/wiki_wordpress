<?php
    $country = fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());
?>
<footer id="footer">
    <div class="grid-fluid">
        <div class="row">
            <div class="col-sm-3">
                <a href="<?php echo fmc_get_page_url() ; ?>" title="<?php _e('Caltex FuelMyCity', FMC); ?>" class="logo-caltex-medium">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/logo-caltex-medium.png" alt="<?php _e('Caltex', FMC); ?>"/>
                </a>
            </div>
            <div class="col-sm-3">
                <ul class="nav">
                    <li><a href="<?php echo fmc_get_page_url(JOURNEYS) ; ?>" title="<?php _e('Journeys', FMC); ?>"><?php _e('Journeys', FMC); ?></a>
                    </li>
                    <li><a href="<?php echo fmc_get_page_url(SOCIALFEEDS) ; ?>" title="<?php _e('#fuelmycity', FMC); ?>"><?php _e('#fuelmycity', FMC); ?></a>
                    </li>
                    <li><a href="<?php echo fmc_get_page_url(PRIZES) ; ?>" title="<?php _e('Contest', FMC); ?>"><?php _e('Contest', FMC); ?></a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-6">
                <ul class="social">
                    <li>
                        <a href="/" title="<?php _e('Twitter', FMC); ?>"
                            class="icon-twitter"
                            data-text="<?php echo urlencode(fmc_get_social_share($country, 'tw')); ?>"
                            data-share="twitter"
                            data-on-footer="true"><?php _e('Twitter', FMC); ?></a>
                    </li>
                    <li>
                        <a href="/" title="<?php _e('Facebook', FMC); ?>"
                            class="icon-fb" data-share="facebook"
                            data-bitly-link="<?php echo home_url(); ?>"
                            data-text="<?php echo fmc_get_social_share($country, 'fb'); ?>"
                            data-img="<?php echo get_template_directory_uri() ?>/images/logo-slider.png"
                            data-caption=""><?php _e('Facebook', FMC); ?></a>
                    </li>
<!--                    <li>
                        <a href="/" title="<?php _e('Google +', FMC); ?>" class="icon-google" data-share-url="<?php echo home_url(); ?>" data-share="googleplus"><?php _e('Google +', FMC); ?> </a>
                    </li>-->
                    <li>
                        <a href="/" title="<?php _e('Top', FMC); ?>" class="sroll-top" data-back-to-top="">
                            <span class="text"><?php _e('Top', FMC); ?></span>
                            <span class="icon-up"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="copyright">
            <div class="nav-bottom">
                <a href="http://www.caltex.com/global/" title="<?php _e('Caltex Worldwide', FMC); ?>"><?php _e('Caltex Worldwide', FMC); ?></a>
                <a href="https://www.caltex.com/global/contact-us/" title="<?php _e('Contact Us', FMC) ?>"><?php _e('Contact Us', FMC) ?></a>
            </div>
            <!--<a target="_blank" href="http://www.caltex.com/sg/terms-of-use" title="<?php _e('Terms Of Use', FMC); ?>"><?php _e('Terms Of Use', FMC); ?></a>-->
            <div class="corporation">
                <a target="_blank" href="<?php echo fmc_get_page_url(TERMS) ; ?>" title="<?php _e('Terms Of Use', FMC); ?>"><?php _e('Terms Of Use', FMC); ?></a>
                <a target="_blank" href="http://www.chevron.com/privacystatement/" title="<?php _e('Privacy Statement', FMC); ?>"><?php _e('Privacy Statement', FMC); ?></a>
                <span>&#169; <?php _e('2015 Chevron Corporation.', FMC); ?></span>
                <span><?php _e('All Rights Reserved.', FMC); ?></span>
            </div>
        </div>
    </div>
</footer>
