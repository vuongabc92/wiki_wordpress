<?php
$cover_img_id = get_post_meta($article->ID, CFS_COVER_IMG, TRUE);
$rating_json  = get_post_meta($article->ID, FMC_JOURNEY_RATING, TRUE);
$kol_id       = get_post_meta($article->ID, CFS_KOL_USER, TRUE);
if (false === $kol_id || '' === $kol_id) {
    $kol_id = $article->post_author;
}
$cover_img       = wp_get_attachment_image_src($cover_img_id, POST_COVER_IMG_SIZE);
$alt             = get_post_meta($cover_img_id, '_wp_attachment_image_alt', true);
$youtube         = get_post_meta($article->ID, FMC_YOUTUBE_URL, TRUE);
$article_title   = $article->post_title;
$nickname        = get_user_meta($kol_id, 'nickname', true);
$avatar_url      = get_kol_avatar($kol_id, 481);
$kol_desc        = get_user_meta($kol_id, 'description', true);
$desc_trans      = icl_translate('Authors', 'description_' . $kol_id, $kol_desc);
$desc_trans      = nl2br($desc_trans);

$social_kol_desc = get_user_meta($kol_id, 'kol_social_desc', true);
?>
<figure class="cover-block">
    <div class="thumb">
        <?php if (fmc_check_detail_image($cover_img)) : ?>
            <img src="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_DETAILS_COVER); ?>" alt="<?php echo $alt; ?>"/>
        <?php endif; ?>
    </div>
    <figcaption data-popup="personDetail" data-id-popup="person-popup">
        <a href="javascript:;"
           title="<?php echo $nickname; ?>"
           class="author col-md-offset-1 col-lg-offset-0"
           data-detail-img="<?php echo $avatar_url; ?>"
           data-detail-name="<?php echo $nickname; ?>"
           data-detail-decs="<?php echo $desc_trans; ?>"
           data-text-btn="<?php _e('View journey', FMC) ?>"
           data-link-btn="<?php echo fmc_get_page_url(JOURNEYS) . '?kol-user=' . $kol_id  ?>">
            <span class="avatar">
                <img src="<?php echo $avatar_url; ?>" alt="<?php _e('avatar', FMC); ?>"/>
            </span>
            <span class="text"><?php echo $nickname; ?></span>
        </a>
        <h2 class="col-sm-offset-2 title"><?php echo $article->post_title; ?></h2>
    </figcaption>
</figure>
<div class="share-block">
    <div class="grid-fluid">
        <div class="row">
            <div class="col-sm-9 col-sm-offset-2 col-xs-offset-1">
                <div class="share-group">
                    <span class="share">
                        <?php _e('Share', FMC); ?>
                    </span>
                    <a href="#" data-share="facebook" title="<?php _e('Facebook', FMC); ?>" class="icon-fb"
                       data-bitly-link="<?php echo home_url(); ?>"
                       data-text="<?php echo $social_kol_desc; ?>"
                       data-img="<?php echo get_template_directory_uri() ?>/images/logo-slider.png"
                       data-caption=""><?php _e('Facebook', FMC); ?></a><a href="#" data-share="twitter" title="<?php _e('Twitter', FMC); ?>" class="icon-twitter"
                       data-text="<?php _e('Check out', FMC) ?> <?php echo $nickname; ?><?php _e("'s journey around ", FMC) ?> <?php echo $kol_city; ?> <?php _e("at", FMC) ?> <?php echo home_url(); ?>"
                       data-kol="<?php echo $nickname; ?>"
                       data-city="<?php echo $kol_city; ?>"
                       data-bitly-link="<?php echo home_url(); ?>"
                       data-hash-tags="caltex,fuelmycity"
                       data-on-footer=""><?php _e('Twitter', FMC); ?></a>
                </div>
                <span data-rating="span" data-id="<?php echo isset($_GET['id']) ? (int) $_GET['id'] : 0; ?>" class="star">
                    <?php
                    $num_star = 5;
                    $rating = 0;
                    if (false !== $rating_json && '' != $rating_json) {
                        $rating_arr = json_decode($rating_json);
                        $rating = round(array_sum($rating_arr) / count($rating_arr));
                    }
                    echo str_repeat('<span class="active"></span>', $rating);
                    echo str_repeat('<span></span>', $num_star - $rating);
                    ?>
                </span><a href="javascript:;" title="<?php _e('Down', FMC); ?>" class="icon-down circle-icon small-icon" data-scroll-to="#post-details-1"><?php _e('Down', FMC); ?></a>
            </div>
        </div>
    </div>
</div>
<?php
if ($youtube !== false && $youtube !== '') :
    ?>
    <div class="video-block">
        <div class="grid-fluid">
            <div class="row">
                <div class="col-md-8 col-md-offset-3 col-sm-12">
                    <div class="embed-responsive">
                        <iframe src="<?php echo YOUTUBE_EMBED_URL . $youtube; ?>" frameborder="0" allowfullscreen class="embed-responsive-item"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
endif;