<div id="post-details-4" class="post-details-block block-4 <?php echo $white_state; ?>" <?php echo $backroud_style; ?> >
    <div class="grid-fluid">
        <div class="row">
            <div class="col-md-1 col-md-offset-2 col-sm-2 col-sm-offset-1 col-xs-2 col-xs-offset-1">
                <div class="order-wrap"><span class="order"><span><?php echo $j; ?></span></span></div>
            </div>
            <div class="col-sm-9 col-xs-9">
                <h2 class="heading-1" >
                    <?php
                    if (false !== $map_link) :
                        ?>
                        <a href="<?php echo $map_link; ?>" title="<?php _e('View on map', FMC); ?>" class="title-box">
                            <?php echo $section_title; ?>
                        </a>
                        <?php
                    else :
                        ?>
                        <span><?php echo $section_title; ?></span>
                    <?php
                    endif;
                    ?>
                </h2>
            </div>
        </div>
        <div class="row post-details-images">
            <?php
            if (fmc_check_detail_image($section_img1)) :
                ?>
                <div class="col-sm-4 col-md-offset-1">
                    <figure>
                        <img src="<?php echo fmc_get_default_image($section_img1[0], DEFAUT_DETAILS_S2_IMG1, 2); ?>" alt="<?php echo $section_img1['alt']; ?>"/>
                        <?php if(!empty($attachment_metadata1["image_meta"]["caption"])){ ?>
                            <figcaption><?php echo $attachment_metadata1["image_meta"]["caption"] ?></figcaption>
                        <?php } ?>
                    </figure>
                </div>
            <?php endif; ?>
            <?php if (fmc_check_detail_image($section_img2)) : ?>
                <div class="col-md-7 col-sm-8 hidden-xs">
                    <figure>
                        <img src="<?php echo fmc_get_default_image($section_img2[0], DEFAUT_DETAILS_S2_IMG2, 2) ?>" alt="<?php echo $section_img2['alt']; ?>"/>
                        <?php if(!empty($attachment_metadata2["image_meta"]["caption"])){ ?>
                            <figcaption><?php echo $attachment_metadata2["image_meta"]["caption"] ?></figcaption>
                        <?php } ?>
                    </figure>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-sm-offset-3 col-sm-6">
                <p class="address"><?php echo $location_address; ?></p>
            </div>
            <div class="col-sm-3 col-md-2">
                <?php
                if (false !== $map_link) :
                    ?>
                    <a href="<?php echo $map_link; ?>" title="<?php _e('View on map', FMC); ?>"
                       class="map-link"><span class="arrow">&gt;</span><?php _e('View on map', FMC); ?></a>
                    <?php
                endif;
                ?>
            </div>
        </div>
        <div class="row desciption-top">
            <div class="col-md-8 col-sm-offset-3 col-sm-9">
                <?php echo $section_text1; ?>
            </div>
        </div>
    </div>
</div>