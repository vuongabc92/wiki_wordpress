<?php
global $post;

$other_posts = fmc_get_posts(false, 3, 0, 0, $article_id);
$i           = 0;
if (count($other_posts)) :
    ?>
    <div class="posts-block other-posts">
        <div class = "grid-fluid">
            <div class = "row heading">
                <div class = "col-sm-5">
                    <h2 class = "title"><?php _e('Other posts', FMC);?></h2>
                    <div class="tags"><span><?php _e('#Caltex', FMC); ?></span><span><?php _e('#Fuelmycity', FMC); ?></span></div>
                </div>
            </div>
            <div class="post-list">
                <div class="row">
                    <div class="col-md-12">
                    <?php
                    foreach ($other_posts as $post) :
                        $i++;
                        setup_postdata($post);
                        $cover_img = wp_get_attachment_image_src(get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true), FEATURED_POST_THUMBNAIL);
                        $alt       = get_post_meta(get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true), '_wp_attachment_image_alt', true);
                        $kol_id    = get_post_meta(get_the_ID(), CFS_KOL_USER, true);
                        if ($kol_id === '') {
                            $kol_id = get_the_author_meta('ID');
                        }
                        $author_post  = get_user_by('id', $kol_id);
                        $display_name = $author_post->display_name;
                        $higher   = '';
                        if ($i % 2 === 0) {
                            $higher = ' data-animate-scroll="data-animate-scroll"';
                        }
                        ?>

                                <div class="col-item-<?php echo ($i > 2) ? '2' : '1'; ?>">
                                    <!--<a href="<?php echo fmc_get_page_url(JOURNEY) . '?id=' . get_the_ID() ; ?>" title="<?php the_title(); ?>" class="post-preview">-->
                                        <a href="<?php echo get_permalink($post->ID) ?>" title="<?php the_title(); ?>" class="post-preview">
                                        <?php
                                        if (fmc_check_detail_image($cover_img)) :
                                            ?>
                                            <div class="thumb">
                                                <img src="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_SMALL_JOURNEY); ?>" alt="<?php echo $alt; ?>"/>
                                            </div>
                                            <?php
                                        endif;
                                        ?>
                                        <div class="content">
                                            <h3 class="title"><?php the_title(); ?></h3>
                                            <div class="desc">
                                                <span class="name"><?php echo $display_name; ?></span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                        <?php
                    endforeach;
                    ?>
                        </div>
                </div>
            </div>
            <div class="button-wrap-1">
                <a href="<?php echo fmc_get_page_url(JOURNEYS); ?>" title="<?php _e('Meet more road-trippers', FMC); ?>" class="button-style button-white-style">
                    <span class="text"><?php _e('Meet more road-trippers', FMC); ?></span>
                    <span class="arrow-right"></span>
                </a>
            </div>
        </div>
    </div>
    <?php
endif;
?>