<?php

/**
 * Register carousel post type
 */
class FMC_Prize_Post_Type {

    /**
     * @constructor
     */
    public function __construct() {
        add_action('init', array($this, 'fmc_register_prize_post_type'));
    }

    /**
     * Register new post type
     */
    public function fmc_register_prize_post_type() {

        $labels = array(
            'name' => __('Prize'),
            'singular_name' => __('Prizes'),
            'menu_name' => __('Prizes'),
            'name_admin_bar' => __('Prizes'),
            'add_new' => __('Add Prize'),
            'add_new_item' => __('Add New Prize'),
            'new_item' => __('New Prize'),
            'edit_item' => __('Edit Prize'),
            'view_item' => __('View Prize'),
            'all_items' => __('All Prizes'),
            'search_items' => __('Search Prizes'),
            'parent_item_colon' => __('Parent Prize:'),
            'not_found' => __('No prize found.'),
            'not_found_in_trash' => __('No prize found in Trash.')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => FMC_Prizes::PRIZE_POST_TYPE),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'map_meta_cap' => true,
            //Only admin can control this post type
            'capabilities' => array(
                'edit_post'          => 'update_core',
                'read_post'          => 'update_core',
                'delete_post'        => 'update_core',
                'edit_posts'         => 'update_core',
                'edit_others_posts'  => 'update_core',
                'publish_posts'      => 'update_core',
                'read_private_posts' => 'update_core'
            ),
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt')
        );

        register_post_type( FMC_Prizes::PRIZE_POST_TYPE, $args );
    }

}
$prize_post_type = new FMC_Prize_Post_Type();