<div id="loading" <?php echo (is_404() || fmc_get_current_page() === JOURNEYS) ? 'class="hidden"' : ''; ?>>
    <span class="loader"></span>
    <span class="loader"></span>
</div>
