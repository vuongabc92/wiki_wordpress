<?php
//$featured_posts = fmc_get_posts($is_featured = TRUE, FEATURED_POST_LIMIT, 0, 0, 0);
$featured_posts = get_home_posts();
$list_kol_user  = fmc_get_list_koluserid();
if (count($featured_posts) > 1) :
    ?>

    <div class="posts-block">
        <div class="grid-fluid">
            <div class="row heading">
                <div class="col-xs-9 col-sm-4 col-md-3 ct-heading">
                    <h2 class="title"><?php _e('A Journey', FMC) ?><br class="hidden-xs"><?php _e('of discovery around asia', FMC); ?></h2>
                </div>
                <div class="col-md-offset-1 col-md-8 col-sm-8 col-xs-12">
                    <p class="desc"><?php _e('At Caltex, we don’t just fuel vehicles – we fuel people too, by inspiring them to see their cities in ways they never have before.', FMC); ?> </p>
                    <p class="desc"><?php _e('That’s why we’ve selected four popular Instagram personalities to show us their idea of a fun road trip in Singapore. Explore their favourite hangouts, live vicariously through their exciting activities, and discover the city’s secret spots. So you, too, can be inspired to experience Singapore in a new way.', FMC); ?></p>
                </div>
            </div>
            <div class="post-list">
                <?php
                $row_num = count($featured_posts) > 2 ? 2 : 1;
                $i       = 1;
                for ($j = 1; $j <= $row_num; $j++) :
                    ?>
                    <div class="row <?php echo ($j === 2) ? 'hidden-xs' : ''; ?>">
                        <?php
                        for ($z = 1; $z <= 2; $z++) :
                            global $post;
                            if (count($featured_posts) - $i >= 0) :
                                $post = $featured_posts[$i - 1];
                                setup_postdata($post);
                                $higher = '';
                                if ($i % 2 === 0) {
                                    $higher = ' data-animate-scroll="data-animate-scroll"';
                                }
                                $cover_img = wp_get_attachment_image_src(get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true), FEATURED_POST_THUMBNAIL);
                                $kol_id = get_post_meta(get_the_ID(), CFS_KOL_USER, true);
                                if ($kol_id === '') {
                                    $kol_id = get_the_author_meta('ID');
                                }
                                $author_post  = get_user_by('id', $kol_id);
                                $display_name = $author_post->display_name;
                                $alt          = get_post_meta(get_post_meta(get_the_ID(), CFS_SMALL_COVER_IMG, true), '_wp_attachment_image_alt', true);
                                ?>
                                <div class="col-sm-6">

                                    <a href="<?php echo get_permalink() ?>" title="<?php the_title(); ?>" class="post-preview" <?php echo $higher; ?>>
                                        <?php
                                            if (fmc_check_detail_image($cover_img)) :
                                        ?>
                                        <div class="thumb">
                                            <img src="<?php echo fmc_get_default_image($cover_img[0], DEFAUT_SMALL_JOURNEY); ?>" alt="<?php echo $alt; ?>"/>
                                        </div>
                                        <?php
                                            endif;
                                        ?>
                                        <div class="content">
                                            <h3 class="title"><?php the_title(); ?></h3>
                                            <div class="desc">
                                                <span class="name"><?php echo $display_name; ?></span>
<!--                                                <span class="year"><?php echo get_the_date('Y'); ?></span>-->
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php
                            endif;
                            $i++;
                        endfor;
                        ?>
                    </div>
                    <?php
                endfor;
                ?>
            </div>
            <div class="button-wrap-1">
                <a href="<?php echo fmc_get_page_url(JOURNEYS) ?>" title="<?php _e('See all', FMC); ?>" class="button-style">
                    <span class="text"><?php _e('Meet more road-trippers', FMC); ?></span>
                    <span class="arrow-right"></span>
                </a>
            </div>
        </div>
    </div>
    <?php
endif; ?>