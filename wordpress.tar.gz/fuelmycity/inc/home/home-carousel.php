<?php
$country  = fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());
$carousel = $carousel_post_type->fmc_get_carousel();
?>
<div class="main-slider main-slider-ct">
    <div class="group-sliders">
        <div data-home-slider="" class="sliders">
            <?php
            if (count($carousel)) :
                foreach ($carousel as $one) :
                    $title      = $one['title']; //fmc_break_carousel_text($one['title']);
                    $author     = fmc_break_carousel_text($one['author']);
                    $randon_num = rand(1, 6);
                    ?>
                    <div class="item">
                        <figure>
                            <a <?php echo ('' !== $one['link']) ? 'href="' . $one['link'] . '"' : ''; ?> class="thumb">
                                <img src="<?php echo fmc_get_default_image($one['img'], DEFAUT_CAROUSEL); ?>" alt="<?php echo $one['alt']; ?>"/>
                            </a>
                        </figure>
                        <div class="box-banner">
                            <div class="wrap">
                                <div style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/bg_shape/<?php echo $randon_num; ?>_masthead_shapeBG.png)" class="inner bgd bgd-1">
                                    <h2><?php echo $author; ?></h2>
                                    <p><?php echo $title; ?></p>
                                    <a class="btn-read-more" <?php echo ('' !== $one['link']) ? 'href="' . $one['link'] . '"' : ''; ?>><?php echo _e('Read all about it', FMC); ?><i class="arrow"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                endforeach;
            endif;
            ?>
        </div>
        <a href="javascript:;" title="<?php _e('Down', FMC); ?>" class="icon-down circle-icon small-icon" data-scroll-to="#introduction-block"><?php _e('Down', FMC); ?></a>
    </div>
</div>