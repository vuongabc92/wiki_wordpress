<div id="introduction-block" style="background-image: url('<?php echo get_template_directory_uri() ?>/images/bgd-single-post.jpg')" class="introduction-block">
    <div class="grid-fluid">
        <div class="row">
            <h2 class="col-sm-offset-1 col-sm-11 title"><?php _e('A journey of discovery around asia.', FMC); ?></h2>
        </div>
        <div class="row">
            <div class="col-md-7 col-sm-offset-1">
                <blockquote class="description">
                    <?php _e('Join us we follow various personalities road-tripping in an around your city. Shining a light upon where they hangout and have fun. Pit-stopping at strange locations, cool eateries, underground gigs, shpping spots anf other secret venues in the city', FMC); ?>
                </blockquote>
            </div>
            <div class="col-md-4 col-sm-11 col-sm-offset-1 col-md-offset-0 text-center">
                <div class="button-wrap">
                    <a href="<?php echo fmc_get_page_url(ABOUT)  ?>" title="<?php _e('About', FMC) ?>" class="button-style button-white-style">
                        <span class="text"><?php _e('About', FMC) ?></span>
                        <span class="arrow-right"></span>
                    </a>
                    <a href="<?php echo fmc_get_page_url(PRIZES) ?>" title="<?php _e('Prizes', FMC) ?>" class="button-style button-white-style">
                        <span class="text"><?php _e('Prizes', FMC) ?></span>
                        <span class="arrow-right"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>