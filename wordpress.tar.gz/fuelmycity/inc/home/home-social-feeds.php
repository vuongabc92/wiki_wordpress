<div class="social-block bgd-red">
    <div data-social-feed="home-page" data-gridviewarea=".social-list" class="grid-fluid">
        <div class="heading white-state">
            <h2 class="title"><?php _e("#Fuelmycity", FMC) ?></h2>
            <div class="row">
                <div class="col-md-10 col-md-offset-1 info-desc">
                    <p class="desc"><?php _e('Join us as follow various personalities road-tripping in and around your city.', FMC); ?></p>
                    <div class="button-group">
                        <a href="<?php echo fmc_get_page_url(PRIZES) ; ?>" title="<?php echo _e('Social Feeds', FMC); ?>" class="button-style button-white-style">
                            <span class="text"><?php echo _e('Join the contest', FMC); ?></span>
                            <span class="arrow-right"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div data-popup="socialFeedDetail" data-id-popup="social-popup" class="row social-list">
            <div class="col-sm-10 col-sm-offset-1">
                <div class="row"></div>
            </div>
        </div>
        <div class="row button-wrap-2">
            <div class="col-md-10 col-md-offset-1 col-sm-9 col-sm-offset-2">
                <a href="<?php echo fmc_get_page_url(SOCIALFEEDS)  ?>" title="<?php _e('See more', FMC) ?>" class="button-style button-white-style">
                    <span class="text"><?php _e('See more', FMC) ?></span>
                    <span class="arrow-right"></span>
                </a>
            </div>
        </div>
    </div>
</div>

<?php
include get_template_directory() . '/inc/loading.php';
