<?php

class FMC_Custom_Page {

    public $post_type = 'page';

    public function __construct() {
        add_action('admin_head', array($this, 'fmc_hide_page_move_to_trash'));
        add_action('admin_head', array($this, 'fmc_disable_page_new_posts'));
    }

    /**
     * Hide page editor and title
     *
     * @global type $_wp_post_type_features
     */
    public function fmc_hide_page_editor() {
        global $_wp_post_type_features;

        $editor = 'editor';
        $title  = 'title';
        if (isset($_wp_post_type_features[$this->post_type])) {
            if (isset($_wp_post_type_features[$this->post_type][$editor])) {
                unset($_wp_post_type_features[$this->post_type][$editor]);
            }
            if (isset($_wp_post_type_features[$this->post_type][$title])) {
                unset($_wp_post_type_features[$this->post_type][$title]);
            }
        }
    }

    /**
     * Remove link move to trash in page edit content
     *
     * @global type $post
     * @param type $actions
     */
    public function fmc_hide_page_move_to_trash() {
        if (get_post_type() == $this->post_type) {
            echo '
                <style type="text/css">
                    .trash, .editinline, .tablenav, #delete-action{
                        //display:none;
                    }
                </style>
            ';
        }
    }

    /**
     * Add max-lenght to text area left right column
     *
     * @return @void
     */
    public function fmc_add_textarea_length() {
        if (get_post_type() == $this->post_type) {
            echo '
                <script>
                    (function($) {
                        $(".textarea").attr("maxlength","500");
                    })(jQuery);
                </script>
            ';
        }
    }

    /**
     * Hide add new link
     *
     * @global type $submenu
     */
    public function fmc_disable_page_new_posts() {
        global $submenu;

        if ((isset($_GET['post_type']) && $_GET['post_type'] == $this->post_type) || get_post_type() == $this->post_type) {
            unset($submenu["edit.php"][10]);
            echo '<style type="text/css">
                    //#favorite-actions, .add-new-h2, .tablenav { display:none; }
                  </style>';
        }
    }

    /**
     * Get page url by slug
     *
     * @param string $slug
     *
     * @return string
     */
    public function fmc_get_page_url($slug) {

        return home_url(ICL_LANGUAGE_CODE . '/' . $slug);
    }
}
$GLOBALS['custom_page'] = new FMC_Custom_Page();
$custom_page = new FMC_Custom_Page();