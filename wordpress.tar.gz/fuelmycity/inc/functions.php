<?php

//Disable auto complate and redirect to page post details
function remove_redirect_guess_404_permalink($redirect_url) {
    if (is_404())
        return false;
    return $redirect_url;
}

add_filter('redirect_canonical', 'remove_redirect_guess_404_permalink');

if (!function_exists('fmc_get_posts')) {

    /**
     * Get all posts from kol user or posts
     * that was created by admin on behalf of kol user
     *
     * @global type $wpdb
     * @param boolean $is_featured
     * @param int     $limit
     * @param int     $offset
     * @param int     $kol_id
     * @param int     $other_post
     * @param string  $country
     *
     * @return type
     */
    function fmc_get_posts($is_featured = false, $limit = 0, $offset = 0, $kol_id = 0, $other_post = 0, $country = '', $order_by_title = false) {

        global $wpdb;

        $kol_meta_key = CFS_KOL_USER;
        $featured_meta_key = CFS_FEATURE_POST;

        //get posts that was set to feature post by admin
        if ($is_featured) {
            $meta_query = "
                AND $wpdb->postmeta.meta_key = '{$featured_meta_key}'
                AND $wpdb->postmeta.meta_value = 1
            ";
        }

        //Get only posts that was created by kol user
        $get_by_kol = '';
        if ($kol_id) {
            $get_by_kol = "
                AND ($wpdb->posts.post_author = {$kol_id}
                OR ($wpdb->postmeta.meta_key = '{$kol_meta_key}'
                AND $wpdb->postmeta.meta_value = {$kol_id}))
            ";
        }

        //Get other posts that is different compare with current post
        //on post details page (journey details)
        $other_post_where = '';
        if ($other_post) {
            $other_post_where = " AND $wpdb->posts.ID != {$other_post}";
        }
        $order_by = " ORDER BY $wpdb->posts.post_date DESC";
        if ($other_post) {
            $order_by = "ORDER BY RAND() ";
        }
        $query = "
            SELECT DISTINCT $wpdb->posts.*
            FROM $wpdb->posts, $wpdb->postmeta
            WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id
            {$meta_query}
            {$get_by_kol}
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->posts.post_type = 'post'
            {$other_post_where}
            {$order_by}
        ";

        /** Get unlimit when filter by kol user */
        if ($limit && $offset) {
            $query .= " LIMIT {$offset}, $limit";
        }
        elseif ($limit) {
            $query .= " LIMIT 0, {$limit}";
        }

        $posts = $wpdb->get_results($query, OBJECT);
        if($order_by_title == true && !empty($posts)){
            $sort_posts = array();
            foreach($posts as $val){
                $kol_id = get_post_meta($val->ID, CFS_KOL_USER, true);
                if ($kol_id === '') {
                    $kol_id = $val->post_author;
                }
                $nickname  = get_user_meta($kol_id, 'nickname', true);
                $sort_posts[strtoupper($nickname . $val->ID)] = $val;
            }
            ksort($sort_posts);
            $posts = array_values($sort_posts);
        }
        return $posts;
    }

}

if (!function_exists('get_posts_by_country')) {

    /**
     * Get list post id by country
     *
     * @param string $country
     *
     * @return array
     */
    function get_posts_by_country($country) {

        if ('' === $country) {
            return array(0);
        }

        $args = array(
            'posts_per_page' => -1,
            'meta_key' => FMC_Country::USER_META_KEY,
            'meta_value' => $country,
        );
        $q = new WP_Query($args);
        $post_id = array();
        if ($q->have_posts()) {
            while ($q->have_posts()) {
                $q->the_post();
                $post_id[] = get_the_ID();
            }
        }
        else {
            return array(0);
        }

        return $post_id;
    }

}

if (!function_exists('fmc_get_post_tran')) {

    /**
     * Get list kol user id
     *
     * @return array
     */
    function fmc_get_post_by_id($post_id) {
        global $wpdb;

        $query = "
            SELECT DISTINCT $wpdb->posts.*
            FROM $wpdb->posts
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->posts.post_type = 'post'
            AND $wpdb->posts.ID = $post_id
        ";

        $posts = $wpdb->get_results($query, OBJECT);

        return $posts;
    }

}

if (!function_exists('get_list_koluserid')) {

    /**
     * Get list kol user id
     *
     * @return array
     */
    function fmc_get_list_koluserid() {
        $users = get_users(array('role' => 'kol'));
        $kol_id_arr = array();
        foreach ($users as $user) {
            $kol_id_arr[] = $user->ID;
        }

        return $kol_id_arr;
    }

}

if (!function_exists('fmc_connect_kol_name')) {

    /**
     * Generate kol user base on lang
     *
     * @param string $lang
     * @param string $fname
     * @param string $lname
     *
     * @return string
     */
    function fmc_connect_kol_name($lang, $fname, $lname) {
        switch ($lang) {
            default:
                $name = $fname . ' ' . $lname;
                break;
        }

        return $name;
    }

}

if (!function_exists('fmc_get_current_page')) {

    /**
     * Get current page, the page slug
     *
     * @return string
     */
    function fmc_get_current_page() {
        $url_arr = explode('/', $_SERVER["REQUEST_URI"]);
        $page_name = array(ABOUT, JOURNEY, JOURNEYS, PRIZES, SOCIALFEEDS, TERMS);

        if (count($url_arr)) {
            foreach ($url_arr as $one) {
                if (in_array($one, $page_name)) {
                    return $one;
                }
            }
        }

        return '';
    }

}

if (!function_exists('fmc_get_page_url')) {

    /**
     * Get page url include current lang in the url
     *
     * @param string $title Page title
     *
     * @return string
     */
    function fmc_get_page_url($title = '') {
        if ($title === '') {
            return home_url();
        }
        $page = get_page_by_path($title);
        $page_id = $page->ID;

        return get_permalink($page_id);
    }

}

if (!function_exists('fmc_print_active_class')) {

    /**
     *
     * @param type $title
     * @return type
     */
    function fmc_print_active_class($page, $page1 = '') {
        if (fmc_get_current_page() === $page) {
            echo HEADER_NAV_ACTIVE;
            return;
        }

        if ('' !== $page1 && fmc_get_current_page() === $page1) {
            echo HEADER_NAV_ACTIVE;
            return;
        }
    }

}

if (!function_exists('fmc_get_num_post_img')) {

    /**
     * Get number image of a section
     *
     * @param int $post_id post id
     * @param int $section the current section
     *
     * @return int
     */
    function fmc_get_num_post_img($post_id, $section, $num_img = false) {
        $img_size = SECTION_IMG_FULL;
        $post_images = array();
        for ($i = 1; $i <= 5; $i++) {
            if ($num_img) {
                if (defined("SECTION_{$num_img}_IMG_{$i}")) {
                    $img_size = constant("SECTION_{$num_img}_IMG_{$i}");
                }
            }
            $img_meta = get_post_meta($post_id, constant("CFS_S{$section}_IMG_{$i}"), true);
            $section_img = wp_get_attachment_image_src($img_meta, $img_size);
            $section_img['alt'] = get_post_meta($img_meta, '_wp_attachment_image_alt', true);

            if (fmc_check_detail_image($section_img)) {
                $post_images['section_img' . (count($post_images) + 1)] = $section_img;
            }
        }

        if ($num_img || !count($post_images)) {
            return $post_images;
        }
        return fmc_get_num_post_img($post_id, $section, count($post_images));
    }

}

if (!function_exists('fmc_break_carousel_text')) {

    /**
     * Break carousel title and author into
     * row by tag <br> or if it too long
     *
     * @param type $str
     *
     * @return string
     */
    function fmc_break_carousel_text($str) {
        $max_len = CAROUSEL_MAX_TEXT;
        $str_len = mb_strlen($str, 'UTF-8');
        if ($str_len <= $max_len) {
            return $str;
        }

        $break_br = explode(CAROUSEL_BR, $str);
        $final_str = '';
        if (count($break_br)) {
            foreach ($break_br as $one) {
                if (mb_strlen($one, 'UTF-8') > $max_len) {
                    $sub_str = mb_split("\s", $one, $max_len);
                    foreach ($sub_str as $sub) {
                        $final_str .= $sub . CAROUSEL_BR;
                    }
                }
                else {
                    $final_str .= $one . CAROUSEL_BR;
                }
            }
        }

        return $final_str;
    }
}


if (!function_exists('fmc_get_default_image')) {

    /**
     * Display default image if image check does not exist.
     *
     * @param string $img_check Image to check whether image exist
     * @param string $default   Default image to display in case image check doesn't exist
     * @param string $block     If image in post details so which block
     *
     * @return string
     */
    function fmc_get_default_image($img_check, $default, $block = 0) {
        /** Split image path to get path from folder uploads to image name */
        $wpcontent = 'wp-content';
        $image_arr = explode($wpcontent, $img_check);
        unset($image_arr[0]);
        $img_name = implode('/', $image_arr);
        $image_path = WP_CONTENT_DIR . $img_name;

        //Check image path. Image shouldn't be a directory and file must exist
        if (!is_dir($image_path) && !file_exists($image_path)) {
            $result = get_template_directory_uri() . '/images/default/' . $default;
            //Get default image in post details
            if ($block) {
                $result = get_template_directory_uri() . "/images/default/post-details/block{$block}/" . $default;
            }

            return $result;
        }

        return $img_check;
    }
}

if (!function_exists('fmc_check_detail_image')) {

    /**
     * Check image in block of post details
     *
     * @param array $image
     *
     * @return boolean
     */
    function fmc_check_detail_image($image) {
        if (false !== $image && '' !== $image && isset($image[0])) {
            return true;
        }

        return false;
    }

}

if (!function_exists('get_kol_avatar')) {

    /**
     * Get kol avatar
     *
     * @param int $kol_id
     * @param int $size
     *
     * @return string
     */
    function get_kol_avatar($kol_id, $size = 100) {
        $avatar_preg = preg_match('/src="(.*?)"/i', get_avatar($kol_id, $size), $matches);
        $avatar_url = count($matches) ? $matches[1] : '';

        return $avatar_url;
    }
}


if (!function_exists('fmc_escape_get')) {

    function fmc_escape_get($key, $default, $must_in = array(), $format = '') {
        if ($key === COUNTRY) {
            $var = get_country_current_site();
        }
        else {
            $var = isset($_GET[$key]) ? $_GET[$key] : $default;
        }

        switch ($format) {
            case 'int':
                $var = (int) $var;
                break;
        }

        if (count($must_in) && !in_array($var, $must_in)) {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: " . get_bloginfo('url'));
            exit();
        }

        return $var;
    }

}

if (!function_exists('fmc_langs')) {

    function fmc_langs() {
        return array(
            'sg',
            'my',
            'ph',
            'hk',
            'th'
        );
    }

}

if (!function_exists('fmc_get_social_share')) {

    /**
     * Get social sharing messages in footer
     *
     * @param string $country
     * @param string $social_type
     *
     * @return string
     */
    function fmc_get_social_share($country, $social_type = '') {

        $share_args = array(
            'post_type' => FMC_Social_Share::SOCIAL_SHARE_POST_TYPE,
            'post_status' => 'publish',
        );
        switch ($country) {
            case 'th':
                $slug = FMC_Social_Share::SOCIAL_SHARE_TH_SLUG;
                break;
            case 'hk':
                $slug = FMC_Social_Share::SOCIAL_SHARE_HK_SLUG;
                break;
            case 'ph':
                $slug = FMC_Social_Share::SOCIAL_SHARE_PH_SLUG;
                break;
            case 'my':
                $slug = FMC_Social_Share::SOCIAL_SHARE_MY_SLUG;
                break;
            default:
                $slug = FMC_Social_Share::SOCIAL_SHARE_SG_SLUG;
                break;
        }

        $share_args['name'] = $slug;
        $social_share_posts = get_posts($share_args);
        $fb_share = '';
        $tw_share = '';
        $gp_share = '';
        if (count($social_share_posts)) {
            $fb_share = get_post_meta($social_share_posts[0]->ID, FMC_Social_Share::SOCIAL_SHARE_META_FB, true);
            $tw_share = get_post_meta($social_share_posts[0]->ID, FMC_Social_Share::SOCIAL_SHARE_META_TW, true);
            $gp_share = get_post_meta($social_share_posts[0]->ID, FMC_Social_Share::SOCIAL_SHARE_META_GP, true);
        }

        $final = '';
        switch ($social_type) {
            case 'fb':
                $final = $fb_share;
                break;
            case 'tw':
                $final = $tw_share;
                break;
            case 'gp':
                $final = $gp_share;
                break;
            default:
                break;
        }

        return $final;
    }

}


/** =======================================================================
 *
 * AUTO RUN FUNCTION
 *
 * Functions below auto run by hook in WP
 *
 */
if (!function_exists('fmc_detect_ip')) {

    /**
     * Detect ip to get country code and redirect to right url
     *
     * @return redirect
     */
    function fmc_detect_ip() {
        $template_path = get_template_directory();
        $ip = $_SERVER['REMOTE_ADDR'];
        $current_url = get_site_url();

        // detect if url have sg
        $uri = $_SERVER["REQUEST_URI"];
        if(strlen($uri) > 2  && $uri[0] === '/'  && $uri[1] === 's'  && $uri[2] === 'g' ){
            $flag = false;
            if(strlen($uri) > 3 && ($uri[3] === '/' || $uri[2] === '?')){
                $flag = true;
            }elseif(strlen($uri) == 3){
                $flag = true;
            }

            if($flag){
                wp_redirect($current_url . substr($uri, 3, -1));
                exit;
            }
        }
        if(!$_COOKIE['language']){
            include_once $template_path . '/inc/ip2location/IP2Location.php';
            $location = new IP2Location($template_path . '/inc/ip2location/IP-COUNTRY-REGION-CITY.BIN');
            $record = $location->lookup($ip, IP2Location::ALL);
            $country_code = mb_strtolower($record->countryCode, 'UTF-8');
            $url = 'http://' . DOMAIN_CURRENT_SITE . '/';
            if (in_array($country_code, array('my', 'th', 'hk', 'ph', 'sg'))) {
                $current_country = get_country_current_site();
                if($current_country !== $country_code){
                    setcookie('language',1,0, "/");
                    wp_redirect($url . $country_code);
                    exit;
                }
            }
        }

    }

    add_action('init', 'fmc_detect_ip');
}


if (!function_exists('fmc_register_img_size')) {

    /**
     * Register image sizes
     */
    function fmc_register_img_size() {
        //Carousel image size
        add_image_size(CAROUSEL_POST_TYPE, 1400, 585, true);
        //Post cover image size
        add_image_size(POST_COVER_IMG_SIZE, 1400, 585, true);
        //Featured post thumbnail
        add_image_size(FEATURED_POST_THUMBNAIL, 528, 323, true);
        /** journey details */
        add_image_size(SECTION_1_IMG_1, 724, 450, true);
        add_image_size(SECTION_2_IMG_1, 360, 205, true);
        add_image_size(SECTION_2_IMG_2, 630, 350, true);
        add_image_size(SECTION_3_IMG_1, 258, 150, true);
        add_image_size(SECTION_3_IMG_2, 258, 150, true);
        add_image_size(SECTION_3_IMG_3, 360, 215, true);
        add_image_size(SECTION_4_IMG_1, 748, 470, true);
        add_image_size(SECTION_4_IMG_2, 254, 170, true);
        add_image_size(SECTION_4_IMG_3, 258, 150, true);
        add_image_size(SECTION_4_IMG_4, 258, 150, true);
        add_image_size(SECTION_5_IMG_1, 258, 150, true);
        add_image_size(SECTION_5_IMG_2, 258, 150, true);
        add_image_size(SECTION_5_IMG_3, 346, 195, true);
        add_image_size(SECTION_5_IMG_4, 360, 215, true);
        add_image_size(SECTION_5_IMG_5, 630, 350, true);
    }

    add_action('init', 'fmc_register_img_size');
}

if (!function_exists('fmc_add_custom_js')) {

    /**
     * Add custom js for carousel custom post type
     * the js validate the form that the carousel must be filled all or otherwise.
     *
     * @param type $hook
     */
    function fmc_add_custom_js($hook) {
        wp_enqueue_script('valid-carouse', get_template_directory_uri() . '/js/validate-carousel.js');
        wp_enqueue_script('valid-post', get_template_directory_uri() . '/js/validate-post.js');
    }

    add_action('admin_enqueue_scripts', 'fmc_add_custom_js');
}

if (!function_exists('fmc_add_post_custom_js')) {

    /**
     * Add constom js
     *
     * @param type $hook
     */
    function fmc_add_post_custom_js($hook) {

        $sa_hide_social_id = '';
        if (get_current_user_id() == FMC_Country::SUPPER_ADMIN && !isset($_GET['user_id'])) {
            $sa_hide_social_id .= "
                $('#eudfacebook_id').parent('td').parent('tr').hide();
                $('#eudtwitter_id').parent('td').parent('tr').hide();
                $('#eudinstagram_id').parent('td').parent('tr').hide();
            ";
        }

        if (current_user_can(FMC_Country::ADMIN_ROLE) && !isset($_GET['user_id'])) {
            $sa_hide_social_id .= "
                $('#eudkol_city').parent('td').parent('tr').hide();
                $('#eudkol_social_desc').parent('td').parent('tr').hide();
            ";
        }

        if (get_current_user_id() != FMC_Country::SUPPER_ADMIN) {
            $sa_hide_social_id .= "$('#eudfacebook_app_id').parent('td').parent('tr').hide();";
        }

        if (current_user_can(FMC_Country::KOL_ROLE)) {
            $sa_hide_social_id .= "
                $('#eudsg_city_social').parent('td').parent('tr').hide();
                $('#eudph_city_social').parent('td').parent('tr').hide();
                $('#eudth_city_social').parent('td').parent('tr').hide();
                $('#eudhk_city_social').parent('td').parent('tr').hide();
                $('#eudmy_city_social').parent('td').parent('tr').hide();
            ";
        }

        echo "
            <script>
                (function($) {
                    //Supper admin hide social fields
                    {$sa_hide_social_id}
                    //Validate user profile
                    $('#createuser table tr').eq(2).addClass('form-required');
                    $('#createuser table tr').eq(3).addClass('form-required');

                    //Add required text to user profile required field
                    var label = $('label[for=last_name]');
                    label.html(label.html() + ' <span class=\"description\">(required)</span>');
                    $('#last_name').attr('required',true);
                    label = $('label[for=first_name]');
                    label.html(label.html() + ' <span class=\"description\">(required)</span>');
                    $('#first_name').attr('required',true);

                    //Hide get feeds link.
                    var adminNavLi = $('#menu-posts-social_feed ul li');
                    adminNavLi.eq(0).hide();
                    adminNavLi.eq(1).hide();
                    adminNavLi.eq(4).hide();

                    href_social_feed = $('#menu-posts-social_feed > a');
                    href_social_feed.attr('href', href_social_feed.attr('href') + '&page=craw-feed')

                    //Hide uneccessary user profile field
                    $('.user-rich-editing-wrap').hide();
                    $('.user-comment-shortcuts-wrap').hide();
                    $('.user-admin-bar-front-wrap').hide();
                    $('#createuser table tr').eq(4).hide();

                    $('#menu-posts-carousel ul li').eq(2).hide();
                    $('#wp-admin-bar-new-carousel').hide();

                    //Add maxlength attribute to input title
                    //$('.post-type-post .field-" . CFS_S1_TITLE . " .text').attr('maxlength', " . CFS_SECTION_TITLE_MAX . ");
                    //$('.post-type-post .field-" . CFS_S2_TITLE . " .text').attr('maxlength', " . CFS_SECTION_TITLE_MAX . ");
                    //$('.post-type-post .field-" . CFS_S3_TITLE . " .text').attr('maxlength', " . CFS_SECTION_TITLE_MAX . ");
                    //$('.post-type-post .field-" . CFS_S4_TITLE . " .text').attr('maxlength', " . CFS_SECTION_TITLE_MAX . ");
                    //$('.post-type-post .field-" . CFS_S5_TITLE . " .text').attr('maxlength', " . CFS_SECTION_TITLE_MAX . ");
                })(jQuery);
            </script>
        ";
    }

    add_action('admin_footer', 'fmc_add_post_custom_js');
}

if (!function_exists('fmc_hide_uneccessary_user_profile')) {

    /**
     * Hide uneccessary user profile fields
     *
     * @global int $_wp_admin_css_colors
     */
    function fmc_hide_uneccessary_user_profile() {
        global $_wp_admin_css_colors;
        global $sitepress;
        remove_action('show_user_profile', array($sitepress, 'show_user_options'));
        $_wp_admin_css_colors = 0;
    }

    add_action('admin_head', 'fmc_hide_uneccessary_user_profile');
}

if (!function_exists('fmc_remove_additional_capabilities_func')) {

    /**
     * Hide capabilities in user profile
     *
     * @return boolean
     */
    function fmc_remove_additional_capabilities_func() {
        return false;
    }

    add_filter('additional_capabilities_display', 'fmc_remove_additional_capabilities_func');
}

if (!function_exists('fmc_check_first_and_last_name')) {

    /**
     * Validate when user update their profile,
     * the first name and last name must be filled
     *
     * @param type $errors
     * @param type $update
     * @param type $user
     */
    function fmc_check_first_and_last_name($errors, $update, $user) {
        if (empty($user->first_name)) {
            $errors->add('empty_first_name', __('<strong>ERROR</strong>: Please enter first name.'));
        }
        if (empty($user->last_name)) {
            $errors->add('empty_last_name', __('<strong>ERROR</strong>: Please enter last name.'));
        }
    }

    add_filter('user_profile_update_errors', 'fmc_check_first_and_last_name', 10, 3);
}

if (!function_exists('fuelmycity_setup')) {

    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     *
     * @since fuelmycity Fifteen 1.0
     */
    function fuelmycity_setup() {

        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on twentyfifteen, use a find and replace
         * to change 'fuelmycity' to the name of your theme in all the template files
         */
        load_theme_textdomain('fuelmycity', get_template_directory() . '/languages');
    }

    add_action('after_setup_theme', 'fuelmycity_setup');
} // fuelmycity_setup

/**
 * @todo to get current site ---> is country
 * @global type $blog_id
 * @return type
 */
function get_country_current_site() {
    global $blog_id;
    $site_info = get_blog_details($blog_id);
    $country = str_replace('/', '', $site_info->path);
    return (!empty($country)) ? $country : 'sg';
}

/**
 * @todo get list site
 */
if (!function_exists('get_list_site')) {

    function get_list_site($expires = 7200) {
        if (!is_multisite()){
            return false;
        }

        // Because the get_blog_list() function is currently flagged as deprecated
        // due to the potential for high consumption of resources, we'll use
        // $wpdb to roll out our own SQL query instead. Because the query can be
        // memory-intensive, we'll store the results using the Transients API
        if (false === ( $site_list = get_transient('multisite_site_list') )) {
            global $wpdb;
            $site_list = $wpdb->get_results($wpdb->prepare('SELECT * FROM wp_blogs ORDER BY blog_id'));
            // Set the Transient cache to expire every two hours
            set_site_transient('multisite_site_list', $site_list, $expires);
        }

        return $site_list;
    }

}

if ( ! function_exists('get_user_nav')) {
    /**
     * Get users display on header
     * List the last 4 users by registed date and sort by display name
     *
     * @param int $limit
     *
     * @return type
     */
    function get_user_nav($limit){

        $kol_id = get_users(array(
            'role'    => 'kol',
            'number'  => $limit,
            'orderby' => 'registered',
            'order'   => 'DESC',
            'fields'  => 'ID'
        ));

        $kol_users = get_users(array(
            'role'    => 'kol',
            'number'  => $limit,
            'orderby' => 'display_name',
            'order'   => 'ASC',
            'include' => $kol_id
        ));

        return $kol_users;
    }
}

if ( ! function_exists('get_home_posts')) {

    /**
     * Get list posts on homepage, the posts of lastest kol users
     *
     * @return array
     */
    function get_home_posts($limit = LIMIT_KOL_HOMEPAGE) {

        $posts = array();
        $users = get_users(array(
            'role'    => 'kol',
            'number'  => $limit,
            'orderby' => 'registered',
            'order'   => 'DESC',
        ));
        
        if (count($users)) {
            foreach ($users as $user) {
                    $post = fmc_get_posts(false, 1, 0, $user->ID);
                    if (count($post)) {
                        $posts[] = $post;
                    }
            }
        }

        if (count($posts) < LIMIT_KOL_HOMEPAGE) {
            $posts = get_home_posts($limit + 1);
        }

        return $posts;
    }
}

if ( ! function_exists('fmc_get_posts_by_user_registed_date')) {

    function fmc_get_posts_by_user_registed_date($limit = POST_LIMIT, $offset = 0) {

        $args = array(
            'posts_per_page' => $limit,
            'offset'         => $offset,
            'meta_key'       => FMC_KOL_REGISTED_DATE,
            'orderby'        => 'meta_value_num',
            'post_type'      => 'post',
            'post_status'    => 'publish',
        );

        $posts = get_posts($args);

        return $posts;
    }
}