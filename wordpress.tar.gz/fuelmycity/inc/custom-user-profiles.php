<?php

if (!function_exists('fmc_add_user_country')) {

    /**
     * Add countries select box in user profiles
     *
     * @param type $user
     */
    function fmc_add_user_country($user) {
        $countries = FMC_Country::get_countries();
        $curernt_user = wp_get_current_user();
        $roles = $curernt_user->roles;
        $country = get_user_meta($curernt_user->ID, FMC_Country::USER_META_KEY, true);

        if ($user->ID !== FMC_Country::SUPPER_ADMIN && (null === $country || '' === $country) && isset($roles[0]) && $roles[0] === FMC_Country::ADMIN_ROLE) {
            ?>
            <table class="form-table">
                <tr>
                    <th><label for="gender">Country</label></th>
                    <td>
                        <select name="<?php echo FMC_Country::USER_META_KEY; ?>" id="<?php echo FMC_Country::USER_META_KEY; ?>" >
                            <!--<option value="<?php echo FMC_Country::DEFAULT_COUNTRY; ?>">Please select a country</option>-->
                            <?php
                            if (count($countries)) {

                                foreach ($countries as $key => $country) {
                                    $selected = selected($key, get_the_author_meta(FMC_Country::USER_META_KEY, $user->ID));
                                    echo "<option value='{$key}' {$selected}>{$country}</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>

            <?php
        }
        else {
            ?>
            <input type="hidden"
                   value="<?php echo $country; ?>"
                   name="<?php echo FMC_Country::USER_META_KEY; ?>" />
            <?php
        }
    }

    add_action('show_user_profile', 'fmc_add_user_country');
    add_action('edit_user_profile', 'fmc_add_user_country');
}

if (!function_exists('fmc_save_user_country')) {

    /**
     * Save user country
     *
     * @param type $user_id
     *
     * @return boolean
     */
    function fmc_save_user_country($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return false;
        }

        $country = get_country_current_site();
        $curernt_user = get_current_user_id();
        $country_meta = get_user_meta($curernt_user, FMC_Country::USER_META_KEY, true);
        if (null !== $country_meta && '' !== $country_meta) {
            $country = $country_meta;
        }
        if (isset($_POST[FMC_Country::USER_META_KEY])) {
            $country = $_POST[FMC_Country::USER_META_KEY];
        }
        update_usermeta($user_id, FMC_Country::USER_META_KEY, $country);
    }

    add_action('personal_options_update', 'fmc_save_user_country');
    add_action('edit_user_profile_update', 'fmc_save_user_country');
    add_action('user_register', 'fmc_save_user_country', 10, 1);
}

if (!function_exists('fmc_custom_user_roles_js')) {

    /**
     * Add constom js
     *
     * @param type $hook
     */
    function fmc_custom_user_roles_js($hook) {
        $curernt_user = wp_get_current_user();
        $roles = $curernt_user->roles[0];


        if ($curernt_user->ID !== FMC_Country::SUPPER_ADMIN && $roles === FMC_Country::ADMIN_ROLE) {
            echo "
                <script>
                        jQuery('#role option[value=\"". FMC_Country::ADMIN_ROLE ."\"]').remove();
                        jQuery('#new_role option[value=\"". FMC_Country::ADMIN_ROLE ."\"]').remove();
                        jQuery('#adduser-role option[value=\"". FMC_Country::ADMIN_ROLE ."\"]').remove();

                        var count = 0;
                        jQuery('.users-php tbody#the-list tr').each(function(){
                            var role = jQuery(this).find('td.role.column-role').text();
                            if(role == 'Administrator'){
                                jQuery(this).remove();
                            }else{
                                count++;
                            }
                        });

                        jQuery('.users-php ul.subsubsub li.administrator').remove();
                        jQuery('.users-php ul.subsubsub li.all').remove();
                </script>
            ";
        }elseif($roles === FMC_Country::KOL_ROLE){
            echo "
                <script>
                        jQuery('#menu-users .wp-submenu a[href=\"user-new.php\"]').remove();
                </script>
            ";
        }
    }

    add_action('admin_footer', 'fmc_custom_user_roles_js');
}


if (!function_exists('fmc_filter_list_posts')) {

    /**
     * Custom list users
     *
     * @param type $query
     */
    function fmc_filter_list_posts($query) {
        if (is_admin() && (in_array($query->get('post_type'), array('post')) ||
                in_array($query->get('post_type'), array('carousel')))) {
            $user_id = get_current_user_id();
            $roles = wp_get_current_user()->roles;
            if ($roles[0] === 'kol') {
                $posts = fmc_get_posts(false, 1000, 0, $user_id);
                $post_id = array(0);
                if (count($posts)) {
                    foreach ($posts as $one) {
                        $post_id[] = $one->ID;
                    }
                }
                $query->set('post__in', $post_id);
                unset($query->query['author']);
                unset($query->query_vars['author']);
            }
        }
    }

    if (defined('DOING_AJAX') && DOING_AJAX) {

    }
    else {
        add_action('pre_get_posts', 'fmc_filter_list_posts', 1000);
    }
}


foreach (array('edit-post', 'edit-carousel') as $hook) {
    add_filter("views_$hook", 'wpse_30331_custom_view_count', 10, 1);
}

function wpse_30331_custom_view_count($views) {
    global $current_screen;
    switch ($current_screen->id) {

        case 'edit-post':
            $views = wpse_30331_manipulate_views('post', $views);
            break;
        case 'edit-carousel':
            $views = wpse_30331_manipulate_views('carousel', $views);
            break;
    }
    return $views;
}

add_filter('views_edit-post', 'wpse_30331_custom_view_count', 10, 1);

/**
 * Hook to recount status on list posts
 *
 * @global type $user_ID
 * @global type $wpdb
 *
 * @param type $what
 * @param type $views
 *
 * @return type
 */
function wpse_30331_manipulate_views($what, $views) {
    global $user_ID;

    $country = get_user_meta($user_ID, FMC_Country::USER_META_KEY, true);
    //Admin can see all
    if (false === $country || '' === $country) {
        return $views;
    }

    $args = array(
        'post_type' => $what,
    );
    $total = 0;
    $publish = 0;
    $draft = 0;
    $trash = 0;
    foreach (array('any', 'publish', 'draft', 'trash') as $status) {
        $args['post_status'] = $status;
        $count_q = new WP_Query($args);
        switch ($status) {
            case 'any':
                $total = $count_q->post_count;
                break;
            case 'publish':
                $publish = $count_q->post_count;
                break;
            case 'draft':
                $draft = $count_q->post_count;
                break;
            case 'trash':
                $trash = $count_q->post_count;
                break;
        }
    }

    $views['all'] = preg_replace('/\(.+\)/U', '(' . $total . ')', $views['all']);
    $views['publish'] = preg_replace('/\(.+\)/U', '(' . $publish . ')', $views['publish']);
    if (isset($views['draft'])) {
        $views['draft'] = preg_replace('/\(.+\)/U', '(' . $draft . ')', $views['draft']);
    }
    if (isset($views['trash'])) {
        $views['trash'] = preg_replace('/\(.+\)/U', '(' . $trash . ')', $views['trash']);
    }
    if (isset($views['mine'])) {
        $args = array(
            'post_type' => 'post',
            'post_author' => $user_ID
        );
        $count_q = new WP_Query($args);
        $views['mine'] = preg_replace('/\(.+\)/U', '(' . $count_q->post_count . ')', $views['mine']);
    }

    return $views;
}

if ( ! function_exists('fmc_add_post_user_registed_date')) {
    /**
     * Add the country to post
     *
     * @param int $post_id
     * @return void
     */
    function fmc_add_post_user_registed_date($post_id) {

        if ( ! wp_is_post_revision( $post_id ) ){
            $user_id = get_post_meta($post_id, CFS_KOL_USER, true);
            //KOL create this post
            if (false === $user_id || '' === $user_id) {
                $cur_post = get_post($post_id);
                $user_id  = $cur_post->post_author;
            }

            $user_saving_post = get_user_by('id', $user_id);

            if ($user_saving_post) {
                $registed_date = new DateTime($user_saving_post->user_registered);
                if (metadata_exists('post', $post_id, FMC_KOL_REGISTED_DATE)) {
                    update_post_meta($post_id, FMC_KOL_REGISTED_DATE, $registed_date->getTimestamp());
                } else {
                    add_post_meta($post_id, FMC_KOL_REGISTED_DATE, $registed_date->getTimestamp());
                }
            }
        }
    }
    add_action('save_post', 'fmc_add_post_user_registed_date');
}