<?php
global $blog_id;

$countries    = FMC_Country::get_country_selector();
$blog_list    = wp_get_sites();
$flag_path    = get_template_directory_uri() . '/images/upload/';
$current_blog = (isset( $countries[$blog_id] )) ? $countries[$blog_id] : array_shift($countries);

?>
<a href="javascript:;" title="<?php echo $current_blog['name'] ?>" class="lang-selected">
    <span class="text">
        <img src="<?php echo $flag_path . $current_blog['flag'] ?>" alt="<?php echo $current_blog['name'] ?>"/>
        <span><?php echo $current_blog['name'] ?></span>
    </span>
</a>
<ul class="dropdown-menu">
    <?php
    foreach ( $blog_list as $blog ) :

        $country = $countries[ $blog['blog_id'] ];

        if ( $blog_id !== $blog['blog_id'] ) :
    ?>
    <li>
        <a href="<?php echo $blog['path']; ?>" title="<?php echo $country['name']; ?>">
            <img src="<?php echo $flag_path . $country['flag']; ?>" alt="<?php echo $country['name']; ?>"/>
            <span><?php echo $country['name']; ?></span>
        </a>
    </li>
    <?php
        endif;
    endforeach;
    ?>
</ul>