<?php
/*
  Template Name: Social feeds page
 */

get_header();

/** Check location params from URL */

// If location exist, the feed id must exist.
$redirect_str = 'location:' . fmc_get_page_url(SOCIALFEEDS);
if ( isset($_GET['latitude']) && isset($_GET['longitude']) && ! isset($_GET['id'])) {
    header($redirect_str);
}

//Params from URL must be same with data in DB
if ( isset($_GET['latitude']) && isset($_GET['longitude']) && isset($_GET['id'])) {
    $feed_id   = $_GET['id'];
    $longitude = $_GET['longitude'];
    $latitude  = $_GET['latitude'];

    $feed_map  = get_post($feed_id);
    if (NULL === $feed_map) {
        header($redirect_str);
    }

    $feed_location = get_post_meta($feed_map->ID, SF_LOCATION, true);
    if (false === $feed_location || '' === $feed_location) {
        header($redirect_str);
    }

    $long_lat = json_decode($feed_location);
    if ($longitude != (string)$long_lat->longitude || $latitude != (string)$long_lat->latitude) {
        header($redirect_str);
    }
}
?>

<div id="social-page" data-tab data-social-feed="social-feed-page" data-gridviewarea=".social-list" data-user-default="KOL" class="social-block bgd-red">
    <div class="heading white-state">
        <div class="grid-fluid">
            <div class="row">
                <div class="col-md-9 col-sm-8">
                    <div class="row">
                        <div class="col-xs-6 col-sm-8 ct-title-social-feed">
                            <h2 class="title"><?php _e("#Fuelmycity", FMC); ?></h2>
                        </div>
                        <div class="col-xs-6 col-sm-4 text-right">
                            <div id="filter-user" data-dropdown=".link-view" data-target=".scopes" class="filter-box">
                                <a href="javascript:;" title="<?php _e("View", FMC); ?>" class="link-view"><span><?php _e("View", FMC); ?></span></a>
                                <ul class="scopes">
                                    <li><a href="javascript:;" title="<?php _e("Ambassadors", FMC); ?>" class="selected"><img src="<?php echo get_template_directory_uri(); ?>/images/icon-marker-red-small.png" alt="<?php _e("marker", FMC); ?>"/><span data-val="KOL"><?php _e("Ambassadors", FMC); ?></span></a>
                                    </li>
                                    <li><a href="javascript:;" title="<?php _e("Public", FMC); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/icon-marker-blue-small.png" alt="<?php _e("marker", FMC); ?>"/><span data-val="PUBLIC"><?php _e("Public", FMC); ?></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="views">
                        <a href="javascript:;" title="<?php _e("Grid", FMC); ?>" class="current" data-handler="grid-view">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/icon-grid.png" alt="<?php _e("Grid", FMC); ?>"/>
                            <span><?php _e("Grid", FMC); ?></span>
                        </a>
                        <a href="javascript:;" title="<?php _e("Map", FMC); ?>" data-handler="map-view">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/icon-marker-white-small.png" alt="<?php _e("Map", FMC); ?>"/>
                            <span><?php _e("Map", FMC); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-content="grid-view" class="grid-view">
        <div class="grid-fluid">
            <div data-popup="socialFeedDetail" data-id-popup="social-popup" class="row social-list">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="row"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="row text-center">
                        <div class="col-sm-9 col-sm-offset-2 col-md-10 col-md-offset-1">
                            <a id="more-grid-feed" href="javascript:;" title="<?php _e('Load more', FMC); ?>" class="button-style button-white-style">
                                <span class="text"><?php _e('Load more', FMC); ?></span>
                                <span class="arrow-down"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="map" data-content="map-view" class="map hidden"></div>
</div>
<?php
get_footer();
?>