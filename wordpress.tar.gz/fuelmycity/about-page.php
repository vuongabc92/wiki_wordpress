<?php
/*
  Template Name: About page
 */

get_header();

$current_id   = get_the_ID();
$left_column  = get_post_meta($current_id, CFS_ABOUT_LEFT, true);
$right_column = get_post_meta($current_id, CFS_ABOUT_RIGHT, true);
$kol_users    = get_users(array(
    'role'       => 'kol',
    'number'     => ABOUT_LIMIT_KOL,
    'orderby'    => 'nickname',
    'order'      => 'ASC',
));
?>
<div class="about-block bgd-dark">
    <div data-popup="personDetail" data-id-popup="person-popup" class="grid-fluid">
        <div class="row heading">
            <div class="col-md-4">
                <h2 class="title"><?php _e('About', FMC); ?></h2>
            </div>
            <div class="col-md-4 col-sm-6">
                <p class="desc"><?php echo $left_column; ?></p>
            </div>
            <div class="col-md-4 col-sm-6">
                <p class="desc"><?php echo $right_column; ?></p>
            </div>
        </div>
        <?php
        if (count($kol_users)) :
            ?>
            <div class="row heading">
                <div class="col-sm-12">
                    <h2 class="title margin-top-40"><?php _e('The Ambassadors', FMC); ?></h2>
                    <div class="tags"><span><?php _e('#Caltex', FMC); ?></span><span><?php _e('#Fuelmycity', FMC); ?></span></div>
                </div>
            </div>
            <div class="about-list">
              <div class="row">
                <?php for($i=0 ;$i < count($kol_users) ; $i++): ?>
                  <?php
                        $kol = $kol_users[$i];
                        $nickname   = get_user_meta($kol->ID, 'nickname', true);
                        $kol_desc   = get_user_meta($kol->ID, 'description', true);
                        $facebook_name   = get_user_meta($kol->ID, 'facebook_name',true);
                        $facebook   = get_user_meta($kol->ID, 'facebook_link',true);
                        $twiter_name   = get_user_meta($kol->ID, 'twitter_name', true);
                        $twiter   = get_user_meta($kol->ID, 'twitter_link', true);
                        $instagram_name   = get_user_meta($kol->ID, 'instagram_name', true);
                        $instagram   = get_user_meta($kol->ID, 'instagram_link', true);
                        $desc_trans = apply_filters("content",$kol_desc);
                        $avatar_url = get_kol_avatar($kol->ID, 481);
                    ?>
                   <div class="item col-sm-6 col-md-4">
                        <a href="javascript:;" title="<?php echo $nickname; ?>" class="about-preview"
                           data-detail-img="<?php echo $avatar_url; ?>"
                           data-detail-name="<?php echo $nickname; ?>"
                           data-detail-decs="<?php echo $desc_trans; ?>"
                           data-text-btn="<?php _e('View journey', FMC) ?>"
                           data-link-btn="<?php echo fmc_get_page_url(JOURNEYS) . '?kol-user=' . $kol->ID  ?>"
                           data-social-block="
                            <ul class='social-block-1'>
                                <?php
                                    if($facebook && $facebook_name){
                                        $facebooks = preg_split('/[;,]/', $facebook);
                                        $facebook_names = preg_split('/[;,]/', $facebook_name);
                                        
                                        $facebook_min = count($facebooks) < count($facebook_names) ? count($facebooks) : count($facebook_names);
                                        for($l = 0; $l < $facebook_min ; $l++){
                                            $tmp_facebook = trim($facebooks[$l]);
                                            $tmp_facebook_name = trim($facebook_names[$l]);
                                            if($tmp_facebook != '' && $tmp_facebook_name != ''){
                                                echo "<li><a href='$tmp_facebook' title='Facebook' class='ic-facebook' target='_blank'>$tmp_facebook_name</a></li>"; 
                                            }
                                        }
                                    }
                                    if($twiter_name && $twiter){
                                        $twiters = preg_split('/[;,]/', $twiter);
                                        $twiter_names = preg_split('/[;,]/', $twiter_name);
                                        $twiter_min = count($twiters) < count($twiter_names) ? count($twiters) : count($twiter_names);
                                        for($m = 0; $m < $twiter_min ; $m++){
                                            $tmp_twiter = trim($twiters[$m]);
                                            $tmp_twiter_name = trim($twiter_names[$m]);
                                            if($tmp_twiter != '' && $tmp_twiter_name != ''){
                                                echo "<li><a href='$tmp_twiter' title='Twitter' class='ic-twitter' target='_blank'>$tmp_twiter_name</a></li>";
                                            }
                                        }
                                    }
                                    if($instagram_name && $instagram){
                                        $instagrams = preg_split('/[;,]/', $instagram);
                                        $instagram_names = preg_split('/[;,]/', $instagram_name);
                                        $instagram_min = count($instagrams) < count($instagram_names) ? count($instagrams) : count($instagram_names);
                                        for($n = 0; $n < $instagram_min ; $n++){
                                            $tmp_instagram = trim($instagrams[$n]);
                                            $tmp_instagram_name = trim($instagram_names[$n]);
                                            if($tmp_instagram != '' && $tmp_instagram_name != ''){
                                                echo "<li><a href='$tmp_instagram' title='Instagram' class='ic-instagram' target='_blank'>$tmp_instagram_name</a></li>";
                                            }
                                        }
                                    }
                                ?>
                            </ul>"
                        >
                            <div class="thumb">
                                    <span class="bg-gradient"></span>
                                    <img src="<?php echo $avatar_url; ?>" alt="<?php echo $nickname; ?>"/>
                            </div>
                           <h3 class="title"><?php echo $nickname; ?></h3>
                       </a>
                   </div>
                <?php endfor; ?>
              </div>
            </div>
            <?php
        endif;
        ?>
    </div>
</div>
<?php
get_footer();