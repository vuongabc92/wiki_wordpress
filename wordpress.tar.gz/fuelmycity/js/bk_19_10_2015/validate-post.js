;
(function($, window, undefined) {
    'use strict';

    var pluginName = 'validate-post',
        titles     = '_title',
        texts      = '_text_',
        imgs       = '_img_';

    function Plugin(element, options) {
        this.element = $(element);
        this.options = $.extend({}, $.fn[pluginName].defaults, this.element.data(), options);
        this.init();
    }

    Plugin.prototype = {
        init: function() {
            var that = this,
                opt  = that.options,
                body = $('body'),
                el   = that.element;

            this.vars = {
                inputsEle: $('#normal-sortables', el),
                titlePost: $('#title', el),
                coverImg: $('.field-cfs_cover_img', el).find('input[type="hidden"]'),
                coverImgSmall: $('.field-cfs_small_cover_img', el).find('input[type="hidden"]')
            };

            this.element.off('submit.' + pluginName).on('submit.' + pluginName, function(e) {
                if (body.hasClass(opt.classType)) {
                    return that.checkSubmit();
                }
            });
        },
        checkSubmit: function() {
            var count = 0,
                opt   = this.options,
                vars  = this.vars,
                win   = $(window),
                css   = 'margin: 5px 0 15px; border: 1px solid #c00; background: #ffebe8; padding: 5px;';

            if (!vars.titlePost.val()) {
                vars.titlePost.next('.warning').length ? null :
                        vars.titlePost.after('<p class="warning" style="' + css + '">' + opt.warningTitle + '</p>');
                count++;
            }
            else {
                vars.titlePost.next('.warning').length ? vars.titlePost.next('.warning').remove() : null;
            }

            if (!(vars.coverImg.val() && vars.coverImgSmall.val())) {
                vars.coverImg.closest('.inside').next('.warning').length ? null :
                        vars.coverImg.closest('.inside').after('<p class="warning" style="' + css + '">' + opt.warningCoverImg + '</p>');
                count++;
            }
            else {
                vars.coverImg.closest('.inside').next('.warning').length ? vars.coverImg.closest('.inside').next('.warning').remove() : null;
            }

            for (var i = 0, l = opt.numGroup; i < l; i++) {
                var title = vars.inputsEle.find('[class="' + opt.prefixSelector + (i + 1) + titles + '"]').find('input'),
                        text = vars.inputsEle.find('[class^="' + opt.prefixSelector + (i + 1) + texts + '"]').find('iframe').contents().find('#tinymce').children(),
                        img = vars.inputsEle.find('[class^="' + opt.prefixSelector + (i + 1) + imgs + '"]').find('input[type="hidden"]'),
                        concatText = "",
                        concatImgVal = "",
                        parentsSection = title.closest('.inside');

                text.each(function() {
                    concatText += $(this).text();
                });

                img.each(function() {
                    concatImgVal += $(this).val();
                });

                if (!((concatText && concatImgVal && title.val()) || (!concatText && !concatImgVal && !title.val()))) {
                    parentsSection.prev('.warning').length ? null :
                            parentsSection.before('<p class="warning" style="' + css + '">' + opt.warningMsg + '</p>');
                    count++;
                }
                else {
                    parentsSection.prev('.warning').length ? parentsSection.prev('.warning').remove() : null;
                }
            }

            if (count) {
                win.scrollTop(this.element.find('p.warning').first().offset().top - 100);
                return false;
            }
        },
        destroy: function() {
            $.removeData(this.element[0], pluginName);
        }
    };

    $.fn[pluginName] = function(options, params) {
        return this.each(function() {
            var instance = $.data(this, pluginName);
            if (!instance) {
                $.data(this, pluginName, new Plugin(this, options));
            } else if (instance[options]) {
                instance[options](params);
            } else {
                window.console && console.log(options ? options + ' method is not exists in ' + pluginName : pluginName + ' plugin has been initialized');
            }
        });
    };

    $.fn[pluginName].defaults = {
        prefixSelector: 'field field-cfs_s',
        numGroup: 5,
        titlePostEle: '#title',
        classType: 'post-type-post',
        warningMsg: 'A section have 3 mandatory fields is: title, text 1 and at least one image. Please fill them all or not.',
        warningTitle: 'Please fill journey title field.',
        warningCoverImg: 'Please upload cover image and small cover image.'
    };

    $(function() {
        $('#post')[pluginName]();
    });

}(jQuery, window));
