;(function($, window, undefined) {
  'use strict';

  var pluginName = 'validate-carousel',
      titles = '_title',
      authors = '_author';

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, this.element.data(), options);
    this.init();
  }

  Plugin.prototype = {
    init: function() {
      var that = this,
          opt = that.options,
          body = $('body'),
          el = that.element;

      this.vars = {
        inputsEle: $('#cfs_input_71 .inside', el)
      };

      this.element.off('submit.' + pluginName).on('submit.' + pluginName, function(e) {
        if (body.hasClass(opt.classType)) {
          return that.checkSubmit();
        }
      });
    },
    checkSubmit: function() {
      var count = 0,
          opt = this.options,
          vars = this.vars,
          win = $(window);
      for (var i = 0, l = opt.numGroup; i < l; i++) {
        var title = vars.inputsEle.find('[class="' + opt.prefixSelector + (i + 1) + titles + '"]').find('input'),
            carousel = vars.inputsEle.find('[class="' + opt.carouselSelector + (i + 1) + '"]').find('img').attr('src'),
            author = vars.inputsEle.find('[class="' + opt.prefixSelector + (i + 1) + authors + '"]').find('input').val(),
            parentsTitle = title.parent().parent();

        if (!((title.val() && carousel && author) || (!title.val() && !carousel && !author))) {
          parentsTitle.prev('.warning').length ? null :
            parentsTitle.before('<p class="warning" style="width:100%;float:left;color:#f66;padding:0 10px;">' + opt.warningMsg + '</p>');
          count++;
        }
        else {
          parentsTitle.prev('.warning').length ? parentsTitle.prev('.warning').remove() : null;
        }
      }

      if (count) {
        win.scrollTop(this.element.find('p.warning').first().offset().top - 100);
        return false;
      }
    },
    destroy: function() {
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      } else {
        window.console && console.log(options ? options + ' method is not exists in ' + pluginName : pluginName + ' plugin has been initialized');
      }
    });
  };

  $.fn[pluginName].defaults = {
    prefixSelector: 'field field-cfs_slide_',
    carouselSelector: 'field field-cfs_carousel_slide_',
    numGroup: 10,
    classType: 'post-type-carousel',
    warningMsg: 'A carouse include: image, title and author. Please fill them all.'
  };

  $(function() {
    $('#post')[pluginName]();
  });

}(jQuery, window));
