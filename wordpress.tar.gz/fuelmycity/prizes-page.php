<?php
/*
  Template Name: Prizes page
 */

get_header();
$image_bottom = CFS()->get("prize_image_bottom");
$img = (!is_null($image_bottom)) ? wp_get_attachment_image($image_bottom, 'full') : '';

?>
<div class="prize-block bgd-dark">
    <div class="grid-fluid">
        <div class="row heading">
            <div class="col-md-4">
                <h2 class="title"><?php echo CFS()->get("prize_title") ?></h2>
                <div class="tags"><span>#<?php echo CFS()->get("prize_tag1") ?></span><span>#<?php echo CFS()->get("prize_tag2") ?></span></div>
            </div>
            <div class="col-md-7 col-sm-7 content-contest">
                <?php
                if (have_posts()) :
                    while (have_posts()) : the_post();
                        the_content();
                    endwhile;
                endif;
                ?>
            </div>
        </div>
        <div class="row infographic wrap-img-contest">
            <div class="col-md-7 col-md-offset-4">
            <?php
                $img = preg_replace( '/(width|height)="\d*?"\s/', "", $img );
                echo $img;
            ?>
            </div>
        </div>
        <div class="row prize-list prize-list-ct">
            <div class="col-md-7 col-md-offset-4">
                <ul>
                    <?php
                        $max_items  = (int) CFS_ITEM_MAX;
                        $list_items = array();
                        for ( $i = 1; $i <= $max_items; $i++ ) {
                            $title = CFS()->get(constant("CFS_ITEM{$i}_TITLE"));
                            $desc  = CFS()->get(constant("CFS_ITEM{$i}_DESCRIPTION"));
                            $image = CFS()->get(constant("CFS_ITEM{$i}_IMAGE"));
                            if ( ! empty($title) &&  ! empty($desc) &&  ! empty($image)) {
                                ?>
                                    <li class="prize-preview">
                                        <div class="thumb"><img src="<?php echo $image; ?>" alt="<?php echo $title; ?>"/>
                                        </div>
                                        <div class="content">
                                            <h3 class="title"><?php echo $title; ?></h3>
                                            <p class="desc"><?php echo $desc; ?></p>
                                        </div>
                                    </li>
                                <?php
                            }
                        }
                    ?>
                </ul>
            </div>
        </div>

    </div>
</div>
<?php
get_footer();