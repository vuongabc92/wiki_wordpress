<?php

/*
  Template Name: Journey page
 */

get_header();

status_header(404);
nocache_headers();
include( get_404_template() );
exit;


$article_id = 0;
if (isset($_GET['id'])) {
    $article_id = (int) $_GET['id'];
}

$article = get_post($article_id);
if (NULL !== $article) {
    $template_path = get_template_directory();

    /** Block in the head such as: cover image, video, ... */
    include $template_path . '/inc/post-details/block-head.php';

    /** Loop to genarate fice sections of post */
    $j = 0;
    for ($i = 1; $i <= NUM_SECTIONS; $i++) {
        $section_cover_img = wp_get_attachment_image_src(get_post_meta($article->ID, constant("CFS_S{$i}_COVER_BG"), true));
        $section_cover_color = get_post_meta($article->ID, constant("CFS_S{$i}_COVER_COLOR"), true);
        //$section_title       = mb_substr(get_post_meta($article->ID, constant("CFS_S{$i}_TITLE"), true), 0, CFS_SECTION_TITLE_MAX, 'utf-8');
        $section_title = get_post_meta($article->ID, constant("CFS_S{$i}_TITLE"), true);
        $section_map = get_post_meta($article->ID, constant("CFS_S{$i}_MAP_LINK"), true);
        $location_address = get_post_meta($article->ID, constant("CFS_S{$i}_LOCATION_ADDRESS"), true);
        $section_text1 = get_post_meta($article->ID, constant("CFS_S{$i}_TEXT_1"), true);
        $section_text2 = get_post_meta($article->ID, constant("CFS_S{$i}_TEXT_2"), true);
        $section_text3 = get_post_meta($article->ID, constant("CFS_S{$i}_TEXT_3"), true);
        $post_images = fmc_get_num_post_img($article->ID, $i);
        $num_img = count($post_images);
        /**
         * This code will extract all index name in array
         * to variable. dump the array to view the name.
         */
        extract($post_images);

        $backroud_style = '';
        $white_state = '';
        if (fmc_check_detail_image($section_cover_img)) {
            $backroud_style = "style='background-image: url(\"{$section_cover_img[0]}\")'";
        }
        elseif (false !== $section_cover_color && '' !== $section_cover_color) {
            $fixed_bg_color = array(CFS_SECTION_BG_RED, CFS_SECTION_BG_WHITE);
            if (in_array($section_cover_color, $fixed_bg_color)) {
                $backroud_style = "style='background-color: {$section_cover_color}'";
            }

            if ($section_cover_color === CFS_SECTION_BG_RED) {
                $white_state = 'white-state';
            }
        }

        /** Get location for view on map link on each section */
        $map_link = false;
        $post_social_id = 0;
        if (false !== $section_map && '' !== $section_map) {
            //Get post id by feed id
            $post_meta = $wpdb->get_results("SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_key='sf_feed_id' AND meta_value = '{$section_map}' ORDER BY post_id DESC", OBJECT);
            
            if (count($post_meta)) {
                $post_social_id = $post_meta[0]->post_id;
            }

            if ($post_social_id !== 0) {
                //Section map variable content feed id in true case
                //Get map location
                $map_location = get_post_meta($post_social_id, SF_LOCATION, true);
                if (false !== $map_location && '' !== $map_location) {
                    $map_link = json_decode($map_location);
                }
            }
        }

        //Link view on map for each section
        if (false !== $map_link) {
            $country = fmc_escape_get(COUNTRY, DEFAULT_COUNTRY, fmc_langs());
            $map_link = fmc_get_page_url(SOCIALFEEDS) . '?latitude='
                    . $map_link->latitude
                    . '&amp;longitude='
                    . $map_link->longitude
                    . '&amp;id=' . $post_social_id
            ;
        }

        //Grow number of block
        if ($num_img) {
            $j++;
        }
        /**
         * Base on number of images in a section to get the correct section layout
         * There are 5 layout sections for 1, 2, 3, 4, 5 images for each case
         */
        switch ($num_img) {
            case 1:
                include $template_path . '/inc/post-details/block-1-image.php';
                break;
            case 2:
                include $template_path . '/inc/post-details/block-2-image.php';
                break;
            case 3:
                include $template_path . '/inc/post-details/block-3-image.php';
                break;
            case 4:
                include $template_path . '/inc/post-details/block-4-image.php';
                break;
            case 5:
                include $template_path . '/inc/post-details/block-5-image.php';
                break;
            default:
                break;
        }
    }
}

/** Other posts */
$wp_count_post = wp_count_posts();
if ($wp_count_post->publish > 1) {
    include $template_path . '/inc/post-details/other-posts.php';
}
get_footer();
