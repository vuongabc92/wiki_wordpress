<?php
// Setup class
  $instagram = new Instagram(array(
    'apiKey'      => '55ba35afc6b64285947494750b27bc7a',
    'apiSecret'   => '49e736f773c94228bc2afb43332d8337',
    'apiCallback' => 'http://localhost/api/instagram/home.php' // must point to success.php
  ));

?>
