<?php
/*
Plugin Name: FuelMyCity Social Feed
Plugin URI: #
Description: Get feed from three socials Facebook, Twitter, Instagram
Version: 1.0
Author: FuelMyCity Develop Team
Text Domain: fmc_social_feed
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * FMC_Social_Feed class.
 */
require_once 'inc/constant.php';

/**
 * Class social feed
 */
class FMC_Social_Feed {

    public static $file;

    /**
     * @constructor
     *
     * Include neccessary files
     */
    public function __construct()
    {
        self::$file = __FILE__;
        require_once 'inc/admin/sf-post.php';
        require_once 'inc/admin/admin.php';
        require_once 'inc/class/front.php';
        //Load social feed class
        require_once 'inc/class/facebook.php';

        //Cron job update social data
        require_once 'inc/cron/facebook.php';
        require_once 'inc/cron/twitter.php';
        require_once 'inc/cron/instagram.php';

        require_once 'inc/kol/user-roles.php';
        require_once 'inc/ajax-functions.php';

    }
}
//Initialize
$GLOBALS['fmc_social_feed'] = new FMC_Social_Feed();

