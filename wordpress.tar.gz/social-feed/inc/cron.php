<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
/**
 * To set up the wordpress schedule
 */
class FMC_Social_Feeds_Cron
{

    public $task_hook_name;
    public $schedule_time;
    public $name;
    public $limit;
    public $post_updated = 0;
    public function schedule_event()
    {
        //Prepare schedule for this feed type
        $schedule = $this->get_schedule();
        if (!wp_next_scheduled($this->task_hook_name)) {
            wp_schedule_event(time(), $schedule, $this->task_hook_name);
        }

    }

    public function remove_schedule_event()
    {
        remove_action($this->task_hook_name, array($this, 'do_event'));
        wp_clear_scheduled_hook($this->task_hook_name);
    }

    public function clear_scheduled_event()
    {
        wp_clear_scheduled_hook($this->task_hook_name);
    }
    /**
     * @todo Do event - update like, comment, share ....
     */
    public function do_event()
    {
        $log_path = plugin_dir_path(FMC_Social_Feed::$file) . DIRECTORY_SEPARATOR . 'debug.log';
        if (!file_exists($log_path)) {
            #mkdir($log_path);
        }
        $task_name = 'site_'.get_current_blog_id() . '_'.  $this->task_hook_name;
        $message = "###".date("Y-m-d H:i:s").": Cron {$task_name} has been start\n";
        $message .= "{$this->post_updated} posts have been updated###\n\n";
        error_log($message, 3, $log_path);
    }

    public function get_schedule()
    {
        $schedules = wp_get_schedules();
        $matches = array_filter($schedules, array($this, 'filter_schedules_callback'));
        if (!empty($matches)) {
            reset($matches);
            return key($matches);
        }
        add_filter('cron_schedules', array($this, 'add_custom_schedule'));
        return $this->task_hook_name;
    }

    public function filter_schedules_callback($schedule)
    {
        return $schedule['interval'] == $this->schedule_time && 1;
    }

    public function add_custom_schedule()
    {
        $schedules[$this->task_hook_name] = array(
            'interval' => $this->schedule_time, // seconds
            'display' => __('Custom ' . $this->name . ' Time', FMC_Social_Feed_Constant::TEXTDOMAIN)
        );
        return $schedules;
    }
    public function get_feed_ids($channel, $paged = 1, $limit = 25) {
        $args = array(
            'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'paged' => $paged
        );
        $args['tax_query'] = array(
            array(
                'taxonomy' => FMC_Social_Feed_Constant::SOCIAL_TYPE,
                'field' => 'slug',
                'terms' => $channel,
            )
        );
        $result = array();
        $posts_query = new WP_Query($args);
        if (is_wp_error($posts_query)) return;
        $result['max_num_pages'] = $posts_query->max_num_pages;
        if ($posts_query->have_posts()) {
            while ($posts_query->have_posts()) {
                $posts_query->the_post();
                $result['posts'][get_the_ID()] = get_post_meta(get_the_ID(), 'sf_ob_id', true);
            }
        }
        return $result;
    }
}