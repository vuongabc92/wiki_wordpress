<?php

if (!function_exists('sf_ajax_get_feeds')) {

    /**
     * AJAX!
     *
     * Get feeds with a limit number and page (option)
     *
     * @return json
     */
    function sf_ajax_get_feeds() {
        include_once 'admin/views/save-feeds.php';

        $feeds = new FMC_Get_Social_Feeds();
        $list_site = get_list_site();
        foreach ($list_site as $site) {
            switch_to_blog($site->blog_id);
            $feeds->save_feeds();
        }

        restore_current_blog();
        wp_die();
    }

    add_action("wp_ajax_nopriv_save-social-feeds", "sf_ajax_get_feeds");
    add_action("wp_ajax_save-social-feeds", "sf_ajax_get_feeds");
}

if (!function_exists('get_list_site')) {

    function get_list_site($expires = 7200) {
        if (!is_multisite())
            return false;

        // Because the get_blog_list() function is currently flagged as deprecated
        // due to the potential for high consumption of resources, we'll use
        // $wpdb to roll out our own SQL query instead. Because the query can be
        // memory-intensive, we'll store the results using the Transients API
        if (false === ( $site_list = get_transient('multisite_site_list') )) {
            global $wpdb;
            $site_list = $wpdb->get_results('SELECT * FROM ' . $wpdb->blogs . ' ORDER BY blog_id');
            // Set the Transient cache to expire every two hours
            set_site_transient('multisite_site_list', $site_list, $expires);
        }

        return $site_list;
    }

}

if (!function_exists('sf_ajax_change_location_feeds')) {

    /**
     * AJAX!
     *
     * Get feeds with a limit number and page (option)
     *
     * @return json
     */
    function sf_ajax_change_location_feeds() {
        include_once 'admin/views/save-feeds.php';

        $feeds = new FMC_Get_Social_Feeds();
        $list_site = get_list_site();
        foreach ($list_site as $site) {
            switch_to_blog($site->blog_id);
            $feeds->change_location_social_feeds();
        }

        restore_current_blog();
        wp_die();
    }

    add_action("wp_ajax_nopriv_change-location-social-feeds", "sf_ajax_change_location_feeds");
    add_action("wp_ajax_change-location-social-feeds", "sf_ajax_change_location_feeds");
}