<?php

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class FMC_Social_Feed_Constant
{

    const TEXTDOMAIN = 'FuelMyCity';
    const POST_TYPE = 'social_feed';
    const SOCIAL_TYPE = 'social_type';
    const PENDING = 'pending';
    const HIDE = 'draft';
    const DELETE = 'delete';
    const APPROVED = 'publish';
    const UPDATE = 'update';
    const KOL_USER = 'yes';
    const NOT_KOL_USER = 'no';
    const ADMIN_USER = 'yes';
    const DEFAULT_HASHTAG = '#fuelmycity';
    
    const SEPARATE_SOCIAL_ID_COMMA = ',';
    const SEPARATE_SOCIAL_ID_SEMICOLON = ';';

    //Social Type
    const SF_FACEBOOK = 'sf-facebook';
    const SF_TWITTER = 'sf-twitter';
    const SF_INSTAGRAM = 'sf-instagram';
    const SF_FACEBOOK_URL = 'https://graph.facebook.com/';
    const SF_FACEBOOK_FIELDS = 'id,message,picture,full_picture,link,from,place,object_id,updated_time,type';
    const SF_FACEBOOK_LIMIT = 'limit=50';
    const SF_TWITTER_URL_TIMELIME = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
    const SF_TWITTER_URL_TWEET = 'https://api.twitter.com/1.1/search/tweets.json';
    const SF_TWITTER_URL_LOOKUP = 'https://api.twitter.com/1.1/statuses/show.json';
    const SF_TWITTER_COUNT = 'count=30';
    const SF_TWITTER_METHOD = 'GET';
    const SF_INSTAGRAM_URL = 'https://api.instagram.com/v1/tags/';
    const SF_INSTAGRAM_URL_MEDIA = 'https://api.instagram.com/v1/media/';
    const SF_GOOGLEMAP_API = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=';
}

class FMC_Social_Feed_Config extends FMC_Social_Feed_Constant
{

    /**
     * Generate facebook rest url
     *
     * @param array $params list contain hashtags, app_id, token
     *
     * @return type
     */
    public static function generate_fb_url($params)
    {
        $access_token = 'access_token=' . $params['app_secret'];
        $base_url = self::SF_FACEBOOK_URL;
        $fields = $params['app_id'] . '/feed?fields=' . self::SF_FACEBOOK_FIELDS;

        return $base_url . $fields . '&&' . $access_token . '&expires=5183987';
    }

    /**
     * Check does the feed exist in DB
     *
     * @param string $social_type social feed type
     * @param string $feed_id     feed id
     *
     * @return boolean true mean the post exist and false for the otherwise
     */
    public static function check_post_exist($social_type, $feed_id)
    {
        $args = array(
            'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => 'sf_feed_id',
                    'value' => $feed_id,
                    'compare' => '=',
                ),
                'relation' => 'AND',
                array(
                    'key' => 'sf_feed_social_type',
                    'value' => $social_type,
                    'compare' => '=',
                )
            )
        );
        wp_reset_query();

        $check_existed = new WP_Query($args);
        if ($check_existed->have_posts()) {
            return true;
        } else {
            return false;
        }
    }
}
