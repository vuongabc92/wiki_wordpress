<?php

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class FMC_Social_Feed_Instagram
{

    public function get_config()
    {

    }

}