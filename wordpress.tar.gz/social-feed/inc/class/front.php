<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
class Fmc_Social_Feeds_Front
{
    var $feeds_query;
    public function ajax_get_feeds_callback() {
        $response = array('total' => 0, 'content' => '');
        $channels = array_keys(FMC_Social_Feed_Config::list_social(1));
        $tax_ids = array();
        if (defined('DOING_AJAX')) {
            $channels = $_REQUEST['channel'];
        }
        if (count($channels)) {
            $args = array(
                'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
                'post_status' => 'publish',
                'posts_per_page' => 12,
                'paged' => (int) $_REQUEST['page']+1,
                'order' => 'DESC',
                'orderby' => 'meta_value',
                'meta_key' => 'sf_date'
            );
            if (!empty($_REQUEST['txtSearch'])) {
                $args['s'] = $_REQUEST['txtSearch'];
            }
            foreach ($channels as $channel) {
                $tax_ids[] = $channel;
            }
            $args['tax_query'] = array(
                 array(
                    'taxonomy' => FMC_Social_Feed_Constant::SOCIAL_TYPE,
                    'field' => 'slug',
                    'terms' => $tax_ids,
                )
            );

            $feeds_query = new WP_Query($args);
            $response['total'] = $feeds_query->found_posts;

            if ($feeds_query->have_posts()) {
                $this->feeds_query = $feeds_query;
                $response['content'] = $this->render_feed();
            }
            //Search by keywords

        }
        echo $response['content'];
        //return;
        if (defined('DOING_AJAX')) {
            exit;
        }
    }
    public function render_feed() {
        ob_start();
        $template = plugin_dir_path(FMC_Social_Feed::$file) . 'templates/feeds.php';
        require $template;
        $content = ob_get_contents();
        ob_get_clean();
        return $content;
    }
}
$social_front = new Fmc_Social_Feeds_Front();
add_action('wp_ajax_ajax_get_feeds', array($social_front, 'ajax_get_feeds_callback'));
add_action('wp_ajax_nopriv_ajax_get_feeds', array($social_front, 'ajax_get_feeds_callback'));