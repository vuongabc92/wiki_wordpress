<?php

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class FMC_Social_Feed_Facebook
{

    public function access_token()
    {
        $app_id = "561788003926520";
        $app_secret = "6532327adfcd0cdc7a17f89a96b54223";
        // Exchange token
        $path = plugin_dir_path(FMC_Social_Feed::$file);
        require_once $path . 'lib/facebook/src/facebook.php';

        $facebook = new Facebook(array(
            'appId' => $app_id,
            'secret' => $app_secret,
        ));
        // Set Extended Access Token
        $facebook->setExtendedAccessToken();

        // Get access short live access token
        $accessToken = $facebook->getAccessToken();
        // Exchange token
        try {
            $res = $facebook->api('/oauth/access_token', 'POST', array(
                'grant_type' => 'fb_exchange_token',
                'client_id' => '278548522343797',
                'client_secret' => $app_secret,
                'fb_exchange_token' => $accessToken
                    )
            );
            echo "<pre>";
            print_r($res);
            echo "</pre>";die;
        } catch (Exception $e) {
            echo "<pre>";
                print_r($e);
             echo "</pre>";
        }
    }
}
