<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class FMC_Social_Feed_Admin {
    public function __construct()
    {
        require_once 'sf-settings.php';
        require_once 'crawl.php';
    }
}
//Initialize
$GLOBALS['fmc_social_feed_admin'] = new FMC_Social_Feed_Admin();