<div class="wrap">
    <?php screen_icon();?>

    <h2> <?php _e('Social Feeds Setting'); ?> </h2>
    <?php if($this->updated) { ?>
        <div id="message" class="updated">
            <p><strong><?php _e('Settings saved.') ?></strong></p>
        </div>
    <?php } ?>
    <form name="my_form" method="post">
        <input type="hidden" name="action" value="sf-setting-action">
        <?php
        wp_nonce_field('sf-setting-action-nonce');

        /* Used to save closed metaboxes and their order */
        wp_nonce_field('meta-box-order', 'meta-box-order-nonce', false);
        wp_nonce_field('closedpostboxes', 'closedpostboxesnonce', false);
        ?>

        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-<?php echo 1 == get_current_screen()->get_columns() ? '1' : '2'; ?>">

                <div id="post-body-content">
                    <p> This page allow admin user access to configure social feed page. Admin have access to the APIs built to
                        connect with the social media network.
                    <p>
                </div>

                <div id="postbox-container-1" class="postbox-container">
                    <?php //do_meta_boxes('', 'side', null); ?>
                </div>

                <div id="postbox-container-2" class="postbox-container">
                    <?php do_meta_boxes('', 'normal', null); ?>
                    <?php do_meta_boxes('', 'advanced', null); ?>
                    <p class="submit"><input type="submit" value="Save Changes" class="button button-primary" id="submit" name="submit"></p>
                </div>

            </div> <!-- #post-body -->
        </div> <!-- #poststuff -->

    </form>

</div><!-- .wrap -->