<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<table class="wp-list-table widefat fixed posts">
    <tr>
        <td width="50%"><strong><?php _e('Feed title.') ?></strong></td>
        <td width="20%"><strong><?php _e('Feed images.') ?></strong></td>
        <td width="10%"><strong><?php _e('Feed like.') ?></strong></td>
        <td width="10%"><strong><?php _e('Feed comment.') ?></strong></td>
        <td width="10%"><strong><?php _e('Feed approve.') ?></strong><br>
            <input type="checkbox" name="sf-all" id="sf-all" onchange="select_all(this)"> </td>
    </tr>
    <tbody>
<?php
if (count($data_feed)) {
    foreach ($data_feed as $row) {
        $check_exist = FMC_Social_Feed_Config::check_post_exist(FMC_Social_Feed_Constant::SF_YOUTUBE, $row['id']);
        if ($check_exist) {
            ?>
                    <tr valign="top">
                        <td><?php echo $row['text'] ?>
                            <input type="hidden" name="sf_title[]" value="<?php echo $row['text'] ?>">
                            <input type="hidden" name="sf_link[]" value="<?php echo 'https://twitter.com/' . $row['user']['screen_name'] . '/status/' . $row['id'] ?>">
                        </td>
                        <td><?php if (isset($row['entities']['media'][0]['media_url'])) { ?>
                                <image width="100" src="<?php echo $row['entities']['media'][0]['media_url'] ?>"/>
                            <?php } ?>
                                <input type="hidden" name="sf_image[]" value="<?php if ($row->picture) echo $row->picture;
                                            else echo '' ?>">
                        </td>
                        <td><?php echo $row['favorite_count'] ?>
                            <input type="hidden" name="sf_like[]" value="<?php echo $row['favorite_count']  ?>">
                        </td>
                        <td><?php echo $row['retweet_count'] ?>
                            <input type="hidden" name="sf_comment[]" value="<?php echo $row['retweet_count'] ?>">
                        </td>
                        <td> <input type="checkbox" name="sf_id[]" value="<?php echo $row['id'] ?>">
                            <input type="hidden" name="sf_date[]" value="<?php echo FMC_Social_Feed_Config::convert_time($row['created_at']) ?>"> </td>
                    </tr>
                    <?php
                }
            }
        }
        else {
            ?>
        <td colspan="5"><?php _e('No Feed Content.') ?> </td>
    <?php } ?>
</tbody>
</table>