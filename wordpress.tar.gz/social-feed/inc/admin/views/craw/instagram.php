<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<table class="wp-list-table widefat fixed posts">
                         <tr>
                             <td width="50%"><strong><?php _e('Feed title.') ?></strong></td>
                             <td width="20%"><strong><?php _e('Feed images.') ?></strong></td>
                             <td width="10%"><strong><?php _e('Feed like.') ?></strong></td>
                             <td width="10%"><strong><?php _e('Feed comment.') ?></strong></td>
                              <td width="10%"><strong><?php _e('Feed approve.') ?></strong><br>
                                 <input type="checkbox" name="sf-all" id="sf-all" onchange="select_all(this)"> </td>
                         </tr>
                                <tbody>
                                    <?php if(count($data_feed->data)) {
                                    foreach($data_feed->data as $row) {
                                        $check_exist = FMC_Social_Feed_Config::check_post_exist(FMC_Social_Feed_Constant::SF_INSTAGRAM,$row->id);

                                        if($check_exist) {?>
                                    <tr valign="top">
                                        <td><?php echo $row->caption->text ?>
                                            <input type="hidden" name="sf_title[]" value="<?php echo $row->caption->text ?>">
                                            <input type="hidden" name="sf_link[]" value="<?php echo $row->link ?>">
                                        </td>
                                        <td><?php
                                            if($row->images->standard_resolution->url){?>
                                            <image width="100" src="<?php echo $row->images->standard_resolution->url ?>"/>
                                             <?php } ?>
                                            <input type="hidden" name="sf_image[]" value="<?php if($row->images->standard_resolution->url) echo $row->images->standard_resolution->url ?>">

                                        </td>
                                         <td><?php echo  $row->likes->count ?>
                                         <input type="hidden" name="sf_like[]" value="<?php echo  $row->likes->count ?>">
                                         </td>
                                            <td><?php echo  $row->comments->count ?>
                                            <input type="hidden" name="sf_comment[]" value="<?php echo $row->comments->count ?>">
                                            </td>
                                            <td> <input type="checkbox" name="sf_id[]" value="<?php echo $row->id?>">
                                            <input type="hidden" name="sf_date[]" value="<?php echo gmdate("Y-m-d g:i:s", $row->created_time); ?>"></td>
                                        </tr>
                                    <?php }
                                        }
                                        }  else { ?>
                                <td colspan="5"><?php _e('No Feed Content.') ?> </td>
                                        <?php }?>
                                </tbody>
                            </table>

