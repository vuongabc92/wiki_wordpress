<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<table class="wp-list-table widefat fixed posts">
    <tr>
        <td width="60%"><strong><?php _e('Feed content.') ?></strong></td>
        <td width="30%"><strong><?php _e('Feed image.') ?></strong></td>
        <td width="10%"><strong><?php _e('Feed approve.') ?></strong><br>
            <input type="checkbox" name="sf-all" id="sf-all" onchange="select_all(this)">
        </td>
    </tr>
    <tbody>
        <?php
        if (count($data_feed->data)) {
            foreach ($data_feed->data as $row) {
                $check_exist = FMC_Social_Feed_Config::check_post_exist(FMC_Social_Feed_Constant::SF_FACEBOOK, $row->object_id);
                if ( ! $check_exist and $row->message != '') {
                    ?>
                    <tr valign="top">
                        <td><?php echo $row->message ?>
                            <input type="hidden" name="sf_title[]" value="<?php echo $row->message ?>">
                            <input type="hidden" name="sf_link[]" value="<?php echo $row->link ?>">
                        </td>
                        <td>
                            <?php if (isset($row->picture)) { ?>
                                <image width="130" src="<?php echo $row->picture ?>"/>
                                <input type="hidden" name="sf_image[]" value="<?php echo $row->picture; ?>">
                            <?php } else { _e('<i>NO IMAGE</i>'); } ?>
                        </td>
                        <td>
                            <input type="checkbox" name="sf_id[]" value="<?php echo $row->object_id ?>">
                            <input type="hidden" name="sf_date[]" value="<?php echo FMC_Social_Feed_Config::convert_time($row->created_time) ?>">
                        </td>
                    </tr>
                    <?php
                }
            }
        } else {
            ?>
        <td colspan="5"><?php _e('No Feed Content.') ?> </td>
    <?php } ?>
</tbody>
</table>