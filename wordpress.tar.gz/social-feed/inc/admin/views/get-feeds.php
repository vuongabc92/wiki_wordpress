<?php
include_once 'save-feeds.php';

$feeds = new FMC_Get_Social_Feeds();
$feeds->save_feeds();