<?php

/**
 * Get feeds from social enginer: Facebook, Twitter, Instagram
 */
class FMC_Get_Social_Feeds {

    private $_list_blog_user;

    /**
     * Update the status of feeds
     *
     * @param array  $feed_id List of feed id
     * @param string $status Action string
     *
     * @return boolean
     * @throws \Exception
     */
    public static function change_feed_status($feed_id, $status) {
        global $wpdb;
        $status_list = array(
            FMC_Social_Feed_Constant::HIDE,
            FMC_Social_Feed_Constant::APPROVED
        );

        //Check does the status got from request exist
        if (!in_array($status, $status_list)) {
            return false;
        }

        if (!count($feed_id)) {
            return false;
        }

        //Update feed status
        foreach ($feed_id as $id) {
            //Get post id by feed id
            $post_meta = $wpdb->get_results("SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_value = '{$id}'", OBJECT);
            $post_id = 0;
            if (count($post_meta)) {
                $post_id = $post_meta[0]->post_id;
            }

            try {
                foreach ($post_meta as $item) {
                    $update_data = array(
                        'ID' => $item->post_id,
                        'post_status' => $status
                    );
                    wp_update_post($update_data, TRUE);
                }
            }
            catch (Exception $ex) {
                throw new \Exception(__('Opp!! Somethings went wrong. ' . $ex->getMessage()));
            }
        }

        return true;
    }

    public static function update_feeds($feed_ids, $status) {
        if ($status !== FMC_Social_Feed_Constant::UPDATE) {
            return fasle;
        }

        if (!count($feed_ids)) {
            return false;
        }

        //Update feed status
        global $wpdb;
        $social_feed = new FMC_Get_Social_Feeds();
        foreach ($feed_ids as $feed_id) {
            //Get post id by feed id
            $post_meta = $wpdb->get_results("SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_key='sf_feed_id' AND meta_value = '{$feed_id}' ORDER BY post_id DESC", OBJECT);
            $post_id = 0;
            if (count($post_meta)) {
                $post_id = $post_meta[0]->post_id;
            }

            $social_type = get_post_meta($post_id, 'sf_feed_social_type', true);
            $data = '';

            $fb_user_id = array();
            $tw_user_id = array();
            $in_user_id = array();

            global $wpdb;
            // get list user of all site
            $users = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . $wpdb->users));
            if (count($users)) {
                // get facebook_id, twitter_id, instagram_id of all users to array
                foreach ($users as $user) {
                    //$country = get_user_meta($user->data->ID, FMC_Country::USER_META_KEY, true);
                    $fb = get_user_meta($user->ID, 'facebook_id', true);
                    $tw = get_user_meta($user->ID, 'twitter_id', true);
                    $in = get_user_meta($user->ID, 'instagram_id', true);

                    if (false !== $fb && $fb !== '') {
                        $fb_user_id[$user->ID] = preg_split('/[;,]/', $fb);
                    }

                    if (false !== $tw && $tw !== '') {
                        $tw_user_id[$user->ID] = preg_split('/[;,]/', $tw);
                    }

                    if (false !== $in && $in !== '') {
                        $in_user_id[$user->ID] = preg_split('/[;,]/', $in);
                    }
                }
            }

            switch ($social_type) {
                case FMC_Social_Feed_Constant::SF_FACEBOOK:
                    $data = $social_feed->get_facebook_by_feedid($feed_id);
                    if (!empty($data)) {
                        $social_feed->save_feed($data, $social_type, $fb_user_id, TRUE);
                    }
                    break;

                case FMC_Social_Feed_Constant::SF_INSTAGRAM:
                    $data = $social_feed->get_instagram_by_feedid($feed_id);
                    if (!empty($data)) {
                        $social_feed->save_feed($data, $social_type, $in_user_id, TRUE);
                    }
                    break;

                case FMC_Social_Feed_Constant::SF_TWITTER:
                    $data = $social_feed->get_twitter_by_feedid($feed_id);
                    if (!empty($data)) {
                        $social_feed->save_feed($data, $social_type, $tw_user_id, TRUE);
                    }
                    break;

                default:
                    break;
            }
        }

        return true;
    }

    public static function delete_feeds($feed_id = array()) {

        if (count($feed_id)) {
            global $wpdb;

            foreach ($feed_id as $id) {
                $post_meta = $wpdb->get_results("SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_value = '{$id}'", OBJECT);

                try {
                    foreach ($post_meta as $item) {
                        $post_id = $item->post_id;
                        wp_delete_post($post_id);
                    }
                }
                catch (Exception $ex) {
                    throw new \Exception(__('Opp!! Somethings went wrong. ' . $ex->getMessage()));
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Display status follow feed status in DB
     *
     * @param string $db_status status from DB
     *
     * @return string the feed status
     */
    public static function display_feed_status($db_status) {
        $status = '';
        switch ($db_status) {
            case FMC_Social_Feed_Constant::APPROVED :
                $status = __('Approved');
                break;

            case FMC_Social_Feed_Constant::HIDE :
                $status = __('Hide');
                break;

            default:
                $status = __('Pending');
                break;
        }

        return $status;
    }

    public function get_kol_social_ids(&$fb_user_id, &$tw_user_id, &$in_user_id){
        global $wpdb;
        // get list user of all site
        $users = $wpdb->get_results('SELECT * FROM ' . $wpdb->users);
        if (count($users)) {
            // get facebook_id, twitter_id, instagram_id of all users to array
            foreach ($users as $user) {
                //$country = get_user_meta($user->data->ID, FMC_Country::USER_META_KEY, true);
                $fb = get_user_meta($user->ID, 'facebook_id', true);
                $tw = get_user_meta($user->ID, 'twitter_id', true);
                $in = get_user_meta($user->ID, 'instagram_id', true);
                $this->_list_blog_user[$user->ID] = get_user_meta($user->ID, 'primary_blog');

                if (false !== $fb && $fb !== '') {
                    $fb_user_id[$user->ID] = preg_split('/[;,]/', $fb);
                }

                if (false !== $tw && $tw !== '') {
                    $tw_user_id[$user->ID] = preg_split('/[;,]/', $tw);
                }

                if (false !== $in && $in !== '') {
                    $in_user_id[$user->ID] = preg_split('/[;,]/', $in);
                }
            }
        }
    }

        /**
     * * Get feeds from each social engines and save one by one into DB like a post
     * The order of social will be:
     *  1. Facebook
     *  2. Twitter
     *  3. Instagram
     *
     *
     * @return boolean
     * @throws \Exception
     */
    public function save_feeds() {
        try {
            $this->_list_blog_user = array();

            //Get all feeds
            $facebook_feeds = $this->get_facebook_feeds();
            $twitter_feeds = $this->get_twitter_feeds();
            $instagram_feeds = $this->get_instagram_feeds();

            $fb_user_id = array();
            $tw_user_id = array();
            $in_user_id = array();

            $this->get_kol_social_ids($fb_user_id, $tw_user_id, $in_user_id);

            $supper_admin_id = FMC_Country::SUPPER_ADMIN;
            $fb_admin_id = array(get_user_meta($supper_admin_id, 'facebook_id', true));
            $tw_admin_id = array(get_user_meta($supper_admin_id, 'twitter_id', true));
            $in_admin_id = array(get_user_meta($supper_admin_id, 'instagram_id', true));


            //Save all feeds one by one
            $log_head = '#BEGIN:' . "\n\n";
            $time = date('Y-m-d h:i:s');
            $ip = $_SERVER['REMOTE_ADDR'];
            $log_content = '';
            $save_info = $this->save_feed_one_by_one($facebook_feeds, FMC_Social_Feed_Constant::SF_FACEBOOK, $fb_user_id, $fb_admin_id);
            $log_content .= $this->write_log(false, '', $save_info['number'], $save_info['list_feed'], FMC_Social_Feed_Constant::SF_FACEBOOK, $save_info['while']);

            $save_info = $this->save_feed_one_by_one($twitter_feeds, FMC_Social_Feed_Constant::SF_TWITTER, $tw_user_id, $tw_admin_id);
            $log_content .= $this->write_log(false, '', $save_info['number'], $save_info['list_feed'], FMC_Social_Feed_Constant::SF_TWITTER, $save_info['while']);

            $save_info = $this->save_feed_one_by_one($instagram_feeds, FMC_Social_Feed_Constant::SF_INSTAGRAM, $in_user_id, $in_admin_id);
            $log_content .= $this->write_log(false, '', $save_info['number'], $save_info['list_feed'], FMC_Social_Feed_Constant::SF_INSTAGRAM, $save_info['while']);

            $log_foot = '#END;' . "\n\n\n\n";
            $common = 'Ip: ' . $ip . "\nTime: " . $time . "\n\n";

            $this->write_log(true, $log_head . $common . $log_content . $log_foot, 0, '', 0, 0);
        }
        catch (Exception $ex) {
            throw new \Exception(__('Opp!! Somethings went wrong. ' . $ex->getMessage()));
        }

        return true;
    }

    /**
     * Write log every cronjob call to save feeds
     *
     * @param int    $num_posts
     * @param array  $list_saved
     * @param string $social_type
     * @param float  $while
     *
     * @return void
     * @throws Exception
     */
    public function write_log($is_write = true, $log_content = '', $num_posts, $list_saved, $social_type, $while) {
        $file = WP_CONTENT_DIR . '/' . FEED_LOG;
        $type = '';
        switch ($social_type) {
            case 'sf-facebook':
                $type = 'Facebook';
                break;
            case 'sf-twitter':
                $type = 'Twitter';
                break;
            case 'sf-instagram':
                $type = 'Instagram';
                break;
            default:
                break;
        }

        if (!is_dir($file) && !file_exists($file)) {
            fopen($file, 'w');
            chmod($file, 0777);
            throw new Exception("Opp!! {$file} doesn't exist.");
        }

        if ($num_posts) {
            $msg = "{$type}\n{$num_posts} feed(s)\n{$list_saved}\n\n";

            if (!$is_write) {
                return $msg;
            }
        }

        if ($is_write) {
            error_log($log_content, 3, $file);
        }

        return '';
    }

    /**
     *
     * @param array  $feeds List of feeds
     * @param string $social_type
     *
     * @return boolean
     * @throws \Exception
     */
    public function save_feed_one_by_one($feeds, $social_type, $kol_social_user_id, $admin_social_id = array()) {
        $feed_saved = 0;
        $list_saved = array();
        $start_time = microtime();

        try {
            if (count($feeds)) {
                foreach ($feeds as $feed) {
                    $feed_exist = FMC_Social_Feed_Config::check_post_exist($social_type, $feed['id']);
                    if (!$feed_exist) {
                        $this->save_feed($feed, $social_type, $kol_social_user_id, false, $admin_social_id);
                        $feed_saved++;
                        $list_saved[] = $feed['id'];
                    }

                    if ($feed_exist && isset($feed['updated_at']) && $feed['updated_at'] !== $feed['created_at']) {
                        $this->save_feed($feed, $social_type, $kol_social_user_id, true, $admin_social_id);
                        $feed_saved++;
                        $list_saved[] = $feed['id'];
                    }
                }
            }
        }
        catch (Exception $ex) {
            throw new \Exception(__('Opp!! Somethings went wrong. ' . $ex->getMessage()));
        }
        $end_time = microtime();
        $while = round($end_time - $start_time, 5);

        return array(
            'number' => $feed_saved,
            'list_feed' => implode('|', $list_saved),
            'while' => $while
        );
    }

    /**
     * Save feeds into DB, the feed will be
     * saved like a post in WP but different post type and contain some post meta
     * check function for more details
     *
     * @param array   $feed               List feeds from one social engine
     * @param string  $social_type        Social type
     * @param array   $kol_social_user_id List kol user id
     * @param boolean $modified           Whether the feed modified or not
     *
     *
     * @return boolean
     * @throws \Exception
     * SELECT * FROM `caltex_postmeta` WHERE meta_key IN ('sf_feed_id', 'sf_feed_picture', 'sf_feed_link', 'sf_feed_from_id', 'sf_feed_from_name', 'sf_feed_from_avatar', 'sf_feed_social_type', 'sf_feed_created_at', 'sf_feed_created_timestamp', 'sf_feed_location', 'sf_feed_is_kol')
     */
    public function save_feed($feed, $social_type, $kol_social_user_id = array(), $modified = false, $admin_social_id = array()) {
        try {
            $key_user_id = recursive_return_array_value_by_key($feed['from_id'], $kol_social_user_id);
            if ($modified) {
                /** Update feed content when user edit post on FB social engine */
                //Get feed that was edited
                $args = array(
                    'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
                    'meta_key' => 'sf_feed_id',
                    'meta_value' => $feed['id'],
                    'post_status' => 'any'
                );
                $post_modified = get_posts($args);
                //Check has feed
                if (count($post_modified)) {
                    $post_modified = $post_modified[0];
                    $post_obj = array(
                        'ID' => $post_modified->ID,
                        'post_title' => $feed['content'],
                        'post_content' => $feed['content'],
                    );

                    //Update feed data
                    $post_id = wp_update_post($post_obj);
                    $created = new \DateTime($feed['created_at']);
                    //Add post meta
                    update_post_meta($post_id, 'sf_feed_picture', $feed['picture']);

                    if ($feed['location'] !== NULL) {
                        update_post_meta($post_id, 'sf_feed_location', json_encode($feed['location']));
                    }
                    else {
                        update_post_meta($post_id, 'sf_feed_location', $feed['location']);
                    }
                    if ($key_user_id !== -1) {
                        //$kol_social_user_id = array_flip($kol_social_user_id);
                        //$country            = get_user_meta($kol_social_user_id[$feed['from_id']], FMC_Country::USER_META_KEY, true);
                        update_post_meta($post_id, 'sf_feed_is_kol', FMC_Social_Feed_Constant::KOL_USER);
                        update_post_meta($post_id, 'sf_wp_kol_id', $key_user_id);
                        //add_post_meta($post_id, 'sf_feed_country', $country);
                    }else{
                        update_post_meta($post_id, 'sf_feed_is_kol', FMC_Social_Feed_Constant::NOT_KOL_USER);
                        update_post_meta($post_id, 'sf_wp_kol_id', '');

                    }
                }
            }
            else {
                global $blog_id;
                // check if user belong to current blog_id

                if ($key_user_id !== -1) {
                    if ($this->_list_blog_user[$key_user_id][0] != $blog_id) {
                        return true;
                    }
                }

                // check lat & long to know country, and add to current country if it belong to site
                if ($feed['location'] !== NULL) {
                    $blog_id_location = $this->get_blogid_by_lat_long($feed['location']['latitude'], $feed['location']['longitude']);

                    if (!empty($blog_id_location) && $blog_id_location != $blog_id) {
                        return true;
                    }
                }

                //Save feed like a post
                $post_obj = array(
                    'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
                    'post_title' => $feed['content'],
                    'post_content' => $feed['content'],
                    'post_status' => FMC_Social_Feed_Constant::PENDING,
                );

                $post_id = wp_insert_post($post_obj);
                $created = new \DateTime($feed['created_at']);
                //Add post meta
                add_post_meta($post_id, 'sf_feed_id', $feed['id']);
                add_post_meta($post_id, 'sf_feed_picture', $feed['picture']);
                add_post_meta($post_id, 'sf_feed_video', $feed['video']);
                add_post_meta($post_id, 'sf_feed_type', $feed['type']);
                add_post_meta($post_id, 'sf_feed_link', $feed['link']);
                add_post_meta($post_id, 'sf_feed_from_id', $feed['from_id']);
                add_post_meta($post_id, 'sf_feed_from_name', $feed['from_name']);
                add_post_meta($post_id, 'sf_feed_from_avatar', $feed['from_avatar']);
                add_post_meta($post_id, 'sf_feed_social_type', $social_type);
                add_post_meta($post_id, 'sf_feed_created_at', $feed['created_at']);
                add_post_meta($post_id, 'sf_feed_created_timestamp', $created->getTimestamp());

                if ($feed['location'] !== NULL) {
                    add_post_meta($post_id, 'sf_feed_location', json_encode($feed['location']));
                }
                else {
                    add_post_meta($post_id, 'sf_feed_location', $feed['location']);
                }

                if (isset($feed['location_name'])) {
                    add_post_meta($post_id, 'sf_feed_location_name', $feed['location_name']);
                }

                if (in_array($feed['from_id'], $admin_social_id)) {
                    add_post_meta($post_id, 'sf_feed_is_admin', FMC_Social_Feed_Constant::ADMIN_USER);
                }
                elseif ($key_user_id !== -1) {
                    //$kol_social_user_id = array_flip($kol_social_user_id);
                    //$country            = get_user_meta($kol_social_user_id[$feed['from_id']], FMC_Country::USER_META_KEY, true);
                    add_post_meta($post_id, 'sf_feed_is_kol', FMC_Social_Feed_Constant::KOL_USER);
                    add_post_meta($post_id, 'sf_wp_kol_id', $key_user_id);
                    //add_post_meta($post_id, 'sf_feed_country', $country);
                }
                else {
                    add_post_meta($post_id, 'sf_feed_is_kol', FMC_Social_Feed_Constant::NOT_KOL_USER);
                }
            }
        }
        catch (Exception $ex) {
            throw new \Exception(__('Opp!! Somethings went wrong. ' . $ex->getMessage()));
        }

        return true;
    }

    /**
     * Get feeds from Facebook via REST API by hashtags
     *
     * @return array
     */
    public function get_facebook_feeds() {
        //Generate Facebook parameters to get feed from FB API
        $fb_params = get_option(FMC_Social_Feed_Constant::SF_FACEBOOK);
        if (empty($fb_params) || !$fb_params) {
            return array();
        }

        if (!is_array($fb_params)) {
            $fb_params = array();
        }
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'app_id' => NULL,
            'app_secret' => NULL
        );
        array_merge($default_value, $fb_params);
        $hashtags_arr = explode(',', $fb_params['sf_handle']);
        if (!count($hashtags_arr)) {
            $hashtags_arr = array(FMC_Social_Feed_Constant::DEFAULT_HASHTAG);
        }
        //Generate url and get data
        $facebook_url = FMC_Social_Feed_Constant::SF_FACEBOOK_URL;
        $access_token = 'access_token=' . $fb_params['app_secret'];
        $url = FMC_Social_Feed_Config::generate_fb_url($fb_params);
        $data_rt = json_decode(file_get_contents($url));
        /**
         * Rebuild feed content
         */
        $feeds_rebuild = array();
        if (null !== $data_rt && count($data_rt->data)) {
            foreach ($data_rt->data as $data_return) {
                $one_feed = $this->get_data_facebook($data_return, $access_token);
                if (!empty($one_feed)) {
                    $feeds_rebuild[] = $one_feed;
                }
            }
        }

        return $feeds_rebuild;
    }

    /**
     * Get feeds from Twitter via Twitter REST API by hashtags
     *
     * @return array
     */
    public function get_twitter_feeds() {
        //Generate twitter key params to get feeds
        $twitter_params = get_option(FMC_Social_Feed_Constant::SF_TWITTER);
        if (!is_array($twitter_params)) {
            $twitter_params = array();
        }
        if (empty($twitter_params) || !$twitter_params) {
            return array();
        }

        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'access_token' => NULL,
            'access_token_secret' => NULL,
            'customer_key' => NULL,
            'customer_secret' => NULL,
            'url_api' => NULL
        );

        array_merge($default_value, $twitter_params);
        $hashtags_arr = explode(',', $twitter_params['sf_handle']);
        if (!count($hashtags_arr)) {
            $hashtags_arr = array(FMC_Social_Feed_Constant::DEFAULT_HASHTAG);
        }
        set_include_path(
                plugin_dir_path(FMC_Social_Feed::$file) . '/lib'
                . PATH_SEPARATOR
                . get_include_path()
        );
        require_once 'twitter/TwitterAPIExchange.php';
        $settings = array(
            'oauth_access_token' => $twitter_params['access_token'],
            'oauth_access_token_secret' => $twitter_params['access_token_secret'],
            'consumer_key' => $twitter_params['customer_key'],
            'consumer_secret' => $twitter_params['customer_secret']
        );

        $twitter = new TwitterAPIExchange($settings);

        //Get all feeds by search key hashtag
        $feeds_rebuild = array();
        //Loop each hashtags if contain many hashtags
        if (count($hashtags_arr)) {
            foreach ($hashtags_arr as $hashtag) {
                //Get feeds
                $url_tweet = FMC_Social_Feed_Constant::SF_TWITTER_URL_TWEET;
                $url_query = '?q=' . rawurlencode($hashtag);
                $response_feeds = $twitter->setGetfield($url_query)
                        ->buildOauth($url_tweet, FMC_Social_Feed_Constant::SF_TWITTER_METHOD)
                        ->performRequest();
                $responses = json_decode($response_feeds, true);
                //Loop feeds response and check does the feed exist or not
                //and ger appropriate info
                foreach ($responses['statuses'] as $one) {
                    if (!$this->array_exist($feeds_rebuild, 'id', $one['id'])) {
                        $feeds_rebuild[] = $this->get_data_twitter($one);
                    }
                }
            }
        }

        ini_restore('include_path');

        return $feeds_rebuild;
    }

    /**
     * Get feeds from Instagram engine
     *
     * @return array List feeds
     */
    public function get_instagram_feeds() {
        set_include_path(plugin_dir_path(FMC_Social_Feed::$file) . '/lib/instagram' . PATH_SEPARATOR . get_include_path());
        require_once 'instagram.class.php';
        $insta_params = get_option(FMC_Social_Feed_Constant::SF_INSTAGRAM);
        if (!is_array($insta_params)) {
            $insta_params = array();
        }
        if (empty($insta_params) || !$insta_params) {
            return array();
        }

        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'api_key' => NULL,
            'api_secret' => NULL,
            'instagram_url' => NULL
        );
        extract(array_merge($default_value, $insta_params));
        $hashtags = explode(',', $insta_params['sf_handle']);
        if (!count($hashtags)) {
            $hashtags = array(FMC_Social_Feed_Constant::DEFAULT_HASHTAG);
        }
        $full_data = array();
        if (count($insta_params['sf_handle'])) {
            foreach ($hashtags as $one) {
                //Hashtag without # sign
                $hashtag = substr($one, 1, strlen($one) - 1);
                $url = FMC_Social_Feed_Constant::SF_INSTAGRAM_URL
                        . $hashtag
                        . '/media/recent?&access_token='
                        . $insta_params['api_secret'] . '&count=50';
                $data_res = file_get_contents($url);
                $response = (array) json_decode($data_res);

                if (count($response)) {
                    foreach ($response['data'] as $res) {
                        $res = (array) $res;
                        if (!$this->array_exist($full_data, 'id', $res['id'])) {
                            $full_data[] = $res;
                        }
                    }
                }
            }
        }

        /**
         * Rebuild feed content
         */
        $feeds_rebuild = array();
        if (count($full_data)) {
            foreach ($full_data as $one) {
                $feeds_rebuild[] = $this->get_data_instagram($one);
            }
        }

        return $feeds_rebuild;
    }

    /**
     * @todo to return array data facebook
     * @param type $data_return
     * @param type $access_token
     * @return boolean
     */
    public function get_data_facebook($data_return, $access_token) {
        //Get feed If it contains hashtags (#...) in hashtags list taht user put
        if (isset($data_return->message) && $this->check_hashtag_exist($data_return->message, $hashtags_arr)) {
            //Get a feed data
            $facebook_url = FMC_Social_Feed_Constant::SF_FACEBOOK_URL;
            $created_at = new \DateTime($data_return->created_time);
            $updated_at = new \DateTime($data_return->updated_time);

            $one_feed = array(
                'id' => $data_return->id,
                'content' => $data_return->message,
                'picture' => isset($data_return->picture) ? $data_return->full_picture : '',
                'video' => '',
                'link' => isset($data_return->link) ? $data_return->link : '',
                'from_id' => $data_return->from->id,
                'from_name' => $data_return->from->name,
                'from_avatar' => $facebook_url . $data_return->from->id . '/picture',
                'location' => NULL,
                'created_at' => $created_at->format('Y-m-d h:i:s'),
                'updated_at' => $updated_at->format('Y-m-d h:i:s'),
                'type' => '',
            );

            if ($data_return->type === 'photo') {
                $one_feed['type'] = 'image';
            }

            if ($data_return->type === 'video') {
                $one_feed['type'] = 'video';
            }

            //Get location coordinates if exit
            if (isset($data_return->place) && $data_return->place !== NULL) {
                $one_feed['location'] = array(
                    'latitude' => $data_return->place->location->latitude,
                    'longitude' => $data_return->place->location->longitude,
                );

//                        if (property_exists($data_return->place, 'name')) {
//                            $one_feed['location_name'] = $data_return->place->name;
//                        }
            }

            //Get picture of feed
            $object_id = isset($data_return->object_id) ? $data_return->object_id : '';

            if ($data_return->type === 'video') {
                $one_feed['video'] = isset($data_return->link) ? $data_return->link : '';
            }

            if ($object_id !== '' && $data_return->type === 'photo') {
                $image_json = file_get_contents($facebook_url . $object_id . '?fields=images&' . $access_token);
                $original = json_decode($image_json);
                if ($original !== NULL && $original->images[0]->source) {
                    $one_feed['picture'] = $original->images[0]->source;
                }
            }
            return $one_feed;
        }

        return array();
    }

    /**
     * @todo to return array data instagram
     * @param type $one
     * @return type
     */
    public function get_data_instagram($one) {
        $created_at = new DateTime(gmdate("Y-m-d\TH:i:s", $one['caption']->created_time));
        $one_feed = array(
            'id' => $one['id'],
            'content' => $one['caption']->text,
            'picture' => $one['images']->standard_resolution->url,
            'video' => '',
            'link' => $one['link'],
            'from_id' => $one['caption']->from->id,
            'from_name' => $one['caption']->from->username,
            'from_avatar' => $one['caption']->from->profile_picture,
            'location' => NULL,
            'created_at' => $created_at->format('Y-m-d h:i:s'),
            'type' => $one['type'],
        );

        if ($one['type'] === 'video') {
            $one_feed['video'] = $one['videos']->standard_resolution->url;
        }

//                if ($one['type'] === 'image') {
//                    $one_feed['picture'] = $one['images']->standard_resolution->url;
//                }

        if ($one['location'] !== NULL) {
            $one_feed['location'] = array(
                'longitude' => @$one['location']->longitude,
                'latitude' => @$one['location']->latitude,
            );
            if (property_exists($one['location'], 'name')) {
                $one_feed['location_name'] = $one['location']->name;
            }
        }

        return $one_feed;
    }

    public function get_data_twitter($one) {
        $created_at = new \DateTime($one['created_at']);

        $one_feed = array(
            'id' => $one['id'],
            'content' => $one['text'],
            'picture' => isset($one['entities']['media'][0]['media_url']) ? $one['entities']['media'][0]['media_url'] : '',
            'video' => '',
            'link' => isset($one['entities']['media'][0]['expanded_url']) ? $one['entities']['media'][0]['expanded_url'] : '',
            'from_id' => $one['user']['id'],
            'from_name' => $one['user']['name'],
            'from_avatar' => $one['user']['profile_image_url'],
            'location' => NULL,
            'created_at' => $created_at->format('Y-m-d h:i:s'),
            'type' => '',
        );

        if (strpos($one_feed['link'], 'video')) {
            $one_feed['type'] = 'video';
            $one_feed['video'] = $one_feed['link'];
        }

        if (strpos($one_feed['link'], 'photo')) {
            $one_feed['type'] = 'image';
        }

        if ($one['place'] !== NULL) {
            $one_feed['location'] = array(
                'longitude' => $one['place']['bounding_box']['coordinates'][0][0][0],
                'latitude' => $one['place']['bounding_box']['coordinates'][0][0][1],
            );
        }

        return $one_feed;
    }

    /**
     * @todo to return data of feed id
     * @param type $feed_id
     * @return type
     */
    public function get_facebook_by_feedid($feed_id) {
        //Generate Facebook parameters to get feed from FB API
        $fb_params = get_option(FMC_Social_Feed_Constant::SF_FACEBOOK);
        if (!is_array($fb_params)) {
            $fb_params = array();
        }
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'app_id' => NULL,
            'app_secret' => NULL
        );
        array_merge($default_value, $fb_params);
        //Generate url and get data
        $facebook_url = FMC_Social_Feed_Constant::SF_FACEBOOK_URL;
        $access_token = 'access_token=' . $fb_params['app_secret'];
        $url = $facebook_url . $feed_id . '?' . $access_token;
        $data_rt = json_decode(file_get_contents($url));
        if (null !== $data_rt && count($data_rt)) {
            return $this->get_data_facebook($data_rt, $access_token);
        }

        return array();
    }

    public function get_instagram_by_feedid($feed_id) {
        set_include_path(plugin_dir_path(FMC_Social_Feed::$file) . '/lib/instagram' . PATH_SEPARATOR . get_include_path());
        require_once 'instagram.class.php';
        $insta_params = get_option(FMC_Social_Feed_Constant::SF_INSTAGRAM);
        if (!is_array($insta_params)) {
            $insta_params = array();
        }
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'api_key' => NULL,
            'api_secret' => NULL,
            'instagram_url' => NULL
        );
        extract(array_merge($default_value, $insta_params));

        $url = FMC_Social_Feed_Constant::SF_INSTAGRAM_URL_MEDIA
                . $feed_id
                . '?&access_token=' . $insta_params['api_secret'];

        $data_res = file_get_contents($url);
        $response = json_decode($data_res);
        if (!is_null($response)) {
            $data = (array) $response->data;
            return $this->get_data_instagram($data);
        }

        return array();
    }

    public function get_twitter_by_feedid($feed_id) {
        //Generate twitter key params to get feeds
        $twitter_params = get_option(FMC_Social_Feed_Constant::SF_TWITTER);
        if (!is_array($twitter_params)) {
            $twitter_params = array();
        }
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'access_token' => NULL,
            'access_token_secret' => NULL,
            'customer_key' => NULL,
            'customer_secret' => NULL,
            'url_api' => NULL
        );

        array_merge($default_value, $twitter_params);
        set_include_path(
                plugin_dir_path(FMC_Social_Feed::$file) . '/lib'
                . PATH_SEPARATOR
                . get_include_path()
        );
        require_once 'twitter/TwitterAPIExchange.php';
        $settings = array(
            'oauth_access_token' => $twitter_params['access_token'],
            'oauth_access_token_secret' => $twitter_params['access_token_secret'],
            'consumer_key' => $twitter_params['customer_key'],
            'consumer_secret' => $twitter_params['customer_secret']
        );

        $twitter = new TwitterAPIExchange($settings);
        $url_tweet = FMC_Social_Feed_Constant::SF_TWITTER_URL_LOOKUP;
        $url_query = '?id=' . $feed_id;
        $response_feeds = $twitter->setGetfield($url_query)
                ->buildOauth($url_tweet, FMC_Social_Feed_Constant::SF_TWITTER_METHOD)
                ->performRequest();
        $response = objectToArray(json_decode($response_feeds, true));

        if (!is_null($response) && count($response)) {
            return $this->get_data_twitter($response);
        }

        return array();
    }

    /**
     * Check a value exist in an array
     *
     * @param array $array array to check $value from $key
     * @param string $key
     * @param string $val
     *
     * @return boolean
     */
    public function array_exist($array, $key, $val) {
        if (count($array)) {
            foreach ($array as $item) {
                if (isset($item[$key]) && $item[$key] === $val) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check does hashtags exist in content
     *
     * @param string $content
     * @param array $hashtags array of hashtags
     *
     * @return boolean
     */
    public function check_hashtag_exist($content, $hashtags) {

        //Check does hashtags exsit
        if (count($hashtags)) {
            foreach ($hashtags as $one) {
                //Check contain has a hashtag
                if (strpos($content, $one) !== false) {
                    return true;
                }
            }

            return false;
        }

        return false;
    }

    /**
     * Explode a string handle to array handle
     *
     * @param string $query
     *
     * @return boolean|array
     */
    public function ext_request_handle($query) {
        $query = explode(',', $query);

        if (count($query)) {
            $handles = array();
            foreach ($query as $one) {
                if ($one[0] === '@') {
                    $handles['chanel'] = $one;
                }

                if ($one[0] === '#') {
                    $handles['hashtags'][] = $one;
                }
            }

            return $handles;
        }

        return false;
    }

    /**
     * @todo to return list site
     * @global type $wpdb
     * @param type $expires
     * @return boolean
     */
    public function get_list_site($expires = 7200) {
        if (!is_multisite())
            return false;

        // Because the get_blog_list() function is currently flagged as deprecated
        // due to the potential for high consumption of resources, we'll use
        // $wpdb to roll out our own SQL query instead. Because the query can be
        // memory-intensive, we'll store the results using the Transients API
        if (false === ( $site_list = get_transient('multisite_site_list') )) {
            global $wpdb;
            $site_list = $wpdb->get_results($wpdb->prepare('SELECT * FROM wp_blogs ORDER BY blog_id'));
            // Set the Transient cache to expire every two hours
            set_site_transient('multisite_site_list', $site_list, $expires);
        }

        return $site_list;
    }

    /**
     * @todo to find blog id by lat & long
     * @param type $deal_lat
     * @param type $deal_long
     * @return string
     */
    public function get_blogid_by_lat_long($deal_lat, $deal_long) {
        //HK,MY, SG, PH, TH
        $geocode = file_get_contents(FMC_Social_Feed_Constant::SF_GOOGLEMAP_API . $deal_lat . ',' . $deal_long . '&sensor=false');

        $output = json_decode($geocode);

        for ($j = 0; $j < count($output->results[0]->address_components); $j++) {
            $cn = array($output->results[0]->address_components[$j]->types[0]);

            if (in_array("country", $cn)) {
                $country = $output->results[0]->address_components[$j]->short_name;
            }
        }

        $list_country_blog = FMC_Country::get_site_blog();
        if (isset($list_country_blog[$country]) && !is_null($list_country_blog[$country])) {
            return $list_country_blog[$country];
        }

        return '';
    }

    public function delete_meta_post($pid) {
        global $wpdb;
        if ($wpdb->get_var($wpdb->prepare('SELECT post_id FROM '. $wpdb->postmeta .' WHERE post_id = %d', $pid))) {
            return $wpdb->query($wpdb->prepare('DELETE FROM '. $wpdb->postmeta .' WHERE post_id = %d', $pid));
        }
        return true;
    }

    /**
     * @todo check location of social feed , if it is not belong to site where it should be, it need to delete
     * @global type $blog_id
     */
    public function change_location_social_feeds() {
        global $blog_id;
        $args = array(
            'posts_per_page' => -1,
            'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
            //'meta_key' => 'sf_feed_is_kol',
            //'meta_value' => FMC_Social_Feed_Constant::NOT_KOL_USER,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => 'sf_feed_is_kol',
                    'value' => FMC_Social_Feed_Constant::NOT_KOL_USER,
                    'compare' => 'like',
                ),
                array(
                    'key' => 'sf_feed_location',
                    'value' => '',
                    'compare' => '!=',
                ),
            ),
        );
        $q = new WP_Query($args);

        if ($q->have_posts()) {
            foreach ($q->posts as $item) {
                $location = get_post_meta($item->ID, sf_feed_location, true);
                if (!empty($location)) {
                    $location_decode = json_decode($location);
                    $blog_id_location = $this->get_blogid_by_lat_long($location_decode->latitude, $location_decode->longitude);
                    if (!empty($blog_id_location) && $blog_id_location != $blog_id) {
                        wp_delete_post($item->ID, true);
                        $this->delete_meta_post($item->ID);
                    }
                }
            }
        }
    }

}

/**
 *
 * Convert an object to an array
 *
 * @param    object  $object The object to convert
 * @reeturn      array
 *
 */
function objectToArray($object) {

    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map('objectToArray', $object);
}

function recursive_return_array_value_by_key($needle, $haystack, $current_key = '') {
    $return = -1;

    foreach ($haystack as $key => $val) {
        if (is_array($val)) {
            $return = recursive_return_array_value_by_key($needle, $val, $key);
        }
        else if ($needle == $val) {
            return $current_key;
        }

        if ($return !== -1) {
            break;
        }
    }
    return $return;
}

function array_search_values($m_needle, $a_haystack, $b_strict = false) {
    return array_intersect_key($a_haystack, array_flip(array_keys($a_haystack, $m_needle, $b_strict)));
}
