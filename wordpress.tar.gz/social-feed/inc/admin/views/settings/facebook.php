<?php
    $sf_facebook_setting = get_option(FMC_Social_Feed_Constant::SF_FACEBOOK);
    if (!is_array($sf_facebook_setting)) {
        $sf_facebook_setting = array();
    }
    $default_value = array(
        'is_enable' => 0,
        'sf_handle' => NULL,
        'app_id' => NULL,
        'app_secret' => NULL
    );
    extract(array_merge($default_value, $sf_facebook_setting));
?>
<table class="form-table">
    <tbody>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[is_enable]"><?php _e('Is Enable'); ?></label></th>
            <td><input type="checkbox" value="1" <?php echo $is_enable ? 'checked="checked"' : '';?> name="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[is_enable]" id="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[is_enable]"></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[sf_handle]"><?php _e('Hashtags'); ?></label></th>
            <td><input type="text" class="regular-text" value="<?php echo $sf_handle;?>" id="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[sf_handle]" name="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[sf_handle]"></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_id]"><?php _e('Page ID'); ?></label></th>
            <td><input type="text" class="regular-text" value="<?php echo $app_id;?>" id="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_id]" name="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_id]"></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_secret]"><?php _e('Access token ID'); ?></label></th>
            <td>
                <input type="text" class="regular-text" value="<?php echo $app_secret;?>" id="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_secret]" name="<?php echo FMC_Social_Feed_Constant::SF_FACEBOOK;?>[app_secret]">
            </td>
        </tr>
    </tbody>
</table>