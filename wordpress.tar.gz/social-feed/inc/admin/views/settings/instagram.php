<?php
    $sf_instagram_setting = get_option(FMC_Social_Feed_Constant::SF_INSTAGRAM);
    if (!is_array($sf_instagram_setting)) {
        $sf_instagram_setting = array();
    }
    $default_value = array(
        'is_enable' => 0,
        'sf_handle' => NULL,
        'api_key' => NULL,
        'api_secret' => NULL,
        'instagram_url' => NULL
    );
    extract(array_merge($default_value, $sf_instagram_setting));
?>
<table class="form-table">
    <tbody>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[is_enable]"><?php _e('Is Enable'); ?></label></th>
            <td><input type="checkbox" value="1" <?php echo $is_enable ? 'checked="checked"' : '';?> name="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[is_enable]" id="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[is_enable]"></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[sf_handle]"><?php _e('Hashtags'); ?></label></th>
            <td><input type="text" class="regular-text" value="<?php echo $sf_handle;?>" id="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[sf_handle]" name="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[sf_handle]"></td>
        </tr>

        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_key]"><?php _e('Client ID'); ?></label></th>
            <td><input type="text" class="regular-text" value="<?php echo $api_key;?>" id="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_key]" name="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_key]"></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_secret]"><?php _e('Access token ID'); ?></label></th>
            <td>
                <input type="text" class="regular-text" value="<?php echo $api_secret;?>" id="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_secret]" name="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[api_secret]">
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[instagram_url]"><?php _e('Instagram URL'); ?></label></th>
            <td>
                <input type="text" class="regular-text" value="<?php echo $instagram_url;?>" id="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[instagram_url]" name="<?php echo FMC_Social_Feed_Constant::SF_INSTAGRAM;?>[instagram_url]">
            </td>
        </tr>
    </tbody>
</table>