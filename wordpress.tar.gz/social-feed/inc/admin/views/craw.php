<div class="wrap">
    <?php
    include_once 'save-feeds.php';

    //The request url contain variable $_GET['feed-id']
    //mean the user wanne view feed details
    if (isset($_GET['feed-id'])) {
        $feed_id = (int) $_GET['feed-id'];

        //Get feed in DB via feed id (post id)
        $feed = get_post($feed_id);
        if ($feed !== NULL) {
            $social_feed_id = get_post_meta($feed->ID, 'sf_feed_id', true);
            $feed_picture   = get_post_meta($feed->ID, 'sf_feed_picture', true);
            $feed_link      = get_post_meta($feed->ID, 'sf_feed_link', true);
            $from_id        = get_post_meta($feed->ID, 'sf_feed_from_id', true);
            $from_name      = get_post_meta($feed->ID, 'sf_feed_from_name', true);
            $from_avatar    = get_post_meta($feed->ID, 'sf_feed_from_avatar', true);
            $social_type    = get_post_meta($feed->ID, 'sf_feed_social_type', true);
            $created_at     = get_post_meta($feed->ID, 'sf_feed_created_at', true);
            $feed_location  = get_post_meta($feed->ID, 'sf_feed_location', true);
            $is_kol         = get_post_meta($feed->ID, 'sf_feed_is_kol', true);
            $is_admin       = get_post_meta($feed->ID, 'sf_feed_is_admin', true);
            $wp_kol_id      = get_post_meta($feed->ID, 'sf_wp_kol_id', true);
            ?>
            <h2><?php _e('Feed details'); ?></h2>
            <table class="wp-list-table widefat fixed striped posts">
                <tr>
                    <td width="20%">ID</td>
                    <td><?php echo $social_feed_id; ?></td>
                </tr>
                <tr>
                    <td width="20%">Content</td>
                    <td><?php _e($feed->post_title) ?></td>
                </tr>
                <tr>
                    <td width="20%">Picture</td>
                    <td>
                        <?php if ($feed_picture !== '') { ?>
                        <image src="<?php echo $feed_picture ?>" width="200" />
                        <?php } else { ?>
                        <i><?php _e('NO IMAGE'); ?></i>
                        <?php } ?>
                    </td>
                </tr>
                <tr>
                    <td width="20%">From user id</td>
                    <td><?php echo $from_id; ?></td>
                </tr>
                <tr>
                    <td width="20%">From user display name</td>
                    <td><?php echo $from_name; ?></td>
                </tr>
                <tr>
                    <td width="20%">From user avatar</td>
                    <td><image src="<?php echo $from_avatar ?>" /></td>
                </tr>
                <tr>
                    <td width="20%">Social type</td>
                    <td>
                        <?php
                            $social_engine = '';
                            switch ($social_type) {
                                case FMC_Social_Feed_Constant::SF_FACEBOOK:
                                    $social_engine = __('Facebook');
                                    break;
                                case FMC_Social_Feed_Constant::SF_TWITTER:
                                    $social_engine = __('Twitter');
                                    break;
                                case FMC_Social_Feed_Constant::SF_INSTAGRAM:
                                    $social_engine = __('Instagram');
                                    break;
                                default:
                                    break;
                            }
                            echo $social_engine;
                        ?>
                    </td>
                </tr>
                <tr>
                    <td width="20%">Feeds type:</td>
                    <td style="text-transform:capitalize">
                        <?php
                        if ($is_kol === FMC_Social_Feed_Constant::KOL_USER) {
                            $wp_kol_users = get_users(array('include' => array($wp_kol_id)));
                            $wp_kol_role = $wp_kol_users[0]->roles;
                            if ($wp_kol_role[0] === FMC_Country::ADMIN_ROLE) {
                                _e('KOL Admin');
                            } else {
                                _e('KOL user');
                            }
                        } else {
                            _e('Public user');
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td width="20%">Status</td>
                    <td><?php _e(FMC_Get_Social_Feeds::display_feed_status($feed->post_status)); ?></td>
                </tr>
                <tr>
                    <td width="20%">Created at</td>
                    <td><?php $created = new \DateTime($created_at); echo $created->format('M d Y'); ?></td>
                </tr>
                <tr>
                    <td width="20%">Visit feed on <?php echo $social_engine ?></td>
                    <td><a href="<?php echo $feed_link; ?>"><?php echo $feed_link; ?></a></td>
                </tr>
                <tr>
                    <td width="20%">Map ID</td>
                    <td><?php echo ('' != $feed_location) ? $feed->ID : '<i>No location</i>'; ?></td>
                </tr>
            </table>
            <?php
        } else {
            //Feed not found with id has recieved
            ?>
            <h2><?php _e('Opp !! The resource your try to access is not exist or was deleted.') ?></h2>
            <?php
        }
    } else {

        //Update feed status (approve or hide compare with pending at the beginning)
        if (isset($_POST['sf_action'])) {
            $status  = $_POST['sf_action'];
            $feed_id = isset($_POST['sf_feed_id']) ? $_POST['sf_feed_id'] : array();

            if ($status === FMC_Social_Feed_Constant::DELETE) {
                if ( FMC_Get_Social_Feeds::delete_feeds($feed_id)) {
                    ?>
                        <div class="updated notice notice-success is-dismissible below-h2" id="message">
                            <p><?php _e('Successfully deleted.'); ?></p>
                            <button class="notice-dismiss" type="button">
                                <span class="screen-reader-text"><?php _e('Dismiss this notice.') ?></span>
                            </button>
                        </div>
                    <?php
                }
            } elseif (FMC_Get_Social_Feeds::change_feed_status($feed_id, $status)) {
                ?>
                <div class="updated notice notice-success is-dismissible below-h2" id="message">
                    <p><?php _e('Successfully updated.'); ?></p>
                    <button class="notice-dismiss" type="button">
                        <span class="screen-reader-text"><?php _e('Dismiss this notice.') ?></span>
                    </button>
                </div>
                <?php
            }elseif(FMC_Get_Social_Feeds::update_feeds($feed_id, $status)){?>
                <div class="updated notice notice-success is-dismissible below-h2" id="message">
                    <p><?php _e('Successfully updated.'); ?></p>
                    <button class="notice-dismiss" type="button">
                        <span class="screen-reader-text"><?php _e('Dismiss this notice.') ?></span>
                    </button>
                </div>
                <?php
            }
        }

        //Get all feeds order by the date feed post on social engine
        $args = array(
            'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
            'posts_per_page' => -1,
            'orderby'   => 'meta_value_num',
            'meta_key'  => 'sf_feed_created_timestamp',
            'order' => 'DESC'
        );
        if (isset($_POST['sf_filter'])) {
            $args['post_status'] = $_POST['sf_filter'];
        }
        $query = new WP_Query($args);
        ?>

        <form name="social_feed" method="post">
            <input type="hidden" name="action" value="sf-craw-action">
            <?php
            wp_nonce_field('sf-craw-action-nonce');
            ?>
            <h2><?php _e('List feeds'); ?></h2>
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <label class="screen-reader-text" for="bulk-action-selector-top"><?php _e('Select bulk action'); ?></label>
                    <select id="bulk-action-selector-top" name="sf_action">
                        <option selected="selected" value="-1"><?php _e('Bulk Actions'); ?></option>
                        <option class="hide-if-no-js" value="<?php echo FMC_Social_Feed_Constant::APPROVED ?>"><?php _e('Approve'); ?></option>
                        <option class="hide-if-no-js" value="<?php echo FMC_Social_Feed_Constant::UPDATE ?>"><?php _e('Update'); ?></option>
                        <option value="<?php echo FMC_Social_Feed_Constant::HIDE ?>"><?php _e('Hide'); ?></option>
                        <option value="<?php echo FMC_Social_Feed_Constant::DELETE ?>"><?php _e('Delete'); ?></option>
                    </select>
                    <input type="submit" value="Apply" class="button action" id="doaction" >
                </div>
                <div class="alignleft actions bulkactions">
                    <label class="screen-reader-text" for="bulk-action-selector-top"><?php _e('Select filter action'); ?></label>
                    <select id="bulk-action-selector-top" name="sf_filter">
                        <option selected="selected" value="-1"><?php _e('Display all'); ?></option>
                        <option class="hide-if-no-js" value="<?php echo FMC_Social_Feed_Constant::APPROVED ?>" <?php selected(FMC_Social_Feed_Constant::APPROVED, isset($_POST['sf_filter']) ? $_POST['sf_filter'] : ''); ?>><?php _e('Approved'); ?></option>
                        <option value="<?php echo FMC_Social_Feed_Constant::HIDE ?>" <?php selected(FMC_Social_Feed_Constant::HIDE, isset($_POST['sf_filter']) ? $_POST['sf_filter'] : ''); ?>><?php _e('Hide'); ?></option>
                        <option value="<?php echo FMC_Social_Feed_Constant::PENDING ?>" <?php selected(FMC_Social_Feed_Constant::PENDING, isset($_POST['sf_filter']) ? $_POST['sf_filter'] : ''); ?>><?php _e('Pending'); ?></option>
                    </select>
                    <input type="submit" value="Filter" class="button action" id="doaction">
                </div>
                <br class="clear">
            </div>

            <table class="wp-list-table widefat fixed striped posts">

                <thead>
                    <tr>
                        <th width="5%"><input type="checkbox" name="sf-all" id="sf-all" onchange="select_all_top(this)"></th>
                        <th width="45%"><?php _e('Feed title') ?></th>
                        <th width="10%"><?php _e('Feed image') ?></th>
                        <th width="10%" ><?php _e('Social type') ?></th>
                        <th width="10%" ><?php _e('User type') ?></th>
                        <th width="10%" ><?php _e('Posted date') ?></th>
                        <th width="10%" ><?php _e('Status') ?></th>
                    </tr>
                </thead>
                <tbody id="the-list">
                    <?php
                    if ($query->have_posts()) :
                        while ($query->have_posts()) : $query->the_post();
                            $feed_id     = get_post_meta(get_the_ID(), 'sf_feed_id', true);
                            $created_at  = new \DateTime(get_post_meta(get_the_ID(), 'sf_feed_created_at', true));
                            $current_url = $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
                            $social_type = get_post_meta(get_the_ID(), 'sf_feed_social_type', true);
                            $is_kol      = get_post_meta(get_the_ID(), 'sf_feed_is_kol', true);
                            $wp_kol_id   = get_post_meta(get_the_ID(), 'sf_wp_kol_id', true);
                            $is_admin    = get_post_meta(get_the_ID(), 'sf_feed_is_admin', true);
                            $img         = get_post_meta(get_the_ID(), 'sf_feed_picture', true);
                            ?>

                            <tr>
                                <th >
                                    <input type="checkbox" name="sf_feed_id[]" value="<?php echo $feed_id; ?>">
                                </th>
                                <td>
                                    <strong>
                                        <a href="<?php echo 'edit.php?post_type=social_feed&page=craw-feed&feed-id=' . get_the_ID(); ?>">
                                            <?php echo strlen(get_the_content()) > 100 ? mb_substr(get_the_content(), 0, 100, 'utf8') . '...' : get_the_content(); ?>
                                        </a>
                                    </strong>
                                </td>
                                <td>
                                    <?php
                                        if ('' !== $img) :
                                    ?>
                                    <a href="<?php echo $img; ?>"><img src="<?php echo $img; ?>" style="width:100px"/></a>
                                    <?php
                                        else :
                                            echo '<i>No image</i>';
                                        endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $social_engine = '';
                                        switch ($social_type) {
                                            case FMC_Social_Feed_Constant::SF_FACEBOOK:
                                                $social_engine = __('Facebook');
                                                break;
                                            case FMC_Social_Feed_Constant::SF_TWITTER:
                                                $social_engine = __('Twitter');
                                                break;
                                            case FMC_Social_Feed_Constant::SF_INSTAGRAM:
                                                $social_engine = __('Instagram');
                                                break;
                                            default:
                                                break;
                                        }
                                        echo $social_engine;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        if ($is_kol === FMC_Social_Feed_Constant::KOL_USER) {
                                            $wp_kol_users = get_users(array('include' => array($wp_kol_id)));
                                            $wp_kol_role  = $wp_kol_users[0]->roles;
                                            if ($wp_kol_role[0] === FMC_Country::ADMIN_ROLE) {
                                                _e('KOL Admin');
                                            } else {
                                                _e('KOL user');
                                            }
                                        } else {
                                            _e('Public user');
                                        }
                                    ?>
                                </td>
                                <td><?php echo $created_at->format('Y-m-d'); ?></td>
                                <td>
                                    <?php
                                    _e(FMC_Get_Social_Feeds::display_feed_status(get_post_status()));
                                    ?>
                                </td>
                            </tr>


                            <?php
                        endwhile;
                    else :
                        ?>
                        <tr>
                            <th></th>
                            <th><?php _e('There is no feeds now.'); ?></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php
                    endif;
                    wp_reset_query();
                    ?>
                </tbody>

                <tfoot>
                    <tr>
                        <th><input type="checkbox" name="sf-all-2" id="sf-all-2" onchange="select_all_bottom(this)"></td>
                        <th><?php _e('Feed title') ?></th>
                        <th><?php _e('Feed image') ?></th>
                        <th><?php _e('Social type') ?></th>
                        <th><?php _e('User type') ?></th>
                        <th><?php _e('Posted date') ?></th>
                        <th><?php _e('Status') ?></th>
                    </tr>
                </tfoot>
            </table>
        </form>
    </div>
<?php } ?>
<script>
    function select_all_top() {
        jQuery('input[name^="sf_feed_id"]').attr({'checked': jQuery('#sf-all').is(':checked')});
        jQuery('#sf-all-2').attr({'checked': jQuery('#sf-all').is(':checked')});
    }

    function select_all_bottom() {
        jQuery('input[name^="sf_feed_id"]').attr({'checked': jQuery('#sf-all-2').is(':checked')});
        jQuery('#sf-all').attr({'checked': jQuery('#sf-all-2').is(':checked')});
    }
</script>