<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


class FMC_Social_Feed_Post {
    public function __construct()
    {
        //add custom post type
        $social_post_type = FMC_Social_Feed_Constant::POST_TYPE;
        add_action('init', array($this, 'register_post_type'));
        add_filter('manage_edit-'.FMC_Social_Feed_Constant::POST_TYPE.'_columns', array($this, 'manage_columns'));
        add_action('restrict_manage_posts', array($this, 'restrict_manage_posts'));
        add_filter('parse_query', array($this, 'convert_taxid_to_term'));
        add_filter('manage_'.FMC_Social_Feed_Constant::POST_TYPE.'_posts_custom_column', array($this, 'posts_custom_column'));
        add_filter("manage_edit-{$social_post_type}_sortable_columns", array($this, 'sortable_column'));
        add_action('pre_get_posts', array($this, 'social_feed_orderby'));
        //Disable new post
        add_action('admin_menu', array($this, 'disable_new_posts'));
        add_action('admin_head', array( $this, 'hidden_add_new_button') );

        //Add functio set/unset feature via bulk action
        add_filter('bulk_actions-edit-'.FMC_Social_Feed_Constant::POST_TYPE, array($this, 'remove_bulk_actions'));
        add_action('admin_footer-edit.php', array($this, 'add_bulk_actions'));
        add_action('load-edit.php', array($this, 'custom_bulk_action'));
        add_action('admin_notices', array($this, 'custom_bulk_admin_notices'));

    }
    public function register_post_type() {
        //init labels
        $labels = array(
            'name' => __('Social Feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'singular_name' => __('Social Feed', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'add_new' => __('Add new', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'add_new_item' => __('Add New Feed', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'edit_item' => __('Edit Feed', FMC_Social_Feed_Constant::TEXTDOMAIN),
            //'new_item' => __('New Feed', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'all_items' => __('Feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'view_item' => __('View Feed', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'search_items' => __('Search Feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'not_found' => __('No feeds found', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'not_found_in_trash' => __('No feeds found in the Trash', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'parent_item_colon' => '',
            'menu_name' => __('Social Feeds')
        );

        $args = array(
            'labels' => $labels,
            'description' => __('Manage Social Feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'public' => true,
            'menu_position' => 10,
            'public' => true,
            'show_ui' => true,
            'supports' => array(
                'title',
                'thumbnail',
                'order'
            ),
            'has_archive' => true,
            'capability_type' => FMC_Social_Feed_Constant::POST_TYPE,
            'capabilities' => array(
                'create_social_feed' => false, // Removes support for the "Add New" function
            ),
            'map_meta_cap' => true,
        );

        //register store post type
        register_post_type(FMC_Social_Feed_Constant::POST_TYPE, $args);
        $args_tax = array(
            'labels' => array(),
            'hierarchical' => true,
            'show_ui' => false,
            'query_var'=> true,
        );
        register_taxonomy(FMC_Social_Feed_Constant::SOCIAL_TYPE, FMC_Social_Feed_Constant::POST_TYPE, $args_tax);
    }
    function disable_new_posts() {
        // Hide sidebar link
        global $submenu;
        unset($submenu['edit.php?post_type='.FMC_Social_Feed_Constant::POST_TYPE][10]);
    }
    public function hidden_add_new_button() {
        if (isset($_GET['post_type']) && $_GET['post_type'] == FMC_Social_Feed_Constant::POST_TYPE) {
            echo '<style type="text/css">
            .add-new-h2 { display:none !important; }
            </style>';
        }
    }
    public function restrict_manage_posts() {
        global $typenow;
        if (FMC_Social_Feed_Constant::POST_TYPE == $typenow) {
            $tax_obj = get_taxonomy(FMC_Social_Feed_Constant::SOCIAL_TYPE);
            wp_dropdown_categories(array(
                'show_option_all' => __("Show All {$tax_obj->label}"),
                'taxonomy' => FMC_Social_Feed_Constant::SOCIAL_TYPE,
                'name' => $tax_obj->name,
                'orderby' => 'name',
                'selected' => isset($_GET[$tax_obj->query_var]) ? $_GET[$tax_obj->query_var] : 0,
                'hierarchical' => true,
                'depth' => 3,
                'show_count' => true, // Show # listings in parens
                'hide_empty' => true, // Don't show businesses w/o listings
            ));
        }
    }
    public function manage_columns() {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'feed_title' => __('Title', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'feed_type' => __('Category', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'featured' => __('Pin', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'sf_date' => __('Date', FMC_Social_Feed_Constant::TEXTDOMAIN),
           // 'object_id' => ('Object ID')
        );
        return $columns;
    }
    public function posts_custom_column($column)
    {
        global $post;
        $social_list = FMC_Social_Feed_Config::list_social();
        switch ($column) {
            case 'feed_title':
                //echo '<a class="row-title" href="' . get_post_meta($post->ID, 'sf_link', true) . '" target="_blank">';
                echo $post->post_title;
                //echo '</a>';
                break;
            case 'feed_type':
                $term = get_the_terms($post->ID, FMC_Social_Feed_Constant::SOCIAL_TYPE);
                if ($term && !is_wp_error($term)) {
                    $social_type = reset($term);
                    echo $social_list[$social_type->slug]['title'];
                }
                break;
            case 'featured':
                $is_featured = get_post_meta($post->ID, 'is_featured', true);
                echo $is_featured == 1 ? 'Yes' : 'No';
                break;
            case 'sf_date':
               // echo get_post_meta($post->ID, 'sf_date', true);
                echo FMC_Social_Feed_Config::time_ago(get_post_meta($post->ID, 'sf_date', true));
                //echo $is_featured == 1 ? 'Yes' : 'No';
                break;
            case 'object_id':
                echo get_post_meta($post->ID, 'sf_ob_id', true);
                break;
            default:
                break;
        }
    }
    public function sortable_column($columns) {
        $columns['feed_title'] = 'title';
        $columns['featured'] = 'featured';
        return $columns;
    }
    public function social_feed_orderby($query) {
        if (!is_admin())
            return;

        $orderby = $query->get('orderby');

        if ('featured' == $orderby) {
            $query->set('meta_key', 'is_featured');
            $query->set('orderby', 'meta_value_num');
        }
    }
    public function convert_taxid_to_term($query)
    {
        global $pagenow;
        $post_type = FMC_Social_Feed_Constant::POST_TYPE; // change HERE
        $taxonomy = FMC_Social_Feed_Constant::SOCIAL_TYPE; // change HERE
        $q_vars = &$query->query_vars;
        if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
            $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
            $q_vars[$taxonomy] = $term->slug;
        }
    }
    public function remove_bulk_actions($actions) {
        unset($actions['edit']);
        return $actions;
    }
    public function add_bulk_actions() {
        global $typenow;
        $text_domain = FMC_Social_Feed_Constant::TEXTDOMAIN;
        if (FMC_Social_Feed_Constant::POST_TYPE == $typenow) {
             ?>
    <script type="text/javascript">
      jQuery(document).ready(function() {
        jQuery('<option>').val('is_featured').text('<?php _e('Set Pin', $text_domain)?>').appendTo("select[name='action']");
        jQuery('<option>').val('un_featured').text('<?php _e('Unset Pin', $text_domain)?>').appendTo("select[name='action']");
        jQuery('<option>').val('is_featured').text('<?php _e('Set Pin', $text_domain)?>').appendTo("select[name='action2']");
        jQuery('<option>').val('un_featured').text('<?php _e('Unset Pin', $text_domain)?>').appendTo("select[name='action2']");
      });
    </script>
    <?php
        }
    }
    public function custom_bulk_admin_notices()
    {
        global $post_type, $pagenow;
        $social_type = FMC_Social_Feed_Constant::POST_TYPE;
        if ($pagenow == 'edit.php' && $post_type == $social_type) {
            if (isset($_REQUEST['is_featured']) && (int) $_REQUEST['is_featured']) {
                $message = sprintf(_n('Post set pin.', '%s posts are set pin.', $_REQUEST['is_featured']), number_format_i18n($_REQUEST['is_featured']));
                echo "<div class=\"updated\"><p>{$message}</p></div>";
            }
            if (isset($_REQUEST['un_featured']) && (int) $_REQUEST['un_featured']) {
                $message = sprintf(_n('Post unset pin.', '%s posts are unset pin.', $_REQUEST['un_featured']), number_format_i18n($_REQUEST['un_featured']));
                echo "<div class=\"updated\"><p>{$message}</p></div>";
            }
        }
    }
    public function custom_bulk_action() {
        
        // 1. get the action
        $wp_list_table = _get_list_table('WP_Posts_List_Table');
        $action = $wp_list_table->current_action();
        // 2. security check
        //check_admin_referer('bulk-posts');
        if (isset($_REQUEST['post'])) {
            $post_ids = array_map('intval', $_REQUEST['post']);
        }
        if (empty($post_ids))
            return;
        switch ($action) {
            // 3. Perform the action
            case 'is_featured':
                foreach ($post_ids as $post_id) {
                    update_post_meta($post_id, 'is_featured', 1);
                }
                $sendback = add_query_arg(
                    array(
                        'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
                        'is_featured' => count($post_ids)
                        //'ids' => join(',', $post_ids)
                    ),
                $sendback);
                break;
            case 'un_featured':
                foreach ($post_ids as $post_id) {
                    update_post_meta($post_id, 'is_featured', 0);
                }
                $sendback = add_query_arg(
                    array(
                        'post_type' => FMC_Social_Feed_Constant::POST_TYPE,
                        'un_featured' => count($post_ids)
                        //'ids' => join(',', $post_ids)
                    ),
                $sendback);
                break;
            default:
                return;
        }
        // 4. Redirect client
        wp_redirect($sendback);
        exit();
    }

}
//Initialize
$GLOBALS['fmc_social_feed_post'] = new FMC_Social_Feed_Post();