<?php

//var_dump(get_include_path()); die;
class FMC_Social_Feed_Craw {

    var $page;

    /**
     * @constructor
     */
    public function __construct() {
        /* Add the page */
        add_action('admin_menu', array($this, 'add_page'));
        add_action('admin_menu', array($this, 'add_get_feeds_page'));
    }

    /**
     * Add get feed submenu
     *
     * @return void
     */
    public function add_get_feeds_page() {
        $this->page = add_submenu_page(
                'edit.php?post_type=social_feed',
                __('Get feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
                __('Get feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
                'manage_options',
                'get-feeds',
                array($this, 'render_get_feeds_page'),
                11
        );
    }

    /**
     * Add craw data page
     *
     * @return void
     */
    public function add_page() {
        $this->page = add_submenu_page(
                'edit.php?post_type=social_feed',
                __('List feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
                __('List feeds', FMC_Social_Feed_Constant::TEXTDOMAIN),
                'manage_options',
                'craw-feed',
                array($this, 'render_page'),
                11
        );

        /* Add callbacks for this screen only */
        add_action('load-' . $this->page, array($this, 'page_actions'), 9);
        //add_action('admin_footer-' . $this->page, array($this, 'footer_scripts'));
    }

    /**
     * Include craw feeds page
     */
    public function render_page() {
        require_once 'views/craw.php';
    }

    /**
     * Include get feeds page
     */
    public function render_get_feeds_page(){
        require_once 'views/get-feeds.php';
    }

    public function page_actions() {
        /* User can choose between 1 or 2 columns (default 2) */
        add_screen_option('layout_columns', array('max' => 1, 'default' => 1));
    }

}

$GLOBALS['fmc_sfadm_craw'] = new FMC_Social_Feed_Craw();

