<?php
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class FMC_Social_Feed_Setting
{

    var $page;
    var $updated = FALSE;

    /**
     * Constructor class for the Simple Admin Metabox
     */
    function __construct()
    {
        /* Add the page */
        add_action('admin_menu', array($this, 'add_page'));
    }

    /**
     * Adds the custom page.
     * Adds callbacks to the load-* and admin_footer-* hooks
     */
    function add_page()
    {

        /* Add the page */
        //$this->page = add_submenu_page($this->hook, $this->title, $this->menu, $this->permissions, $this->slug, array($this, 'render_page'), 12);
        $this->page = add_submenu_page(
            'edit.php?post_type=social_feed',
            __('Social Feeds Setting', FMC_Social_Feed_Constant::TEXTDOMAIN),
            __('Settings', FMC_Social_Feed_Constant::TEXTDOMAIN),
            'manage_options',
            'sf_setting_page',
            array($this, 'render_page'),
            11
        );
        /* Add callbacks for this screen only */
        add_action('load-' . $this->page, array($this, 'page_actions'), 9);
        add_action('admin_footer-' . $this->page, array($this, 'footer_scripts'));
    }

    /**
     * Prints the jQuery script to initiliase the metaboxes
     * Called on admin_footer-*
     */
    function footer_scripts()
    {
        echo '<script> postboxes.add_postbox_toggles(pagenow);</script>';
    }

    /*
     * Actions to be taken prior to page loading. This is after headers have been set.
     * call on load-$hook
     * This calls the add_meta_boxes hooks, adds screen options and enqueues the postbox.js script.
     */
    function page_actions()
    {
        do_action('add_meta_boxes_' . $this->page, null);
        do_action('add_meta_boxes', $this->page, null);

        /* User can choose between 1 or 2 columns (default 2) */
        add_screen_option('layout_columns', array('max' => 1, 'default' => 1));

        /* Enqueue WordPress' script for handling the metaboxes */
        wp_enqueue_script('postbox');
    }

    /**
     * Renders the page
     */
    function render_page()
    {
        if (!empty($_POST)) {
            $this->save();
        }
        require_once 'views/settings.php';
    }

    /**
     * Save setting value
     */
    public function save()
    {
        $nonce = $_REQUEST['_wpnonce'];
        if (wp_verify_nonce($nonce, 'sf-setting-action-nonce')) {
            if (!isset($_REQUEST['sf_fb_setting']['is_enable'])) {
                $_REQUEST['sf_fb_setting']['is_enable'] = 0;
            }
            update_option(FMC_Social_Feed_Constant::SF_FACEBOOK, $_REQUEST[FMC_Social_Feed_Constant::SF_FACEBOOK]);
            update_option(FMC_Social_Feed_Constant::SF_TWITTER, $_REQUEST[FMC_Social_Feed_Constant::SF_TWITTER]);
            update_option(FMC_Social_Feed_Constant::SF_INSTAGRAM, $_REQUEST[FMC_Social_Feed_Constant::SF_INSTAGRAM]);
            $this->updated = TRUE;
        }
    }

    /**
     * Render metabox
     */
    function render_meta_box() {
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
    }
    function add_meta_boxes() {
        add_meta_box('facebook_setting', 'Facebook Channel Feeds', array($this, 'facebook_setting_metabox'), 'social_feed_page_sf_setting_page', 'normal', 'high');
        add_meta_box('twitter_setting', 'Twitter Channel Feeds', array($this, 'twitter_setting_metabox'), 'social_feed_page_sf_setting_page', 'normal', 'high');
        add_meta_box('instagram_setting', 'Instagram Channel Feeds', array($this, 'instagram_setting_metabox'), 'social_feed_page_sf_setting_page', 'normal', 'high');
    }

    //Define the insides of the metabox
    function facebook_setting_metabox()
    {
        require_once 'views/settings/facebook.php';
    }
    function twitter_setting_metabox()
    {
        require_once 'views/settings/twitter.php';
    }
    function instagram_setting_metabox()
    {
        require_once 'views/settings/instagram.php';
    }
}

//Create social feed setting page
$sf_settings = new FMC_Social_Feed_Setting();
$sf_settings->render_meta_box();


