<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
$cron_class_path = plugin_dir_path(FMC_Social_Feed::$file) . 'inc/cron.php';
require_once $cron_class_path;
/**
 * To cron update twitter likes count
 */
class FMC_Social_Feeds_Cron_Twitter extends FMC_Social_Feeds_Cron
{
    public function __construct() {
        $this->task_hook_name = 'twitter_schedule_event';
        $this->schedule_time = 60 * 60; //every hour
        $this->limit = -1;
    }
    public function do_event() {
        $sf_twitter_setting = get_option(FMC_Social_Feed_Constant::SF_TWITTER);
        if (!is_array($sf_twitter_setting)) {
            $sf_twitter_setting = array();
        }
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'access_token' => NULL,
            'access_token_secret' => NULL,
            'customer_key' => NULL,
            'customer_secret' => NULL,
            'url_api' => NULL
        );
        extract(array_merge($default_value, $sf_twitter_setting));
        if (!$is_enable) return;
        $tax = FMC_Social_Feed_Constant::SF_TWITTER;
        $feed_result = $this->get_feed_ids($tax, 1, $this->limit);
        if (!isset($feed_result['posts']) || !count($feed_result['posts'])) return;
        $feed_ids = $feed_result['posts'];
        set_include_path(plugin_dir_path(FMC_Social_Feed::$file). '/lib' . PATH_SEPARATOR . get_include_path());
        require_once 'twitter/TwitterAPIExchange.php';
        $settings = array(
            'oauth_access_token' => $access_token,
            'oauth_access_token_secret' => $access_token_secret,
            'consumer_key' => $customer_key,
            'consumer_secret' => $customer_secret
        );
        $requestMethod = 'GET';
        $twitter = new TwitterAPIExchange($settings);
        foreach ($feed_ids as $post_id => $feed_id) {
            if (empty($feed_id)) continue;
            $url = "https://api.twitter.com/1.1/statuses/show.json";
            $response = json_decode(
                $twitter->setGetfield("?id={$feed_id}")->buildOauth($url, 'GET')->performRequest()
                , true
            );
            if (isset($response['errors'])) continue;
            //Update those items
            $sf_likes = isset($response['favorite_count']) ?
                $response['favorite_count'] : 0;
            update_post_meta($post_id, 'sf_like', $sf_likes);
            $sf_comments = isset($response['retweet_count']) ?
                $response['retweet_count']: 0;
            update_post_meta($post_id, 'sf_comment_pin', $sf_comments);
            $this->post_updated++;
        }
        ini_restore('include_path');
        return parent::do_event();
    }
}