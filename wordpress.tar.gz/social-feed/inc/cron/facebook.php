<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
$cron_class_path = plugin_dir_path(FMC_Social_Feed::$file) . 'inc/cron.php';
require_once $cron_class_path;

/**
 * Facebook Cron Job Class
 */
class FMC_Social_Feeds_Cron_Facebook extends FMC_Social_Feeds_Cron
{
    public function __construct() {
        $this->task_hook_name = 'facebook_schedule_event';
        $this->schedule_time = 60 * 60; //every hour
        $this->limit = 25;
    }
    /**
     * Update likes count, comments count
     */
    public function do_event()
    {
        //Get social settings
        $sf_facebook_setting = get_option(FMC_Social_Feed_Constant::SF_FACEBOOK);
        $default_value = array(
            'is_enable' => 0,
            'sf_handle' => NULL,
            'app_id' => NULL,
            'app_secret' => NULL
        );
        extract(array_merge($default_value, $sf_facebook_setting));
        if (!$is_enable)
            return;
        $access_token = 'AAAEt4y3a0QwBAFcvyCY0RZBFeGaPwLhxJZBSaQG6rEyhy8EV0mKVdRbqzt9MZA2C2DkTZC8xWypbMth5A8f909mp8N2ZC87g3oYb4uWEkGwZDZD';
        $access_token = 'access_token=' . $access_token;
        $urlfacebook = 'https://graph.facebook.com/';

        //Get feeds ids to update comments total, likes total
        $tax = FMC_Social_Feed_Constant::SF_FACEBOOK;
        $feed_result = $this->get_feed_ids($tax, 1, $this->limit);
        if (!$feed_result['max_num_pages'])
            return;
        for ($paged = 1; $paged <= $feed_result['max_num_pages']; $paged++) {
            if ($paged == 1) {
                $feed_ids = $feed_result['posts'];
            } else {
                $feed_queries = $this->get_feed_ids($tax, $paged, $this->limit);
                if (!$feed_queries['posts'])
                    continue;
                $feed_ids = $feed_queries['posts'];
            }
            $ids = implode(',', array_values($feed_ids));
            $control = "?ids={$ids}&fields=likes.summary(1),comments.summary(1)";
            $url = $urlfacebook . $control . '&&' . $access_token;
            //Call api facebook open graph
            $response = json_decode(FMC_Social_Feed::remote_get_content($url), true);
            if (!is_array($response) || empty($response))
                return;
            foreach ($feed_ids as $post_id => $feed_id) {
                if (!isset($response[$feed_id]))
                    continue;
                //Update those items
                $sf_likes = isset($response[$feed_id]['likes']['summary']['total_count']) ?
                        $response[$feed_id]['likes']['summary']['total_count'] : 0;
                update_post_meta($post_id, 'sf_like', $sf_likes);
                $sf_comments = isset($response[$feed_id]['comments']['summary']['total_count']) ?
                        $response[$feed_id]['comments']['summary']['total_count'] : 0;
                update_post_meta($post_id, 'sf_comment_pin', $sf_comments);
                $this->post_updated++;
            }
        }
        return parent::do_event();
    }
}