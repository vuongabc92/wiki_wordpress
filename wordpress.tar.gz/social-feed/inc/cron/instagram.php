<?php

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
$cron_class_path = plugin_dir_path(FMC_Social_Feed::$file) . 'inc/cron.php';
require_once $cron_class_path;

/**
 * To cron update instagram likes count
 */
class FMC_Social_Feeds_Cron_Instagram extends FMC_Social_Feeds_Cron
{

    public function __construct()
    {
        $this->task_hook_name = 'instagram_schedule_event';
        $this->schedule_time = 60 * 60; //every hour
        $this->limit = -1;
    }

    public function do_event()
    {
        $sf_instagram_setting = get_option(FMC_Social_Feed_Constant::SF_INSTAGRAM);
        if (!is_array($sf_instagram_setting)) {
            $sf_instagram_setting = array();
        }
        $default_value = array('is_enable' => 0,'api_secret' => NULL);
        extract(array_merge($default_value, $sf_instagram_setting));
        ini_restore('include_path');
        if (!$is_enable || empty($api_secret)) return;

        //Get feed from DB and update likes count
        $tax = FMC_Social_Feed_Constant::SF_INSTAGRAM;
        $feed_result = $this->get_feed_ids($tax, 1, $this->limit);
        if (!isset($feed_result['posts']) || !count($feed_result['posts']))
            return;
        $feed_ids = $feed_result['posts'];
        foreach ($feed_ids as $post_id => $feed_id) {
            if (empty($feed_id))
                continue;
            $url = "https://api.instagram.com/v1/media/{$feed_id}?access_token={$api_secret}";
            $remote_content = FMC_Social_Feed::remote_get_content($url);
            if (!$remote_content) continue;
            $response = json_decode($remote_content, TRUE);
            if (isset($response["meta"]["error_type"])) {
                error_log($response["meta"]["error_message"]);
                continue;
            }
            //Update likes count of feed_id
            $sf_likes = isset($response['data']['likes']['count']) ?
                    $response['data']['likes']['count'] : 0;
            update_post_meta($post_id, 'sf_like', $sf_likes);
            $sf_comments = isset($response['data']['comments']['count']) ?
                    $response['data']['comments']['count'] : 0;
            update_post_meta($post_id, 'sf_comment_pin', $sf_comments);
            $this->post_updated++;
        }
        return parent::do_event();
    }

}