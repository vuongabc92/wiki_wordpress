<?php

class Create_Custom_Role1 {

    /**
     * Remove unneccessaries role
     *
     * @return void
     */
    public function remove_role() {
        /* remove the unnecessary roles this block of code should run once */
        remove_role('subscriber');
        remove_role('editor');
        remove_role('author');
        remove_role('contributor');
        //remove_role('kol');
    }

    /**
     * Create kol user role
     *
     * @return void
     */
    public function create_kol_role() {

        $capabilities = array(
            'read' => true,
            'create_posts' => true,
            'edit_posts' => true,
            'delete_posts' => true,
            'publish_posts' => true,
            'edit_published_posts' => true,
            'delete_published_posts' => true,
        );

        add_role('kol', __('KOL'), $capabilities);

    }
}

//$custom_role = new Create_Custom_Role();
//$custom_role->create_kol_role();