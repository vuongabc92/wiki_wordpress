<?php

$api_url = 'http://api.douban.com/shuo/v2/statuses/user_timeline/china' ;
        $datadb = file_get_contents($api_url);
        $data_db = json_decode($datadb, true);

        var_dump($data_db); die;