
<?php if ($this->feeds_query->posts) {
    foreach ($this->feeds_query->posts as $item) {
        ?>
        <?php
        $sf_media = get_post_meta($item->ID, 'sf_media');
        $sf_id = get_post_meta($item->ID, 'sf_ob_id');
        $sf_uid = get_post_meta($item->ID, 'sf_uid');
        $sf_like = get_post_meta($item->ID, 'sf_like');
        $sf_comment_pin = get_post_meta($item->ID, 'sf_comment_pin');
        $sf_chanel = get_post_meta($item->ID, 'sf_chanel');
        $sf_link = get_post_meta($item->ID, 'sf_link');
        $sf_date = get_post_meta($item->ID, 'sf_date');
        $sf_featured = get_post_meta($item->ID, 'is_featured');
        $class_chanel = FMC_Social_Feed_Config::get_chanel_class($sf_chanel[0]);
        $time_ago = FMC_Social_Feed_Config::time_ago($sf_date[0]);
        if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUTUBE){
            $link_feed = 'http://www.youtube.com/watch?v='.$sf_id[0];
        }
        else if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_WEIBO){
            $link_feed = FMC_Social_Feed::get_weibo_url($sf_uid[0], $sf_id[0]);
        }
        else {
            $link_feed = $sf_link[0];
        }

        ?>
        <div class="social-media-block <?php if ($sf_featured[0]) echo $class_chanel['class'] ?>"><span class="rippon"></span>
            <div class="thumb">
                <?php
                if ($sf_media[0]) {
                    if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUTUBE || $sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUKU) {
                        if($sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUTUBE ) $viewicon = 'view-youtube' ; else $viewicon = 'view-youku ' ;
                        ?>
               <img src="<?php echo $sf_media[0] ?>" alt="<?php echo $item->post_title ?>"/><a href="<?php echo $sf_id[0] ?>" title="<?php echo $item->post_title ?>" class="<?php echo $viewicon ; ?> icon-video" >Youtube video</a>
                    <?php } else { ?>
                        <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $item->post_title ?>" class="undefined">
                            <img src="<?php echo $sf_media[0] ?>" alt="<?php echo $item->post_title ?>"/></a>
            <?php }
        }
        ?>
            </div>
            <div class="desc">
                <?php
                    $isExpand = (strlen($item->post_content) > 210) ? true : false;
                    $classExpand = $isExpand ? 'hidden' : '';
                ?>
                <?php if ($isExpand) : ?>
                    <p <?php if ($sf_chanel[0] == 'sf-twitter' || $sf_chanel[0] == 'sf-weibo') echo 'class="quoite"'; ?>><?php echo FMC_Social_Feed::make_links(mb_strcut( $item->post_content, 0,210 )); ?> ...
                        <a id="icon-add" class="icon-add<?php if ($sf_featured[0]) echo '-black';?>" href="javascript:void(0);"></a>
                    </p>
                <?php endif;?>
                    <p class= "<?php echo $classExpand;?><?php if ($sf_chanel[0] == 'sf-twitter' || $sf_chanel[0] == 'sf-weibo') echo " quoite" ?>"><?php echo FMC_Social_Feed::make_links($item->post_content);  ?></p>
            </div>
            <div class="social">
                <ul class="status">
                    <?php if ($sf_chanel[0] != FMC_Social_Feed_Constant::SF_NAVER) { ?>
                    <li>
                        <?php if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUTUBE) {?>
                        <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $sf_like[0] ?>"><span class="<?php echo $class_chanel['like']; ?>"></span><span class="none-link social-desktop"><?php echo $sf_like[0] ?></span><span class="mobile none-link">&nbsp;like<?php if ($sf_like[0] > 1)echo 's'; ?></span></a>
                        <?php } else {?>
                        <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $sf_like[0] ?>"><span class="<?php echo $class_chanel['like']; ?>"></span><span class="social-desktop"><?php echo $sf_like[0] ?></span><span class="mobile">&nbsp;like<?php if ($sf_like[0] > 1)echo 's'; ?></span></a>
                        <?php }?>
                    </li>
                    <?php if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_INSTAGRAM || $sf_chanel[0] == FMC_Social_Feed_Constant::SF_TWITTER) {?>
                    <li>
                        <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $sf_comment_pin[0] ?>" class="undefined"><span class="icon-comment<?php if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_TWITTER) echo'-1' ?>"></span><span class="social-desktop"><?php echo $sf_comment_pin[0] ?></span><span class="mobile">&nbsp;<?php if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_TWITTER) echo  'retweet' ; else echo 'comment' ;?><?php if ($sf_comment_pin[0] > 1)echo 's'; ?></span></a>
                    </li>
                    <?php }?>
                    <?php } ?>
                </ul>
                <div class="name-social">
                    <?php  if ($sf_chanel[0] == FMC_Social_Feed_Constant::SF_YOUTUBE) {?>
                            <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $time_ago;  ?>"><span class="<?php echo $class_chanel['icon'] ?>"></span><span class="none-link social-desktop"><?php echo $time_ago; ?></span></a>
                        <?php } else {?>
                            <a target="_blank" href="<?php echo $link_feed ?>" title="<?php echo $time_ago;  ?>"><span class="<?php echo $class_chanel['icon'] ?>"></span><span class="none-link social-desktop"><?php echo $time_ago; ?></span></a>
                        <?php }?>
                </div>
            </div>
        </div>
    <?php }
}
?>
<input id="num-of-page" type="hidden" name="num-of-page" value="<?php echo (int) $_REQUEST['page'] + 1; ?>"/>