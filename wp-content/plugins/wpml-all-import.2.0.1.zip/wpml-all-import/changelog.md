#2.0.1

##Fixes

* Fixed error while activating when WP All Import absent

#2.0.0

* Initial release (previous versions was maintained not by WPML team)