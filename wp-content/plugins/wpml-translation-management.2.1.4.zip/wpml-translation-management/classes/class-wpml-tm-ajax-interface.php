<?php

interface WPML_TM_AJAX_Interface {
//	public function __construct();

	public function enqueue_resources( $hook_suffix );
}